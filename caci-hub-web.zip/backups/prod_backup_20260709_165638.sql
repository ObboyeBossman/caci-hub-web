--
-- PostgreSQL database dump
--

\restrict T08lCyunFWIVDumxyxNvIjCG5eH9Nu2s1frbV4xKfj9tacuzGAzxSQv10k8yTZF

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA supabase_migrations;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: attendance_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.attendance_status AS ENUM (
    'present',
    'absent',
    'excused'
);


--
-- Name: finance_budget_period; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.finance_budget_period AS ENUM (
    'monthly',
    'quarterly',
    'annual'
);


--
-- Name: finance_category_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.finance_category_type AS ENUM (
    'income',
    'expense'
);


--
-- Name: finance_payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.finance_payment_method AS ENUM (
    'cash',
    'momo',
    'bank_transfer',
    'cheque',
    'other'
);


--
-- Name: finance_pledge_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.finance_pledge_status AS ENUM (
    'active',
    'completed',
    'defaulted',
    'cancelled'
);


--
-- Name: finance_transaction_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.finance_transaction_type AS ENUM (
    'tithe',
    'offering',
    'special_offering',
    'pledge_payment',
    'donation',
    'expense'
);


--
-- Name: gender_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.gender_type AS ENUM (
    'male',
    'female'
);


--
-- Name: group_member_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.group_member_role AS ENUM (
    'leader',
    'assistant_leader',
    'member'
);


--
-- Name: group_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.group_type AS ENUM (
    'department',
    'age_group'
);


--
-- Name: marital_status_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.marital_status_type AS ENUM (
    'single',
    'married',
    'widowed',
    'divorced',
    'separated'
);


--
-- Name: membership_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.membership_status AS ENUM (
    'active',
    'inactive',
    'visitor',
    'prospect',
    'transfer',
    'deceased'
);


--
-- Name: pastoral_case_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pastoral_case_status AS ENUM (
    'open',
    'in_progress',
    'resolved',
    'closed'
);


--
-- Name: pastoral_case_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pastoral_case_type AS ENUM (
    'follow_up',
    'bereavement',
    'illness',
    'counselling',
    'discipline',
    'other'
);


--
-- Name: pastoral_priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pastoral_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


--
-- Name: prayer_request_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.prayer_request_status AS ENUM (
    'active',
    'answered',
    'closed'
);


--
-- Name: recurrence_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.recurrence_type AS ENUM (
    'none',
    'daily',
    'weekly',
    'biweekly',
    'monthly'
);


--
-- Name: service_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.service_status AS ENUM (
    'scheduled',
    'completed',
    'cancelled'
);


--
-- Name: visit_outcome; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.visit_outcome AS ENUM (
    'positive',
    'needs_follow_up',
    'no_response',
    'referred'
);


--
-- Name: visit_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.visit_type AS ENUM (
    'home_visit',
    'hospital_visit',
    'phone_call',
    'video_call',
    'in_person'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: assign_membership_number(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_membership_number(p_member_id uuid, p_assembly_id uuid) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
DECLARE
  v_assembly_code text;
  v_max_seq integer;
  v_new_seq integer;
  v_membership_number text;
  v_existing_number text;
BEGIN
  -- 1. Check if the member already has a membership number (Idempotency)
  SELECT membership_number INTO v_existing_number
  FROM public.members
  WHERE id = p_member_id;

  IF v_existing_number IS NOT NULL THEN
    RETURN v_existing_number;
  END IF;

  -- 2. Lock the assembly row to queue concurrent requests.
  SELECT assembly_code INTO v_assembly_code
  FROM public.assemblies
  WHERE id = p_assembly_id
  FOR UPDATE;

  IF v_assembly_code IS NULL THEN
    RAISE EXCEPTION 'Assembly not found or could not be locked';
  END IF;

  -- 3. Calculate the sequence max safely within the lock.
  -- We include both active and soft-deleted members to ensure sequences never overlap.
  -- We also ensure the regex matches exactly the trailing digits.
  SELECT COALESCE(
    MAX(
      CAST(
        SUBSTRING(membership_number FROM '-([0-9]+)$') AS integer
      )
    ),
    0
  )
  INTO v_max_seq
  FROM public.members
  WHERE assembly_id = p_assembly_id
    AND membership_number IS NOT NULL
    AND membership_number LIKE ('CACI-' || v_assembly_code || '-%');

  v_new_seq := v_max_seq + 1;
  v_membership_number := 'CACI-' || v_assembly_code || '-' || LPAD(v_new_seq::text, 5, '0');

  -- 4. Assign to member record
  UPDATE public.members
  SET membership_number = v_membership_number
  WHERE id = p_member_id;

  RETURN v_membership_number;
END;
$_$;


--
-- Name: FUNCTION assign_membership_number(p_member_id uuid, p_assembly_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.assign_membership_number(p_member_id uuid, p_assembly_id uuid) IS 'Generates and assigns a membership number for the given member in the given assembly. SECURITY DEFINER (required to bypass RLS on members during sequence calculation). Callable by authenticated and service_role only — anon EXECUTE revoked to prevent unauthenticated invocation via /rest/v1/rpc/.';


--
-- Name: auth_assembly_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_assembly_id() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT assembly_id
  FROM public.user_profiles
  WHERE id = auth.uid()
  LIMIT 1;
$$;


--
-- Name: FUNCTION auth_assembly_id(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.auth_assembly_id() IS 'Returns the assembly_id for the currently authenticated user. SECURITY DEFINER prevents RLS recursion when called from other table RLS policies.';


--
-- Name: auth_has_permission(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_has_permission(perm_key text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM user_profiles up
    JOIN assembly_roles ar  ON ar.id = up.assembly_role_id
    JOIN role_permissions rp ON rp.role_id = ar.id
    WHERE up.id = auth.uid()
    AND   rp.permission_key = perm_key
    AND   ar.is_active = true
    AND   up.is_active = true
  );
$$;


--
-- Name: auth_is_participant_of_thread(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_is_participant_of_thread(p_thread_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM communication_thread_participants
    WHERE thread_id = p_thread_id
    AND   member_id = auth_member_id()
    AND   left_at IS NULL
  );
$$;


--
-- Name: auth_is_thread_participant(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_is_thread_participant(p_thread_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM communication_thread_participants
    WHERE thread_id = p_thread_id
    AND   member_id = auth_member_id()
    AND   left_at IS NULL
  );
$$;


--
-- Name: auth_member_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auth_member_id() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $$
  SELECT id FROM members
  WHERE auth_user_id = auth.uid()
  AND   is_active = true
  LIMIT 1;
$$;


--
-- Name: clear_must_change_password(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_must_change_password() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  UPDATE public.user_profiles
     SET must_change_password = false
   WHERE id = auth.uid();
END;
$$;


--
-- Name: FUNCTION clear_must_change_password(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.clear_must_change_password() IS 'Allows an authenticated user to clear their own must_change_password flag after successfully updating their password. Bypasses user_profiles RLS.';


--
-- Name: enforce_member_update_columns(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_member_update_columns() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_role TEXT;
BEGIN
  v_role := public.get_user_role();

  -- Allow internal system calls (triggers, migrations, service role).
  IF v_role IS NULL THEN
    RETURN NEW;
  END IF;

  -- Admin: unrestricted.
  IF v_role = 'admin' THEN
    RETURN NEW;
  END IF;

  -- All other system roles (currently: 'member'): deny direct updates.
  -- Fine-grained write permissions are enforced by authorization-service.ts
  -- before the request reaches the database. If a write reaches here from a
  -- non-admin, it must be rejected as a defence-in-depth measure.
  RAISE EXCEPTION 'Insufficient permissions to update member record'
    USING ERRCODE = '42501';
END;
$$;


--
-- Name: FUNCTION enforce_member_update_columns(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.enforce_member_update_columns() IS 'BEFORE UPDATE trigger that enforces column-level write permissions per role. Admin: unrestricted. Secretary: all except pastoral_notes. Pastor: pastoral_notes only. Volunteer/Member: all updates denied. SECURITY DEFINER to call get_user_role() safely. Callable by authenticated only — anon EXECUTE revoked.';


--
-- Name: get_available_primary_contacts(uuid, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_available_primary_contacts(p_assembly_id uuid, p_search text, p_current_household_id uuid DEFAULT NULL::uuid) RETURNS TABLE(id uuid, first_name text, last_name text, primary_phone text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  SELECT m.id, m.first_name, m.last_name, m.primary_phone
  FROM public.members_view m
  WHERE m.assembly_id = p_assembly_id
    AND m.is_active = true
    AND (
      p_search IS NULL 
      OR p_search = '' 
      OR m.first_name ILIKE '%' || p_search || '%' 
      OR m.last_name ILIKE '%' || p_search || '%'
    )
    AND NOT EXISTS (
       SELECT 1 FROM public.households h 
       WHERE h.primary_contact_id = m.id 
         AND (p_current_household_id IS NULL OR h.id != p_current_household_id)
    )
  ORDER BY m.last_name, m.first_name;
END;
$$;


--
-- Name: get_next_membership_sequence(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_next_membership_sequence(p_assembly_id uuid) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
DECLARE
  v_max_seq integer;
  v_dummy text;
BEGIN
  -- 1. Lock the parent assembly row. This is the crucial fix for the race condition.
  -- Even if there are 0 members, the assembly row exists. Concurrent calls will be
  -- blocked here and proceed one by one.
  SELECT name INTO v_dummy
  FROM public.assemblies
  WHERE id = p_assembly_id
  FOR UPDATE;

  -- 2. Now safely calculate the max sequence. Since we hold the assembly lock,
  -- no other transaction can be doing this at the same time for this assembly.
  SELECT COALESCE(
    MAX(
      CAST(
        SPLIT_PART(membership_number, '-', 3) AS integer
      )
    ),
    0
  )
  INTO v_max_seq
  FROM public.members
  WHERE assembly_id = p_assembly_id
    AND membership_number IS NOT NULL
    AND membership_number ~ '^CACI-[A-Z]+-[0-9]+$';

  RETURN v_max_seq;
END;
$_$;


--
-- Name: FUNCTION get_next_membership_sequence(p_assembly_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_next_membership_sequence(p_assembly_id uuid) IS 'Returns the current highest sequence integer for members in the given assembly. Uses FOR UPDATE on the assemblies table to properly serialise concurrent calls preventing duplicate numbers (Day 65 race condition fix).';


--
-- Name: get_user_assembly_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_assembly_id() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT assembly_id
  FROM public.user_profiles
  WHERE id = auth.uid()
    AND is_active = true
  LIMIT 1;
$$;


--
-- Name: FUNCTION get_user_assembly_id(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_user_assembly_id() IS 'Returns the assembly_id for the authenticated user. NULL if no active profile. SECURITY DEFINER prevents RLS recursion on user_profiles.';


--
-- Name: get_user_role(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role() RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT role
  FROM public.user_profiles
  WHERE id        = auth.uid()
    AND is_active = true
  LIMIT 1;
$$;


--
-- Name: FUNCTION get_user_role(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_user_role() IS 'Returns the system role (admin | member) of the currently authenticated user. Returns NULL if no active user_profiles row exists for auth.uid(). SECURITY DEFINER prevents infinite recursion in RLS policies on tables that join user_profiles. Used in RLS enforcement for admin override.';


--
-- Name: has_finance_permission(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_finance_permission(perm text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM role_permissions rp
    JOIN assembly_roles ar
      ON ar.id = (
        SELECT assembly_role_id FROM user_profiles
        WHERE id = auth.uid()
      )
    JOIN system_permissions sp
      ON sp.id = rp.permission_key
    WHERE sp.key = perm
      AND ar.assembly_id = auth_assembly_id()
  )
$$;


--
-- Name: has_pastoral_permission(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_pastoral_permission(perm text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM role_permissions rp
    JOIN assembly_roles ar
      ON ar.id = (
        SELECT assembly_role_id FROM user_profiles
        WHERE id = auth.uid()
      )
    JOIN system_permissions sp
      ON sp.id = rp.permission_key
    WHERE sp.key = perm
      AND ar.assembly_id = auth_assembly_id()
  )
$$;


--
-- Name: increment_storage_usage(uuid, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.increment_storage_usage(p_assembly_id uuid, p_bytes bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_month date := date_trunc('month', now())::date;
BEGIN
  INSERT INTO assembly_storage_usage (assembly_id, snapshot_month, supabase_bytes)
  VALUES (p_assembly_id, v_month, p_bytes)
  ON CONFLICT (assembly_id, snapshot_month)
  DO UPDATE SET supabase_bytes = assembly_storage_usage.supabase_bytes + p_bytes;
END;
$$;


--
-- Name: is_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_profiles
    WHERE id        = auth.uid()
      AND role      = 'admin'
      AND is_active = true
  );
$$;


--
-- Name: FUNCTION is_admin(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.is_admin() IS 'Returns true iff the current user is an active admin. Compares against the TEXT system role. Returns false (not NULL) for unauthenticated or inactive users. Used in admin-only RLS policies.';


--
-- Name: is_member(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_member() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_profiles
    WHERE id        = auth.uid()
      AND role      = 'member'
      AND is_active = true
  );
$$;


--
-- Name: FUNCTION is_member(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.is_member() IS 'Returns true iff the current user is an active member (non-admin system role). In the new RBAC model, permission checks happen at the app layer — not in RLS. RLS only uses is_admin() and is_member() for assembly isolation.';


--
-- Name: link_household_primary_contact(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.link_household_primary_contact() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN
  -- If primary_contact_id is set or changed
  IF NEW.primary_contact_id IS NOT NULL THEN
    UPDATE public.members
    SET household_id = NEW.id
    WHERE id = NEW.primary_contact_id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: log_service_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_service_changes() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
DECLARE
  col     text;
  old_val text;
  new_val text;
BEGIN
  FOREACH col IN ARRAY ARRAY[
    'title', 'status', 'service_date',
    'start_time', 'venue', 'headcount',
    'notes', 'group_id', 'deleted_at'
  ] LOOP
    EXECUTE format('SELECT ($1).%I::text', col)
      INTO old_val USING OLD;
    EXECUTE format('SELECT ($1).%I::text', col)
      INTO new_val USING NEW;

    IF old_val IS DISTINCT FROM new_val THEN
      INSERT INTO service_audit_log (
        service_id, changed_by,
        field_changed, old_value, new_value
      ) VALUES (
        NEW.id, auth.uid(),
        col, old_val, new_val
      );
    END IF;
  END LOOP;
  RETURN NEW;
END;
$_$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION set_updated_at(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_updated_at() IS 'Generic trigger function that sets updated_at = now() on every row UPDATE. Shared across all Phase 1 tables. SET search_path = public added per security advisor.';


--
-- Name: sync_user_permissions_to_jwt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_user_permissions_to_jwt() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_permissions TEXT[];
BEGIN
  -- Collect permission keys for the new assembly role (empty when NULL)
  IF NEW.assembly_role_id IS NOT NULL THEN
    SELECT ARRAY_AGG(rp.permission_key)
      INTO v_permissions
      FROM public.role_permissions rp
     WHERE rp.role_id = NEW.assembly_role_id;
  ELSE
    v_permissions := ARRAY[]::TEXT[];
  END IF;

  -- Coalesce NULL to empty array
  v_permissions := COALESCE(v_permissions, ARRAY[]::TEXT[]);

  -- Write into auth.users.raw_app_meta_data (merges with existing keys)
  UPDATE auth.users
     SET raw_app_meta_data = raw_app_meta_data
       || jsonb_build_object(
            'assembly_id',  NEW.assembly_id,
            'permissions',  to_jsonb(v_permissions)
          )
   WHERE id = NEW.id;

  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION sync_user_permissions_to_jwt(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.sync_user_permissions_to_jwt() IS 'Fires after UPDATE of assembly_role_id or assembly_id on user_profiles. Collects permission keys for the new assembly role and writes them into auth.users.raw_app_meta_data as { assembly_id, permissions: [...] }. The frontend reads this from the JWT app_metadata to hydrate the AppUser permissions array without an extra DB round-trip.';


--
-- Name: write_member_audit_log(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.write_member_audit_log() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
DECLARE
  auditable_columns TEXT[] := ARRAY[
    'title',
    'first_name', 'last_name', 'other_names', 'primary_phone', 'secondary_phone', 'email',
    'occupation', 'physical_address', 'facebook_url',
    'whatsapp_number', 'instagram_url',
    'emergency_contact_name', 'emergency_contact_phone',
    'emergency_contact_relationship',
    'membership_status', 'gender', 'marital_status',
    'household_id', 'profile_photo_url', 'pastoral_notes',
    'is_active', 'deleted_at', 'join_date'
  ];
  col_name  TEXT;
  old_val   TEXT;
  new_val   TEXT;
BEGIN
  FOREACH col_name IN ARRAY auditable_columns LOOP
    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO old_val USING OLD;
    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO new_val USING NEW;

    IF old_val IS DISTINCT FROM new_val THEN
      INSERT INTO public.member_audit_log (
        member_id, assembly_id, changed_by, field_changed, old_value, new_value
      ) VALUES (
        NEW.id,
        NEW.assembly_id,
        auth.uid(),
        col_name,
        old_val,
        new_val
      );
    END IF;
  END LOOP;

  RETURN NEW;
END;
$_$;


--
-- Name: FUNCTION write_member_audit_log(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.write_member_audit_log() IS 'AFTER UPDATE trigger on members. Inserts one member_audit_log row per changed auditable field. Runs as SECURITY DEFINER to bypass the absence of an INSERT policy on member_audit_log (IMR-02). Reference: Document 4, Section 7.2.';


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: announcement_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcement_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    target_group_ids uuid[] DEFAULT '{}'::uuid[],
    is_pinned boolean DEFAULT false,
    visible_from timestamp with time zone DEFAULT now(),
    visible_until timestamp with time zone,
    posted_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: assemblies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assemblies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    assembly_code text NOT NULL,
    address text,
    digital_address text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    default_member_password text,
    CONSTRAINT assemblies_assembly_code_check CHECK ((assembly_code ~ '^[A-Z]{2}-[A-Z]{3,6}$'::text))
);


--
-- Name: TABLE assemblies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.assemblies IS 'Assembly (church branch) registry. Pre-seeded in Phase 1 — not user-managed via UI until the multi-assembly management phase.';


--
-- Name: COLUMN assemblies.assembly_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.assemblies.assembly_code IS 'Short structured code used in membership number generation. Format: [2-letter country ISO]-[3–6 letter abbreviation]. e.g. GH-ASSAK. Enforced by CHECK constraint.';


--
-- Name: COLUMN assemblies.digital_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.assemblies.digital_address IS 'Ghana GhanaPostGPS digital address code. e.g. WR-1234-5678. NULL until the GPS code is confirmed for the assembly location.';


--
-- Name: COLUMN assemblies.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.assemblies.is_active IS 'Soft-disable flag. Set to false to deactivate an assembly without deleting its records. Not used in Phase 1 (single assembly).';


--
-- Name: COLUMN assemblies.default_member_password; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.assemblies.default_member_password IS 'Assembly-level temporary password for members with no email.
   Set once by admin via the set-assembly-default-password Edge Function.
   NULL means not yet configured. Never stored per-member.';


--
-- Name: assembly_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assembly_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN assembly_roles.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.assembly_roles.is_active IS 'Soft-disable flag. Deactivated roles still exist in the DB but are excluded from UI role pickers. Users assigned a deactivated role lose its permissions at next JWT refresh.';


--
-- Name: COLUMN assembly_roles.is_system; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.assembly_roles.is_system IS 'Reserved for platform-default roles seeded by migrations. is_system = true roles may not be deleted by assemblies.';


--
-- Name: assembly_storage_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assembly_storage_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    snapshot_month date NOT NULL,
    supabase_bytes bigint DEFAULT 0,
    r2_warm_bytes bigint DEFAULT 0,
    r2_cold_bytes bigint DEFAULT 0,
    total_bytes bigint GENERATED ALWAYS AS (((supabase_bytes + r2_warm_bytes) + r2_cold_bytes)) STORED,
    sms_segments_sent integer DEFAULT 0,
    whatsapp_msgs_sent integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: communication_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    thread_message_id uuid,
    campaign_id uuid,
    storage_tier text DEFAULT 'hot'::text NOT NULL,
    storage_provider text DEFAULT 'supabase'::text NOT NULL,
    storage_bucket text NOT NULL,
    storage_path text NOT NULL,
    public_url text,
    mime_type text NOT NULL,
    file_size_bytes bigint NOT NULL,
    original_filename text,
    checksum text,
    duration_seconds integer,
    waveform_data jsonb,
    normalised_path text,
    transcription_text text,
    transcription_status text DEFAULT 'skipped'::text,
    is_sensitive boolean DEFAULT false,
    virus_scan_status text DEFAULT 'pending'::text,
    uploaded_by uuid,
    archive_after timestamp with time zone,
    purge_after timestamp with time zone,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT communication_attachments_storage_provider_check CHECK ((storage_provider = ANY (ARRAY['supabase'::text, 'r2'::text]))),
    CONSTRAINT communication_attachments_storage_tier_check CHECK ((storage_tier = ANY (ARRAY['hot'::text, 'warm'::text, 'cold'::text]))),
    CONSTRAINT communication_attachments_transcription_status_check CHECK ((transcription_status = ANY (ARRAY['pending'::text, 'processing'::text, 'done'::text, 'failed'::text, 'skipped'::text]))),
    CONSTRAINT communication_attachments_virus_scan_status_check CHECK ((virus_scan_status = ANY (ARRAY['pending'::text, 'clean'::text, 'infected'::text, 'skipped'::text])))
);


--
-- Name: communication_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_campaigns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    template_id uuid,
    title text NOT NULL,
    channel text NOT NULL,
    audience_type text NOT NULL,
    audience_ids uuid[] DEFAULT '{}'::uuid[],
    trigger_type text DEFAULT 'manual'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    scheduled_at timestamp with time zone,
    sent_at timestamp with time zone,
    total_recipients integer DEFAULT 0,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT communication_campaigns_audience_type_check CHECK ((audience_type = ANY (ARRAY['assembly'::text, 'group'::text, 'member_list'::text, 'filter'::text]))),
    CONSTRAINT communication_campaigns_channel_check CHECK ((channel = ANY (ARRAY['in_app'::text, 'email'::text, 'sms'::text, 'whatsapp'::text, 'push'::text]))),
    CONSTRAINT communication_campaigns_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'scheduled'::text, 'sending'::text, 'sent'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT communication_campaigns_trigger_type_check CHECK ((trigger_type = ANY (ARRAY['manual'::text, 'birthday'::text, 'event_reminder'::text, 'pledge_reminder'::text, 'custom'::text])))
);


--
-- Name: communication_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    campaign_id uuid,
    assembly_id uuid NOT NULL,
    member_id uuid NOT NULL,
    channel text NOT NULL,
    body_resolved text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    provider text,
    external_ref text,
    provider_status text,
    failed_reason text,
    cost_units integer DEFAULT 0,
    delivered_at timestamp with time zone,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    CONSTRAINT communication_messages_provider_check CHECK ((provider = ANY (ARRAY['sendgrid'::text, 'twilio'::text, 'arkesel'::text, 'fcm'::text, 'internal'::text]))),
    CONSTRAINT communication_messages_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'sent'::text, 'delivered'::text, 'read'::text, 'failed'::text])))
);


--
-- Name: communication_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    assembly_id uuid NOT NULL,
    channel text NOT NULL,
    category text NOT NULL,
    opted_in boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: communication_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    channel text NOT NULL,
    category text NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb,
    whatsapp_template_name text,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT communication_templates_category_check CHECK ((category = ANY (ARRAY['broadcast'::text, 'direct'::text, 'automated'::text, 'announcement'::text]))),
    CONSTRAINT communication_templates_channel_check CHECK ((channel = ANY (ARRAY['in_app'::text, 'email'::text, 'sms'::text, 'whatsapp'::text, 'push'::text])))
);


--
-- Name: communication_thread_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_thread_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    message_type text DEFAULT 'text'::text NOT NULL,
    body text,
    storage_tier text DEFAULT 'hot'::text,
    created_at timestamp with time zone DEFAULT now(),
    edited_at timestamp with time zone,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT communication_thread_messages_message_type_check CHECK ((message_type = ANY (ARRAY['text'::text, 'audio'::text, 'image'::text, 'document'::text]))),
    CONSTRAINT communication_thread_messages_storage_tier_check CHECK ((storage_tier = ANY (ARRAY['hot'::text, 'warm'::text, 'cold'::text])))
);


--
-- Name: communication_thread_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_thread_participants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    member_id uuid NOT NULL,
    role text DEFAULT 'member'::text,
    joined_at timestamp with time zone DEFAULT now(),
    left_at timestamp with time zone,
    last_read_at timestamp with time zone,
    CONSTRAINT communication_thread_participants_role_check CHECK ((role = ANY (ARRAY['member'::text, 'pastor'::text, 'admin'::text])))
);


--
-- Name: communication_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    subject text,
    is_pastoral boolean DEFAULT false,
    is_sensitive boolean DEFAULT false,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: communication_trigger_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_trigger_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    trigger_event text NOT NULL,
    template_id uuid NOT NULL,
    channels text[] NOT NULL,
    days_offset integer DEFAULT 0,
    offset_direction text DEFAULT 'before'::text,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT communication_trigger_rules_offset_direction_check CHECK ((offset_direction = ANY (ARRAY['before'::text, 'after'::text]))),
    CONSTRAINT communication_trigger_rules_trigger_event_check CHECK ((trigger_event = ANY (ARRAY['member.birthday'::text, 'service.reminder'::text, 'pledge.overdue'::text, 'member.join_anniversary'::text])))
);


--
-- Name: finance_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_budgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    category_id uuid NOT NULL,
    period public.finance_budget_period NOT NULL,
    year integer NOT NULL,
    month integer,
    quarter integer,
    budgeted_amount numeric(12,2) NOT NULL,
    actual_amount numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT finance_budgets_budgeted_amount_check CHECK ((budgeted_amount >= (0)::numeric)),
    CONSTRAINT finance_budgets_month_check CHECK (((month >= 1) AND (month <= 12))),
    CONSTRAINT finance_budgets_quarter_check CHECK (((quarter >= 1) AND (quarter <= 4))),
    CONSTRAINT finance_budgets_year_check CHECK ((year >= 2000))
);


--
-- Name: finance_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    name text NOT NULL,
    category_type public.finance_category_type NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: finance_pledges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_pledges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    member_id uuid NOT NULL,
    pledge_name text NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'GHS'::text NOT NULL,
    start_date date DEFAULT CURRENT_DATE NOT NULL,
    end_date date,
    status public.finance_pledge_status DEFAULT 'active'::public.finance_pledge_status NOT NULL,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT chk_pledge_amount CHECK ((amount_paid <= total_amount)),
    CONSTRAINT finance_pledges_amount_paid_check CHECK ((amount_paid >= (0)::numeric)),
    CONSTRAINT finance_pledges_total_amount_check CHECK ((total_amount > (0)::numeric))
);


--
-- Name: finance_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    category_id uuid NOT NULL,
    member_id uuid,
    transaction_type public.finance_transaction_type NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'GHS'::text NOT NULL,
    payment_method public.finance_payment_method NOT NULL,
    reference_number text,
    transaction_date date DEFAULT CURRENT_DATE NOT NULL,
    description text,
    service_id uuid,
    group_id uuid,
    pledge_id uuid,
    recorded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT finance_transactions_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid NOT NULL,
    member_id uuid NOT NULL,
    role public.group_member_role DEFAULT 'member'::public.group_member_role NOT NULL,
    joined_at date DEFAULT CURRENT_DATE NOT NULL,
    left_at date,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    name text NOT NULL,
    group_type public.group_type NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    leader_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: households; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.households (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    family_name text NOT NULL,
    address text,
    primary_contact_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE households; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.households IS 'Groups member records into family units. Scoped to a single assembly. primary_contact_id is a plain uuid here; the FK to members.id is added as a deferrable constraint in Migration 7 to resolve the circular reference caused by members.household_id referencing this table.';


--
-- Name: COLUMN households.assembly_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.households.assembly_id IS 'Assembly this household belongs to. All RLS policies scope households to the requesting user''s assembly via this column.';


--
-- Name: COLUMN households.family_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.households.family_name IS 'Display name for the household. e.g. "Asante Family". Required — a household must have a name to be meaningful.';


--
-- Name: COLUMN households.address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.households.address IS 'Optional household address. May differ from individual member addresses (e.g. a family home vs a member''s personal residence).';


--
-- Name: COLUMN households.primary_contact_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.households.primary_contact_id IS 'UUID of the primary contact member for this household. Stored without a FK constraint until Migration 7 adds the deferrable FK (households.primary_contact_id -> members.id ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED). Will be NULL until explicitly set by the Admin.';


--
-- Name: member_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    assembly_id uuid NOT NULL,
    changed_by uuid,
    field_changed text NOT NULL,
    old_value text,
    new_value text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE member_audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.member_audit_log IS 'Immutable audit trail of field-level changes to member records. Written only by the write_member_audit_log SECURITY DEFINER trigger. No application role may INSERT, UPDATE, or DELETE rows — see IMR-02.';


--
-- Name: COLUMN member_audit_log.changed_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.member_audit_log.changed_by IS 'auth.uid() of the user whose request caused the UPDATE. Set by the trigger.';


--
-- Name: COLUMN member_audit_log.field_changed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.member_audit_log.field_changed IS 'Name of the members column that changed. One row per changed field per UPDATE.';


--
-- Name: COLUMN member_audit_log.old_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.member_audit_log.old_value IS 'Previous column value cast to text. NULL if the column was previously NULL.';


--
-- Name: COLUMN member_audit_log.new_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.member_audit_log.new_value IS 'New column value cast to text. NULL if the column was set to NULL.';


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    membership_number text,
    first_name text NOT NULL,
    last_name text NOT NULL,
    date_of_birth date,
    gender public.gender_type NOT NULL,
    marital_status public.marital_status_type,
    primary_phone text,
    email text,
    physical_address text,
    occupation text,
    facebook_url text,
    whatsapp_number text,
    instagram_url text,
    emergency_contact_name text,
    emergency_contact_phone text,
    emergency_contact_relationship text,
    membership_status public.membership_status DEFAULT 'visitor'::public.membership_status NOT NULL,
    join_date date,
    household_id uuid,
    profile_photo_url text,
    pastoral_notes text,
    is_active boolean DEFAULT true NOT NULL,
    deleted_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auth_user_id uuid,
    other_names text,
    secondary_phone text,
    title text,
    CONSTRAINT members_title_check CHECK ((title = ANY (ARRAY['Mr.'::text, 'Mrs.'::text, 'Ms.'::text, 'Miss'::text, 'Dr.'::text, 'Prof.'::text, 'Rev.'::text, 'Pastor'::text, 'Elder'::text, 'Deacon'::text, 'Deaconess'::text, 'Apostle'::text, 'Bishop'::text])))
);


--
-- Name: TABLE members; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.members IS 'Core member registry for CACI Hub. Scoped to a single assembly via assembly_id. Membership numbers are assigned by the generate-membership-number Edge Function immediately after insert (Day 15 Decision 1). Soft-deleted rows have deleted_at set and remain for audit; they are excluded from all active-member indexes and policies.';


--
-- Name: COLUMN members.assembly_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.assembly_id IS 'Assembly this member belongs to. Every RLS policy filters on this column (IMR-04).';


--
-- Name: COLUMN members.membership_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.membership_number IS 'Unique identifier in the format CACI-[assembly_code]-[5-digit-sequence]. NULL at insert time; populated by the generate-membership-number Edge Function. Uniqueness enforced by idx_members_membership_number_unique (partial, WHERE deleted_at IS NULL).';


--
-- Name: COLUMN members.membership_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.membership_status IS 'Lifecycle status of this member. Defaults to ''visitor'' at insert; promoted to ''active'' by admin or secretary after formal joining.';


--
-- Name: COLUMN members.join_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.join_date IS 'Date the member formally joined the assembly. Explicitly set by admin; distinct from created_at (Day 11 Decision 1).';


--
-- Name: COLUMN members.household_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.household_id IS 'Optional FK to the households table. NULL until the member is assigned to a household. ON DELETE SET NULL: deleting the household record does not orphan the member.';


--
-- Name: COLUMN members.pastoral_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.pastoral_notes IS 'Confidential pastoral-care notes visible only to admin and pastor roles. RLS column-level restriction applied in the dedicated RLS migration.';


--
-- Name: COLUMN members.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.is_active IS 'Fast boolean flag indicating whether the member is active. Soft-deleted members have is_active = false AND deleted_at IS NOT NULL. Suspended (inactive but not deleted) members have is_active = false AND deleted_at IS NULL.';


--
-- Name: COLUMN members.deleted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.deleted_at IS 'Timestamp when the member record was soft-deleted. NULL means the record is not deleted. All partial indexes and RLS policies filter on deleted_at IS NULL.';


--
-- Name: COLUMN members.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.created_by IS 'auth.users.id of the user who created this member record. NULL for system-generated or seeded records. ON DELETE SET NULL preserves the member if the creating admin account is later removed.';


--
-- Name: COLUMN members.auth_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.auth_user_id IS 'Supabase Auth user linked to this member (admin-provisioned login). NULL means no app login yet.';


--
-- Name: COLUMN members.other_names; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.other_names IS 'Middle or secondary names of the member. Optional.';


--
-- Name: members_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.members_view WITH (security_barrier='true', security_invoker='true') AS
 SELECT id,
    assembly_id,
    membership_number,
    first_name,
    last_name,
    other_names,
    title,
    date_of_birth,
    gender,
    marital_status,
    primary_phone,
    secondary_phone,
    email,
    physical_address,
    occupation,
    facebook_url,
    whatsapp_number,
    instagram_url,
        CASE
            WHEN (public.is_admin() OR (auth_user_id = ( SELECT auth.uid() AS uid))) THEN emergency_contact_name
            ELSE NULL::text
        END AS emergency_contact_name,
        CASE
            WHEN (public.is_admin() OR (auth_user_id = ( SELECT auth.uid() AS uid))) THEN emergency_contact_phone
            ELSE NULL::text
        END AS emergency_contact_phone,
        CASE
            WHEN (public.is_admin() OR (auth_user_id = ( SELECT auth.uid() AS uid))) THEN emergency_contact_relationship
            ELSE NULL::text
        END AS emergency_contact_relationship,
    membership_status,
    join_date,
    household_id,
    profile_photo_url,
    auth_user_id,
        CASE
            WHEN public.is_admin() THEN pastoral_notes
            ELSE NULL::text
        END AS pastoral_notes,
    is_active,
    deleted_at,
    created_by,
    created_at,
    updated_at
   FROM public.members m;


--
-- Name: VIEW members_view; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.members_view IS 'Security barrier + invoker view over members. security_invoker=true ensures RLS of the querying user is applied. Column masking: emergency contact visible to admin or own member row; pastoral notes visible to admin only. All other role-based access decisions are enforced by authorization-service.ts at the application layer — RLS only enforces DB-level floor rules.';


--
-- Name: pastoral_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pastoral_cases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    member_id uuid NOT NULL,
    case_type public.pastoral_case_type NOT NULL,
    title text NOT NULL,
    description text,
    priority public.pastoral_priority DEFAULT 'medium'::public.pastoral_priority NOT NULL,
    status public.pastoral_case_status DEFAULT 'open'::public.pastoral_case_status NOT NULL,
    assigned_to uuid,
    is_private boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: pastoral_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pastoral_visits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    case_id uuid NOT NULL,
    member_id uuid NOT NULL,
    visited_by uuid NOT NULL,
    visit_type public.visit_type NOT NULL,
    visit_date date NOT NULL,
    notes text,
    outcome public.visit_outcome DEFAULT 'positive'::public.visit_outcome NOT NULL,
    next_visit_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: prayer_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    member_id uuid,
    title text NOT NULL,
    description text,
    is_anonymous boolean DEFAULT false NOT NULL,
    status public.prayer_request_status DEFAULT 'active'::public.prayer_request_status NOT NULL,
    is_answered boolean DEFAULT false NOT NULL,
    answered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: push_device_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_device_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    assembly_id uuid NOT NULL,
    device_token text NOT NULL,
    platform text NOT NULL,
    is_active boolean DEFAULT true,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT push_device_tokens_platform_check CHECK ((platform = ANY (ARRAY['ios'::text, 'android'::text, 'web'::text])))
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_key text NOT NULL
);


--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role_permissions IS 'Many-to-many junction between assembly_roles and system_permissions. Multiple roles can share the same permission. Only admin may modify this table. Backend must reject assignment of permissions where is_assignable = false.';


--
-- Name: service_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_attendance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_id uuid NOT NULL,
    member_id uuid NOT NULL,
    status public.attendance_status DEFAULT 'present'::public.attendance_status NOT NULL,
    notes text,
    marked_by uuid,
    marked_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: service_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_id uuid NOT NULL,
    changed_by uuid,
    field_changed text NOT NULL,
    old_value text,
    new_value text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: service_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    group_id uuid,
    title text NOT NULL,
    service_type text NOT NULL,
    recurrence public.recurrence_type DEFAULT 'weekly'::public.recurrence_type NOT NULL,
    day_of_week text,
    start_time time without time zone,
    venue text,
    recurrence_end_date date,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assembly_id uuid NOT NULL,
    template_id uuid,
    group_id uuid,
    title text NOT NULL,
    service_type text NOT NULL,
    service_date date NOT NULL,
    start_time time without time zone,
    venue text,
    headcount integer,
    notes text,
    status public.service_status DEFAULT 'scheduled'::public.service_status NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    CONSTRAINT services_headcount_check CHECK ((headcount >= 0))
);


--
-- Name: storage_signed_url_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_signed_url_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    attachment_id uuid NOT NULL,
    requested_by uuid NOT NULL,
    ip_address text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: system_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_permissions (
    id text NOT NULL,
    description text,
    label text NOT NULL,
    module_name text DEFAULT 'general'::text NOT NULL,
    category text DEFAULT 'General'::text NOT NULL,
    is_assignable boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    key text NOT NULL
);


--
-- Name: TABLE system_permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.system_permissions IS 'Platform-owned permission catalogue. Rows are seeded via migrations only — never created at runtime. Permissions are assigned to assembly_roles via role_permissions. Assemblies may only use is_assignable = true permissions.';


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_profiles (
    id uuid NOT NULL,
    assembly_id uuid NOT NULL,
    full_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL,
    assembly_role_id uuid,
    role text DEFAULT 'member'::text NOT NULL,
    CONSTRAINT user_profiles_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'member'::text])))
);


--
-- Name: TABLE user_profiles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_profiles IS 'Links a Supabase Auth user to their assembly and system role. Source of truth for all RLS helper functions (get_user_role, get_user_assembly_id, is_admin, etc.). Rows are Admin-created — not auto-created on sign-up. Never hard-deleted; deactivation via is_active = false only.';


--
-- Name: COLUMN user_profiles.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profiles.id IS 'Primary key. Must equal auth.users.id for the corresponding Auth account. Not a standalone UUID — cascade-deleted when the Auth user is removed.';


--
-- Name: COLUMN user_profiles.assembly_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profiles.assembly_id IS 'The assembly this user account belongs to. Every RLS policy derives the requesting user''s assembly scope from this column. Enforces IMR-04 (no cross-assembly data access) at the database layer.';


--
-- Name: COLUMN user_profiles.full_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profiles.full_name IS 'User display name. Written to member_audit_log.changed_by context on every audited member change. Does not need to match auth.users metadata.';


--
-- Name: COLUMN user_profiles.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profiles.is_active IS 'Soft-disable flag. Set to false by Admin to deactivate an account. The Supabase Auth session should also be revoked at the same time — RLS alone does not invalidate an existing JWT for an inactive user. All six RLS helper functions filter AND is_active = true, so an inactive user effectively has no role and no assembly access.';


--
-- Name: COLUMN user_profiles.must_change_password; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profiles.must_change_password IS 'True when account was provisioned with a default or custom password.
   Forces a non-dismissable password change screen on first login.
   Cleared to false after the member sets their own password.';


--
-- Name: COLUMN user_profiles.assembly_role_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_profiles.assembly_role_id IS 'Optional FK → assembly_roles(id). The custom role this user holds within their assembly (e.g. Secretary, Treasurer). NULL = no custom role assigned; user is governed by their system role only. Updated by admin via user management. Changing this triggers sync_user_permissions_to_jwt to refresh the JWT.';


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    message_id uuid,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


--
-- Name: messages_2026_07_06; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_06 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: messages_2026_07_07; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_07 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: messages_2026_07_08; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_08 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: messages_2026_07_09; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_09 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: messages_2026_07_10; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_10 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: messages_2026_07_11; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_11 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: messages_2026_07_12; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_07_12 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL)))
);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: -
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


--
-- Name: messages_2026_07_06; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_06 FOR VALUES FROM ('2026-07-06 00:00:00') TO ('2026-07-07 00:00:00');


--
-- Name: messages_2026_07_07; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_07 FOR VALUES FROM ('2026-07-07 00:00:00') TO ('2026-07-08 00:00:00');


--
-- Name: messages_2026_07_08; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_08 FOR VALUES FROM ('2026-07-08 00:00:00') TO ('2026-07-09 00:00:00');


--
-- Name: messages_2026_07_09; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_09 FOR VALUES FROM ('2026-07-09 00:00:00') TO ('2026-07-10 00:00:00');


--
-- Name: messages_2026_07_10; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_10 FOR VALUES FROM ('2026-07-10 00:00:00') TO ('2026-07-11 00:00:00');


--
-- Name: messages_2026_07_11; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_11 FOR VALUES FROM ('2026-07-11 00:00:00') TO ('2026-07-12 00:00:00');


--
-- Name: messages_2026_07_12; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_07_12 FOR VALUES FROM ('2026-07-12 00:00:00') TO ('2026-07-13 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
b04b6bb4-48b8-48ca-9951-e531f54fce8f	\N	bab5d1e8-a2b1-4c25-9b6f-495e0e561f8f	s256	KFGdUPw6wwBDx18gmURjWfVDQ__D7u4gJ92o6fb82m0	google			2026-04-28 18:26:38.8145+00	2026-04-28 18:26:38.8145+00	oauth	\N	\N	http://localhost:3000	\N	\N	f
19201b18-1364-4c98-a875-9a2c73fdbc9d	deed0df7-d6de-404a-853d-0428c4196c9a	4cff56f2-7d04-46f6-93ce-106f0a58c444	s256	LgKaQcJN8o7Mps6LCe_L9XImOrcRn-7KnYWnqIMp1sw	google	ya29.a0AQvPyIMDBA-FeT89sdH2xLSzLF8pGEwUSG7EoqGMs5m7LZqSLm4xLWffwVWxfSV8M1z5i4o7fICX-xaJTFnr-IXnK116cwk-A2-0ei3wqi2d-OGaR1zPS6HOiXvDd9BwvLB_PERN3mQA-LWnU_-AQFiiYNY9ez3UO5DSCfqrSFs6mw5POquZLpT20lL93-xhoNIODHoaCgYKAXkSARASFQHGX2MiW4hAtTmN6mxo5DNcrOMXmw0206		2026-04-28 18:28:25.320687+00	2026-04-28 18:29:58.074203+00	oauth	2026-04-28 18:29:58.074151+00	\N	http://localhost:3000	\N	\N	f
e7098bc3-a68c-4138-8066-02e3f3f50171	\N	811e3d62-9894-4387-a237-0847c25ebd1f	s256	BgEumJUQo--w0v9tKeqR_iQ5D5ANb-vg-ksXI29BQHk	google			2026-04-28 18:36:40.782065+00	2026-04-28 18:36:40.782065+00	oauth	\N	\N	http://localhost:3000	\N	\N	f
6697416c-dc9e-4bd8-92f9-2d8656f96a91	2617ff08-81f1-4171-b309-be69bf22604c	74d30509-530d-484e-87fd-b2bb9bc41a84	s256	xTQ-_EHaG1QmOCAgRgcaWEehWq5u-jMHyZs9lCJUJyQ	recovery			2026-05-06 10:46:05.981921+00	2026-05-06 10:46:05.981921+00	recovery	\N	\N	\N	\N	\N	f
c6b41e81-5d66-4589-9393-b843becde535	\N	7cac603d-e512-4270-b9f6-bf02a9cba074	s256	2SLLYan0XT2a67nmFq14ephxIsZiyZ-m2bvs_X_3wl0	google			2026-05-08 15:55:31.107926+00	2026-05-08 15:55:31.107926+00	oauth	\N	\N	http://localhost:3000	\N	\N	f
10bf4dce-2d02-4a50-b70b-b1b501ed35bf	deed0df7-d6de-404a-853d-0428c4196c9a	31a43df9-1fbc-4aed-b594-b738bc9804eb	s256	D7PzOhDUDmKbZRn7nglMRo94sOodWGG6lADe5pCkY-0	recovery			2026-05-10 08:43:45.22073+00	2026-05-10 08:49:36.409668+00	recovery	2026-05-10 08:49:36.40961+00	\N	\N	\N	\N	f
a99312b0-927f-466a-a013-14ca195d8c54	deed0df7-d6de-404a-853d-0428c4196c9a	a568a0eb-20aa-4e3a-abe9-c530efb7e640	s256	Bz9VeRRKE8NRyQAQje7rMp2YyJ5SGOliIJfZ8tXOcqc	recovery			2026-05-10 09:14:55.441582+00	2026-05-10 09:15:41.576386+00	recovery	2026-05-10 09:15:41.576316+00	\N	\N	\N	\N	f
04ba16e7-eb2b-4ea6-bef7-c6ac0b69def2	deed0df7-d6de-404a-853d-0428c4196c9a	0483b704-1c78-4589-88e9-45a13515f964	s256	in_2yoCUnHc3GQ3RVrAuZEfX_NvGokNEEN15gIkbRKk	recovery			2026-05-10 09:16:02.202225+00	2026-05-10 09:16:39.783203+00	recovery	2026-05-10 09:16:39.783152+00	\N	\N	\N	\N	f
bbec1be4-c023-4731-9287-729cd5556b23	deed0df7-d6de-404a-853d-0428c4196c9a	1b4b1592-d973-4502-95dd-e5713bfca20f	s256	4BrEqwDbuKNoM_3hu6Qm6ULxKnzU-OE78pD6oqoy66I	recovery			2026-05-10 09:24:24.355522+00	2026-05-10 09:24:58.440705+00	recovery	2026-05-10 09:24:58.440649+00	\N	\N	\N	\N	f
9a2d92af-96b0-42a3-89b7-dc4b5b1847c7	deed0df7-d6de-404a-853d-0428c4196c9a	bd2ecc70-a004-4381-bf02-70e09e6fb3d8	s256	F-uNrw5Z-vMlyt1jTjbTHHYJxuFLbE9B5igEZlfGT3k	recovery			2026-05-10 09:43:36.212841+00	2026-05-10 09:44:32.615561+00	recovery	2026-05-10 09:44:32.615489+00	\N	\N	\N	\N	f
e24a4d4e-777b-496d-a956-293719d8e540	deed0df7-d6de-404a-853d-0428c4196c9a	5b20e1dc-08a7-4b93-b0f5-b7bfcb2ded01	s256	IL4a-3OUmHqz4T_ZW8CDqFaTiXJHNfOzinTUkRhTK48	recovery			2026-05-10 09:50:18.157297+00	2026-05-10 09:50:50.440734+00	recovery	2026-05-10 09:50:50.440683+00	\N	\N	\N	\N	f
b1ebf752-084d-4a41-9843-de28c443958d	deed0df7-d6de-404a-853d-0428c4196c9a	bd889fc1-8926-44f4-912b-ff84c2d3c294	s256	8w7LeR5OD-grlt91Z9TdicmIdUSZ0M3dOsaUtuL2ZW8	recovery			2026-05-10 10:01:05.124654+00	2026-05-10 10:01:34.04386+00	recovery	2026-05-10 10:01:34.043803+00	\N	\N	\N	\N	f
7390cc21-e6bc-4f0e-b64b-077493e3100f	deed0df7-d6de-404a-853d-0428c4196c9a	78a3f913-094a-4423-a07f-d3c19ee41e33	s256	lu3MTwJD77bhX-FX1hsRuqU_3PCW4jbYvqopZZfr3YQ	recovery			2026-05-12 18:29:58.110624+00	2026-05-12 18:34:06.081392+00	recovery	2026-05-12 18:34:06.081309+00	\N	\N	\N	\N	f
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
deed0df7-d6de-404a-853d-0428c4196c9a	deed0df7-d6de-404a-853d-0428c4196c9a	{"sub": "deed0df7-d6de-404a-853d-0428c4196c9a", "email": "obboyebossman@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-27 06:36:38.161114+00	2026-04-27 06:36:38.161172+00	2026-04-27 06:36:38.161172+00	a9439631-6f99-481d-8037-1d8b6a888923
101503958035766307836	deed0df7-d6de-404a-853d-0428c4196c9a	{"iss": "https://accounts.google.com", "sub": "101503958035766307836", "name": "Obboye Bossman", "email": "obboyebossman@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocL8Vg8QpQf1Qzd9HOyK_iIgjLdAXi3XpBR8hKbyh1MOZ0ZVnQ=s96-c", "full_name": "Obboye Bossman", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocL8Vg8QpQf1Qzd9HOyK_iIgjLdAXi3XpBR8hKbyh1MOZ0ZVnQ=s96-c", "provider_id": "101503958035766307836", "email_verified": true, "phone_verified": false}	google	2026-04-28 18:29:15.116352+00	2026-04-28 18:29:15.116399+00	2026-04-28 18:29:58.072128+00	e0f42869-aefd-416b-8adc-b9025d648e23
d5d4e4b9-30c8-4e94-b32d-23af008c93c0	d5d4e4b9-30c8-4e94-b32d-23af008c93c0	{"sub": "d5d4e4b9-30c8-4e94-b32d-23af008c93c0", "email": "abless024@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-05-26 05:31:35.999359+00	2026-05-26 05:31:35.999418+00	2026-05-26 05:31:35.999418+00	219e526f-1c32-4ee1-ad0a-3bd59b391673
58a36986-b2fa-4e36-8314-4cd4a5eec5de	58a36986-b2fa-4e36-8314-4cd4a5eec5de	{"sub": "58a36986-b2fa-4e36-8314-4cd4a5eec5de", "phone": "23353907475", "email_verified": false, "phone_verified": false}	phone	2026-05-26 19:17:08.791825+00	2026-05-26 19:17:08.791876+00	2026-05-26 19:17:08.791876+00	b695e0fb-047d-46a6-aa17-3a59ae348566
3a316d19-9416-43b3-a10b-2ec52522c7f1	3a316d19-9416-43b3-a10b-2ec52522c7f1	{"sub": "3a316d19-9416-43b3-a10b-2ec52522c7f1", "email": "stevmmre@yahoo.com", "email_verified": false, "phone_verified": false}	email	2026-05-31 08:23:10.899233+00	2026-05-31 08:23:10.899299+00	2026-05-31 08:23:10.899299+00	3c65f45d-9d2b-4168-b4a2-ce4eaea26470
3a316d19-9416-43b3-a10b-2ec52522c7f1	3a316d19-9416-43b3-a10b-2ec52522c7f1	{"sub": "3a316d19-9416-43b3-a10b-2ec52522c7f1", "phone": "233249439129", "email_verified": false, "phone_verified": false}	phone	2026-05-31 08:23:10.904355+00	2026-05-31 08:23:10.904413+00	2026-05-31 08:23:10.904413+00	a731187a-7220-4c51-98a1-6c004ab3da54
fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	{"sub": "fb71f8ba-67d0-4217-8c2e-cd4ae284ced5", "email": "benjaminkwekumensah@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-05-31 10:45:20.341334+00	2026-05-31 10:45:20.34139+00	2026-05-31 10:45:20.34139+00	016fedca-da34-46ca-bb86-f27f3428bb57
fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	{"sub": "fb71f8ba-67d0-4217-8c2e-cd4ae284ced5", "phone": "233557887388", "email_verified": false, "phone_verified": false}	phone	2026-05-31 10:45:20.346296+00	2026-05-31 10:45:20.346379+00	2026-05-31 10:45:20.346379+00	439fcebb-f301-4c71-b612-7f759312ef84
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
79876433-2d3e-47c7-bdcf-c4ebf24a197e	2026-06-13 21:01:55.001953+00	2026-06-13 21:01:55.001953+00	password	47f30bb8-b1b6-484a-99ab-a6184e31cf75
d024ed18-5f2e-44ff-9f3b-29390c6d4bba	2026-06-20 11:58:01.214367+00	2026-06-20 11:58:01.214367+00	password	35ac2edf-eed1-4c25-adb9-ae956056ab0a
5eaed1e2-9d26-4d50-8a56-b91b56669cd5	2026-06-21 07:14:28.693239+00	2026-06-21 07:14:28.693239+00	password	964d114f-31e7-4e15-8ae9-36797290583a
eac0b0cf-35e9-4ebd-8e32-f73834823324	2026-06-28 10:35:14.891296+00	2026-06-28 10:35:14.891296+00	password	b01263a9-06a4-47d0-9b9b-c8ba8c86e0cd
4224983d-dacb-4bcb-be86-0d1ffbda9aa6	2026-06-29 15:04:53.436634+00	2026-06-29 15:04:53.436634+00	password	07f50031-f26f-4405-803d-454a38d9a4f0
c502ae79-a381-41dc-a274-ff0c2ed51542	2026-07-01 23:51:35.936726+00	2026-07-01 23:51:35.936726+00	password	a7e81dde-524c-448e-8810-e547a9995ab3
dce783be-31db-492c-8b25-a9873c992a7d	2026-07-06 04:12:00.519347+00	2026-07-06 04:12:00.519347+00	password	2633f524-ea3b-427d-b801-f4aa1a54eca0
e06b50b5-71c4-487b-bb54-394dbda07ce4	2026-07-09 15:21:12.604861+00	2026-07-09 15:21:12.604861+00	password	5298c59a-2f91-44bf-8962-af3d900e0bca
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
cedf118b-a81d-4ba0-90e5-f29b4de4a10f	deed0df7-d6de-404a-853d-0428c4196c9a		totp	unverified	2026-05-18 19:44:09.765426+00	2026-05-18 19:44:09.765426+00	6HIPJF22PARF57TC7BUJ4GOBL5XLDYOW	\N	\N	\N	\N	\N
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	568	4hu3phw5ihea	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-06-20 11:58:01.164001+00	2026-06-20 11:58:01.164001+00	\N	d024ed18-5f2e-44ff-9f3b-29390c6d4bba
00000000-0000-0000-0000-000000000000	570	g7fcqrxh4nep	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-06-21 10:42:52.760814+00	2026-06-21 11:49:05.292761+00	4gibt2ws4773	5eaed1e2-9d26-4d50-8a56-b91b56669cd5
00000000-0000-0000-0000-000000000000	572	4fkwmbcy5ipr	3a316d19-9416-43b3-a10b-2ec52522c7f1	t	2026-06-21 22:28:12.63286+00	2026-06-22 09:27:27.539515+00	dmy5nmhf22c2	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	574	mnn2b5enan7t	3a316d19-9416-43b3-a10b-2ec52522c7f1	t	2026-06-23 22:43:10.654944+00	2026-06-27 23:36:32.50361+00	qtr7nbuycxjd	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	576	diyp5kbn4bvr	3a316d19-9416-43b3-a10b-2ec52522c7f1	t	2026-06-28 00:34:36.759473+00	2026-06-28 01:33:04.037296+00	q6ssbbhpvxqb	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	578	du6qyd4ztct6	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-06-28 10:35:14.854146+00	2026-06-28 12:13:30.476494+00	\N	eac0b0cf-35e9-4ebd-8e32-f73834823324
00000000-0000-0000-0000-000000000000	580	pyhxf2ly7noa	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-06-29 15:04:53.397782+00	2026-06-29 15:04:53.397782+00	\N	4224983d-dacb-4bcb-be86-0d1ffbda9aa6
00000000-0000-0000-0000-000000000000	582	p5d4nif3c5hm	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-07-02 00:56:01.767215+00	2026-07-02 08:00:27.115229+00	6f6pcqk5gdyo	c502ae79-a381-41dc-a274-ff0c2ed51542
00000000-0000-0000-0000-000000000000	584	fs4tfb7d7bfr	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-07-03 04:57:33.681022+00	2026-07-03 04:57:33.681022+00	y3naqfpf6vtc	c502ae79-a381-41dc-a274-ff0c2ed51542
00000000-0000-0000-0000-000000000000	586	tifsmjfzjw55	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-07-09 07:48:08.124869+00	2026-07-09 07:48:08.124869+00	oqelnv5vxmoz	eac0b0cf-35e9-4ebd-8e32-f73834823324
00000000-0000-0000-0000-000000000000	569	4gibt2ws4773	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-06-21 07:14:28.653828+00	2026-06-21 10:42:52.739023+00	\N	5eaed1e2-9d26-4d50-8a56-b91b56669cd5
00000000-0000-0000-0000-000000000000	571	bsxl73pgy63a	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-06-21 11:49:05.30271+00	2026-06-21 11:49:05.30271+00	g7fcqrxh4nep	5eaed1e2-9d26-4d50-8a56-b91b56669cd5
00000000-0000-0000-0000-000000000000	562	dmy5nmhf22c2	3a316d19-9416-43b3-a10b-2ec52522c7f1	t	2026-06-13 21:01:54.999426+00	2026-06-21 22:28:12.609412+00	\N	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	573	qtr7nbuycxjd	3a316d19-9416-43b3-a10b-2ec52522c7f1	t	2026-06-22 09:27:27.558047+00	2026-06-23 22:43:10.636495+00	4fkwmbcy5ipr	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	575	q6ssbbhpvxqb	3a316d19-9416-43b3-a10b-2ec52522c7f1	t	2026-06-27 23:36:32.530481+00	2026-06-28 00:34:36.741376+00	mnn2b5enan7t	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	577	njj7ky665odt	3a316d19-9416-43b3-a10b-2ec52522c7f1	f	2026-06-28 01:33:04.052511+00	2026-06-28 01:33:04.052511+00	diyp5kbn4bvr	79876433-2d3e-47c7-bdcf-c4ebf24a197e
00000000-0000-0000-0000-000000000000	581	6f6pcqk5gdyo	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-07-01 23:51:35.886258+00	2026-07-02 00:56:01.745945+00	\N	c502ae79-a381-41dc-a274-ff0c2ed51542
00000000-0000-0000-0000-000000000000	583	y3naqfpf6vtc	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-07-02 08:00:27.138164+00	2026-07-03 04:57:33.661716+00	p5d4nif3c5hm	c502ae79-a381-41dc-a274-ff0c2ed51542
00000000-0000-0000-0000-000000000000	585	gdlecsgay5ol	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-07-06 04:12:00.462079+00	2026-07-06 04:12:00.462079+00	\N	dce783be-31db-492c-8b25-a9873c992a7d
00000000-0000-0000-0000-000000000000	579	oqelnv5vxmoz	deed0df7-d6de-404a-853d-0428c4196c9a	t	2026-06-28 12:13:30.497231+00	2026-07-09 07:48:08.099676+00	du6qyd4ztct6	eac0b0cf-35e9-4ebd-8e32-f73834823324
00000000-0000-0000-0000-000000000000	587	6e73bhwohe6o	deed0df7-d6de-404a-853d-0428c4196c9a	f	2026-07-09 15:21:12.5534+00	2026-07-09 15:21:12.5534+00	\N	e06b50b5-71c4-487b-bb54-394dbda07ce4
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
c502ae79-a381-41dc-a274-ff0c2ed51542	deed0df7-d6de-404a-853d-0428c4196c9a	2026-07-01 23:51:35.839762+00	2026-07-03 04:57:33.72273+00	\N	aal1	\N	2026-07-03 04:57:33.72261	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	102.176.94.100	\N	\N	\N	\N	\N
eac0b0cf-35e9-4ebd-8e32-f73834823324	deed0df7-d6de-404a-853d-0428c4196c9a	2026-06-28 10:35:14.804006+00	2026-07-09 07:48:08.155241+00	\N	aal1	\N	2026-07-09 07:48:08.155135	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	154.161.156.45	\N	\N	\N	\N	\N
e06b50b5-71c4-487b-bb54-394dbda07ce4	deed0df7-d6de-404a-853d-0428c4196c9a	2026-07-09 15:21:12.503926+00	2026-07-09 15:21:12.503926+00	\N	aal1	\N	\N	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:149.0) Gecko/20100101 Firefox/149.0	169.239.248.150	\N	\N	\N	\N	\N
5eaed1e2-9d26-4d50-8a56-b91b56669cd5	deed0df7-d6de-404a-853d-0428c4196c9a	2026-06-21 07:14:28.61866+00	2026-06-21 11:49:05.324288+00	\N	aal1	\N	2026-06-21 11:49:05.324176	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:151.0) Gecko/20100101 Firefox/151.0	41.204.44.204	\N	\N	\N	\N	\N
79876433-2d3e-47c7-bdcf-c4ebf24a197e	3a316d19-9416-43b3-a10b-2ec52522c7f1	2026-06-13 21:01:54.990849+00	2026-06-28 01:33:04.077417+00	\N	aal1	\N	2026-06-28 01:33:04.077297	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	154.161.170.233	\N	\N	\N	\N	\N
4224983d-dacb-4bcb-be86-0d1ffbda9aa6	deed0df7-d6de-404a-853d-0428c4196c9a	2026-06-29 15:04:53.358392+00	2026-06-29 15:04:53.358392+00	\N	aal1	\N	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	102.214.88.222	\N	\N	\N	\N	\N
dce783be-31db-492c-8b25-a9873c992a7d	deed0df7-d6de-404a-853d-0428c4196c9a	2026-07-06 04:12:00.432746+00	2026-07-06 04:12:00.432746+00	\N	aal1	\N	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	154.161.158.152	\N	\N	\N	\N	\N
d024ed18-5f2e-44ff-9f3b-29390c6d4bba	deed0df7-d6de-404a-853d-0428c4196c9a	2026-06-20 11:58:01.123943+00	2026-06-20 11:58:01.123943+00	\N	aal1	\N	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	102.176.95.225	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	authenticated	authenticated	benjaminkwekumensah@gmail.com	$2a$10$ztjspZ71UtM72nKlueLTzelt9w2QBGxV65e0oy0.KIeXkHU5Ha3TK	2026-05-31 10:45:20.350959+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email", "phone"], "assembly_id": "1777703f-d720-48e5-9543-eba8d27e6a15", "permissions": ["attendance:mark", "finance.offerings.edit", "finance.offerings.view", "financials:view", "financials:write", "sermon:edit", "households.create", "households.edit", "households.view", "member:edit", "member:view_all", "members.create", "members.deactivate", "members.edit", "members.import", "members.view", "reports.export", "reports.view"]}	{"email_verified": true}	\N	2026-05-31 10:45:20.331767+00	2026-05-31 10:45:20.357435+00	233557887388	2026-05-31 10:45:20.357208+00			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	deed0df7-d6de-404a-853d-0428c4196c9a	authenticated	authenticated	obboyebossman@gmail.com	$2a$10$JY7ooYOA0Yj41WiYaCm.oe6EUjdDw6pIqoTGnlPOazNoUtkzL9X1W	2026-04-27 06:36:38.175475+00	\N		\N		2026-05-12 18:29:58.137361+00			\N	2026-07-09 15:21:12.502745+00	{"provider": "email", "providers": ["email", "google"]}	{"iss": "https://accounts.google.com", "sub": "101503958035766307836", "name": "Obboye Bossman", "email": "obboyebossman@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocL8Vg8QpQf1Qzd9HOyK_iIgjLdAXi3XpBR8hKbyh1MOZ0ZVnQ=s96-c", "full_name": "Obboye Bossman", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocL8Vg8QpQf1Qzd9HOyK_iIgjLdAXi3XpBR8hKbyh1MOZ0ZVnQ=s96-c", "provider_id": "101503958035766307836", "email_verified": true, "phone_verified": false}	\N	2026-04-27 06:36:38.143943+00	2026-07-09 15:21:12.577646+00	+233593529509	2026-05-27 07:45:12.936116+00			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	58a36986-b2fa-4e36-8314-4cd4a5eec5de	authenticated	authenticated	\N	$2a$10$mFiOUSkeXP3LesLs2R4E.uy068iGSwMpQASN4C7P2D1x/drrS8ydq	\N	\N		\N		\N			\N	\N	{"provider": "phone", "providers": ["phone"]}	{}	\N	2026-05-26 19:17:08.78248+00	2026-05-26 19:17:08.802165+00	23353907475	2026-05-26 19:17:08.801816+00			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d5d4e4b9-30c8-4e94-b32d-23af008c93c0	authenticated	authenticated	abless024@gmail.com	$2a$10$qZXzxAhbzb0kPseYKwCtLekTUKSKwtPKa8mN6c7pIyz6JOVYGwTjm	2026-05-26 05:31:36.003245+00	\N		\N		\N			\N	2026-05-26 19:29:12.197708+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-05-26 05:31:35.968698+00	2026-05-26 20:49:30.295591+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3a316d19-9416-43b3-a10b-2ec52522c7f1	authenticated	authenticated	stevmmre@yahoo.com	$2a$10$7CWm.r45nyHs.pzsPVSYQuHcv5qEqYOz34gpHKPKIvTc4mv5nU5B6	2026-05-31 08:23:10.909031+00	\N		\N		\N			\N	2026-06-13 21:01:54.989587+00	{"provider": "email", "providers": ["email", "phone"], "assembly_id": "1777703f-d720-48e5-9543-eba8d27e6a15", "permissions": []}	{"email_verified": true}	\N	2026-05-31 08:23:10.877888+00	2026-06-28 01:33:04.063349+00	233249439129	2026-05-31 08:23:10.913057+00			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: announcement_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcement_posts (id, assembly_id, title, body, target_group_ids, is_pinned, visible_from, visible_until, posted_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: assemblies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assemblies (id, name, assembly_code, address, digital_address, is_active, created_at, updated_at, default_member_password) FROM stdin;
1777703f-d720-48e5-9543-eba8d27e6a15	Assakae Central Assembly	GH-ASSAK	Assakae, Takoradi, Western Region, Ghana	\N	t	2026-04-28 14:25:28.979893+00	2026-05-25 23:19:41.972018+00	Qwerty12345
\.


--
-- Data for Name: assembly_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assembly_roles (id, assembly_id, name, description, created_at, updated_at, is_active, is_system) FROM stdin;
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	1777703f-d720-48e5-9543-eba8d27e6a15	Secretary	\N	2026-05-31 10:46:22.103781+00	2026-05-31 10:46:22.103781+00	t	f
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	1777703f-d720-48e5-9543-eba8d27e6a15	Pastor	Spiritual oversight and pastoral care, with administrative access to member records and ministry reporting.	2026-05-26 21:11:21.05171+00	2026-05-26 21:11:21.05171+00	t	f
\.


--
-- Data for Name: assembly_storage_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assembly_storage_usage (id, assembly_id, snapshot_month, supabase_bytes, r2_warm_bytes, r2_cold_bytes, sms_segments_sent, whatsapp_msgs_sent, created_at) FROM stdin;
\.


--
-- Data for Name: communication_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_attachments (id, assembly_id, thread_message_id, campaign_id, storage_tier, storage_provider, storage_bucket, storage_path, public_url, mime_type, file_size_bytes, original_filename, checksum, duration_seconds, waveform_data, normalised_path, transcription_text, transcription_status, is_sensitive, virus_scan_status, uploaded_by, archive_after, purge_after, archived_at, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: communication_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_campaigns (id, assembly_id, template_id, title, channel, audience_type, audience_ids, trigger_type, status, scheduled_at, sent_at, total_recipients, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: communication_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_messages (id, campaign_id, assembly_id, member_id, channel, body_resolved, status, provider, external_ref, provider_status, failed_reason, cost_units, delivered_at, read_at, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: communication_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_preferences (id, member_id, assembly_id, channel, category, opted_in, updated_at) FROM stdin;
\.


--
-- Data for Name: communication_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_templates (id, assembly_id, title, body, channel, category, variables, whatsapp_template_name, is_active, created_by, created_at, updated_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: communication_thread_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_thread_messages (id, thread_id, sender_id, message_type, body, storage_tier, created_at, edited_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: communication_thread_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_thread_participants (id, thread_id, member_id, role, joined_at, left_at, last_read_at) FROM stdin;
\.


--
-- Data for Name: communication_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_threads (id, assembly_id, subject, is_pastoral, is_sensitive, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: communication_trigger_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_trigger_rules (id, assembly_id, trigger_event, template_id, channels, days_offset, offset_direction, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: finance_budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_budgets (id, assembly_id, category_id, period, year, month, quarter, budgeted_amount, actual_amount, notes, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: finance_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_categories (id, assembly_id, name, category_type, description, is_active, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: finance_pledges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_pledges (id, assembly_id, member_id, pledge_name, total_amount, amount_paid, currency, start_date, end_date, status, notes, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: finance_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_transactions (id, assembly_id, category_id, member_id, transaction_type, amount, currency, payment_method, reference_number, transaction_date, description, service_id, group_id, pledge_id, recorded_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_members (id, group_id, member_id, role, joined_at, left_at, is_active, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, assembly_id, name, group_type, description, is_active, leader_id, created_by, created_at, deleted_at, deleted_by) FROM stdin;
c71b3baf-f66a-44b5-8f74-2ee05058a977	1777703f-d720-48e5-9543-eba8d27e6a15	Peace	department	\N	t	\N	\N	2026-06-07 12:58:48.838229+00	\N	\N
a5d7b605-da7e-47d7-93d5-286279d9b5ae	1777703f-d720-48e5-9543-eba8d27e6a15	Pastor	department	\N	t	\N	\N	2026-06-07 12:59:04.633352+00	\N	\N
3c3dbe48-7248-4299-9791-b735ea8ae397	1777703f-d720-48e5-9543-eba8d27e6a15	Love	department	\N	t	\N	\N	2026-06-07 12:59:16.326737+00	\N	\N
94e63394-88f2-4129-88c4-6697da7b935d	1777703f-d720-48e5-9543-eba8d27e6a15	Hope	department	\N	t	\N	\N	2026-06-07 12:59:26.935848+00	\N	\N
c13dc1f1-215e-453e-9e61-e26727d2a35b	1777703f-d720-48e5-9543-eba8d27e6a15	Youth	department	\N	t	\N	\N	2026-06-07 13:00:45.685754+00	\N	\N
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.households (id, assembly_id, family_name, address, primary_contact_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_audit_log (id, member_id, assembly_id, changed_by, field_changed, old_value, new_value, changed_at) FROM stdin;
45d3db69-7829-4c49-a8e1-35bf26016f9f	37e8593c-2e6a-4ce6-b029-6693f51bd281	1777703f-d720-48e5-9543-eba8d27e6a15	\N	whatsapp_number	\N	+233593529509	2026-05-26 21:01:20.730201+00
22824453-2e01-4589-9f16-075b6d784c55	b668ef4c-b006-4268-a13a-4627e6d4cd04	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	occupation	\N	Catering	2026-05-28 04:05:57.530048+00
623db60c-53c9-474f-b5c2-fea6d6d22dc9	3309bcf1-5d6c-4fac-80dd-6c4c9e49a48c	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	title	\N	Mr.	2026-05-31 11:17:47.904262+00
a664dabd-380e-4c9f-bfbe-28ff6f0dc42c	3309bcf1-5d6c-4fac-80dd-6c4c9e49a48c	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_name	\N	Rev. Stephen Ankomah	2026-05-31 11:17:47.904262+00
e70d09d8-0ee2-439d-b407-0b21bb3694b0	3309bcf1-5d6c-4fac-80dd-6c4c9e49a48c	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_phone	\N	024943912[	2026-05-31 11:17:47.904262+00
16f823a0-4238-4d91-ad41-531bd4eb1e11	3309bcf1-5d6c-4fac-80dd-6c4c9e49a48c	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_relationship	\N	parent	2026-05-31 11:17:47.904262+00
8e79f708-ae74-4086-bdcf-74ad75c940e5	37e8593c-2e6a-4ce6-b029-6693f51bd281	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	profile_photo_url	\N	https://cyjkjzcthbpkufbsyosz.supabase.co/storage/v1/object/public/member-photos/deed0df7-d6de-404a-853d-0428c4196c9a/profile_1780821453772_86782.jpg	2026-06-07 08:37:35.587901+00
38136ef2-9426-495a-a491-b92b558c2605	fdd9b955-fbbd-45fe-b61b-1249a3f6a321	1777703f-d720-48e5-9543-eba8d27e6a15	3a316d19-9416-43b3-a10b-2ec52522c7f1	emergency_contact_relationship	spouse	\N	2026-06-13 21:07:42.315344+00
d90e0e6c-7441-498c-97fe-4d514a1d5534	fdd9b955-fbbd-45fe-b61b-1249a3f6a321	1777703f-d720-48e5-9543-eba8d27e6a15	3a316d19-9416-43b3-a10b-2ec52522c7f1	profile_photo_url	\N	https://cyjkjzcthbpkufbsyosz.supabase.co/storage/v1/object/public/member-photos/3a316d19-9416-43b3-a10b-2ec52522c7f1/profile_1781384860245_1001076624.jpg	2026-06-13 21:07:42.315344+00
bea08a40-c5dc-4091-87d6-3df34e0e0561	85abad2e-4def-4651-825e-35120b6694d7	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	join_date	2026-06-15	\N	2026-06-15 15:23:48.938265+00
9b1dc915-c7ae-4dd9-88c8-86847e51c2ab	85abad2e-4def-4651-825e-35120b6694d7	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	marital_status	\N	married	2026-06-15 15:25:31.704622+00
94c3692f-c365-43a0-b60e-721da93bdafc	d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	primary_phone	233557096865	557096865	2026-06-21 11:01:01.901344+00
14c76b13-b97e-48ed-90b4-fceb645cfa54	d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	whatsapp_number	233557096865	557096865	2026-06-21 11:01:01.901344+00
43d51d28-082a-4f04-9278-0be242baf5ae	d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_phone	233546992325	546992325	2026-06-21 11:01:01.901344+00
3e18ebda-9360-441b-a7a7-90819417b267	d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	primary_phone	557096865	233557096865	2026-06-21 11:03:21.765867+00
430545f6-58f3-477e-85bb-8ba708fe4cc7	d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	whatsapp_number	557096865	233557096865	2026-06-21 11:03:21.765867+00
99d8df36-6dd5-466c-87f0-7476fca8d25f	d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_phone	546992325	233546992325	2026-06-21 11:03:21.765867+00
765ba336-79bb-4242-918b-2cf05d5a23d1	1448c373-35fc-4535-af71-2de10b315384	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	primary_phone	535099715	233535099715	2026-06-21 11:18:56.43243+00
46435a5d-8c39-469a-827c-e0623a02cb6d	1448c373-35fc-4535-af71-2de10b315384	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	secondary_phone	208940960	233208940960	2026-06-21 11:18:56.43243+00
74488f13-e17c-4725-9bf2-8bbcf4520300	1448c373-35fc-4535-af71-2de10b315384	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	whatsapp_number	535099715	233535099715	2026-06-21 11:18:56.43243+00
0615e784-69af-464f-bc7d-e450f77a4066	1448c373-35fc-4535-af71-2de10b315384	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_phone	534267152	233534267152	2026-06-21 11:18:56.43243+00
cdad3c2c-eb95-4f70-8d30-1b15dc244f61	d90bddbf-a476-4e4d-a247-31e11b34554d	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	primary_phone	2424759670	2332424759670	2026-06-21 11:19:44.381917+00
c8254723-45b1-40e4-b922-ca264e7ad94f	d90bddbf-a476-4e4d-a247-31e11b34554d	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	whatsapp_number	2424759670	2332424759670	2026-06-21 11:19:44.381917+00
bd8e4fef-adc8-4655-a696-bee6b379fd89	d90bddbf-a476-4e4d-a247-31e11b34554d	1777703f-d720-48e5-9543-eba8d27e6a15	deed0df7-d6de-404a-853d-0428c4196c9a	emergency_contact_phone	548063276	233548063276	2026-06-21 11:19:44.381917+00
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, assembly_id, membership_number, first_name, last_name, date_of_birth, gender, marital_status, primary_phone, email, physical_address, occupation, facebook_url, whatsapp_number, instagram_url, emergency_contact_name, emergency_contact_phone, emergency_contact_relationship, membership_status, join_date, household_id, profile_photo_url, pastoral_notes, is_active, deleted_at, created_by, created_at, updated_at, auth_user_id, other_names, secondary_phone, title) FROM stdin;
37e8593c-2e6a-4ce6-b029-6693f51bd281	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00001	Abraham	Bossman	2004-07-02	male	single	+233593529509	obboyebossman@gmail.com	Assakae	Student	\N	+233593529509	\N	Isaac	+233593228102	Sibling	active	\N	\N	https://cyjkjzcthbpkufbsyosz.supabase.co/storage/v1/object/public/member-photos/deed0df7-d6de-404a-853d-0428c4196c9a/profile_1780821453772_86782.jpg	\N	t	\N	\N	2026-05-26 20:59:58.460092+00	2026-06-07 08:37:35.587901+00	deed0df7-d6de-404a-853d-0428c4196c9a	Nhyiraba Obboye	\N	\N
fdd9b955-fbbd-45fe-b61b-1249a3f6a321	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00002	Stephen	Ankomah	\N	male	married	+233249439129	stevmmre@yahoo.com	\N	Rev. Minister	\N	\N	\N	\N	+233543371849	\N	active	2026-05-27	\N	https://cyjkjzcthbpkufbsyosz.supabase.co/storage/v1/object/public/member-photos/3a316d19-9416-43b3-a10b-2ec52522c7f1/profile_1781384860245_1001076624.jpg	\N	t	\N	\N	2026-05-27 21:51:01.626838+00	2026-06-13 21:07:42.315344+00	3a316d19-9416-43b3-a10b-2ec52522c7f1	\N	\N	Rev.
205c48e7-e8b0-4a81-998d-0e70ecaed30d	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00056	Emmanuel	Quaido	1985-08-02	male	married	243612638	\N	Assakae - After Bridge	Business	\N	243612638	\N	Colonius Quaidoo	242775993	Other	active	\N	\N	\N	\N	t	\N	\N	2026-06-14 08:49:08.919372+00	2026-06-14 08:49:09.764934+00	\N	\N	242694049	\N
e13271c1-988e-4ebd-b2fd-160991ab79af	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00067	Rebecca	Cobbinah	1982-07-03	male	married	233578980332	augustinecudjoe847@gmail.com	Assakae	Trader	\N	233277679787	\N	\N	\N	\N	active	2012-01-01	\N	\N	\N	t	\N	\N	2026-06-21 10:50:29.812257+00	2026-06-21 10:50:30.903104+00	\N	\N	233277679787	Mrs.
4c29e510-bfdb-4364-aca5-c1972c765543	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00075	Nicholas	Asiedu	1997-12-03	male	\N	233599542164	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-06-21 11:59:07.390356+00	2026-06-21 11:59:08.296511+00	\N	\N	\N	\N
0cda0506-781e-4e77-8ae0-44fec5b02319	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00018	Juliana	Obboye	\N	female	\N	\N	\N	Western Region	Farming	\N	\N	\N	Christina Bossman	+233242833301	Other	active	\N	\N	\N	\N	t	\N	\N	2026-05-29 04:36:02.943987+00	2026-05-29 04:36:02.943987+00	\N	\N	\N	\N
2d7ef5df-60cb-4010-b3b3-f52713f229b4	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00005	Moses	Appiah	2006-06-08	male	single	+233555056540	mosesaduappiah657@gmail.com	Assakae	Student	\N	+233572201033	\N	Benjamin Appiah	+233544858920	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 04:16:30.557032+00	2026-05-28 04:16:32.68814+00	\N	Adu	\N	\N
b19a32a9-8216-463e-a0dc-1765a17bfe08	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00006	Esther	Eshun	1999-01-21	female	single	+233247614162	estereshun282@gmail.com	Assakae	Teacher	\N	+23324 761 4162	\N	\N	+233591565145	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 04:21:09.52808+00	2026-05-28 04:21:11.615018+00	\N	\N	\N	\N
b668ef4c-b006-4268-a13a-4627e6d4cd04	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00003	Ama	Queen	1981-11-14	female	single	+233557813105	\N	\N	Catering	\N	233557813105	\N	Samuel Amoah	233595762184	friend	active	2025-05-01	\N	\N	\N	t	\N	\N	2026-05-28 04:02:42.476621+00	2026-05-28 04:05:57.530048+00	\N	\N	\N	\N
d0b63874-2850-479a-8f6e-e6fb486b5a79	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00004	Esther	Eshun	\N	female	\N	+23327465506	\N	Assakae	\N	\N	+23327 465 506	\N	\N	+233559911376	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 04:10:33.243205+00	2026-05-28 04:10:35.329189+00	\N	\N	\N	\N
dea2616d-5bd5-4895-8ebd-59911402e5ff	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00007	Moses	Diidonoba	2012-02-23	male	single	+233538099870	\N	Assakae	Student	\N	\N	\N	\N	+233242308121	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 04:26:44.651375+00	2026-05-28 04:26:46.693161+00	\N	Adu	+233206119857	\N
c9175d10-338e-48d0-8224-262e0367f541	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00008	Lucus	Eshun	2000-12-27	male	single	+233257595511	lukumasahkweky16@gmail.com	Assakae	\N	\N	\N	\N	Theophilus Ansah	+233559911376	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 04:33:19.435565+00	2026-05-28 04:33:21.224944+00	\N	Kweku	\N	\N
f18d0e9f-e42b-400d-8fa5-76e88499d363	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00009	Mary	Arthur	1995-12-11	female	married	+233538148013	\N	Assakae	Trading	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 04:43:30.617021+00	2026-05-28 04:43:32.158428+00	\N	\N	\N	\N
eebebc2f-96e9-4a6e-b517-62dfa089c304	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00057	Grace	Gaabin	\N	female	\N	\N	\N	\N	Trader	\N	\N	\N	\N	\N	\N	active	2026-06-15	\N	\N	\N	t	\N	\N	2026-06-15 15:21:29.337635+00	2026-06-15 15:21:31.222333+00	\N	\N	\N	\N
d737ffad-db2a-4268-b602-4a2127a91ef2	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00068	Stephen	Cobbinah	1984-07-07	male	married	233557096865	\N	Assakae	Driver	\N	233557096865	\N	Mary Mensah	233546992325	Spouse	active	2004-03-15	\N	\N	\N	t	\N	\N	2026-06-21 10:55:31.745806+00	2026-06-21 11:03:21.765867+00	\N	\N	\N	Mr.
85abad2e-4def-4651-825e-35120b6694d7	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00058	Philomina	Arthur	1997-07-18	female	married	5939531533	\N	Assakae	Fashion	\N	5939531533	\N	Mr. Eric Abekah	5311615289	\N	active	\N	\N	\N	\N	t	\N	\N	2026-06-15 15:23:06.374223+00	2026-06-15 15:25:31.704622+00	\N	\N	\N	\N
ad295379-c5cf-4afc-8c2b-a051b3ef5c0a	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00069	Naomi	Afetsi	1998-02-28	female	single	544906862	\N	Assakae	Midwife	\N	544906862	\N	Emmanuel Quayson	247879682	Spouse	active	2025-05-01	\N	\N	\N	t	\N	\N	2026-06-21 11:00:14.791357+00	2026-06-21 11:00:15.541218+00	\N	\N	\N	\N
604d6bb2-095a-4ad1-a9ce-74ec2e232e05	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00059	Edna	Quayson	2011-03-21	female	single	503441354	ednaquayson@gmail.com	Assakae	Student	\N	\N	\N	Florence Assafuah	503381858	Parent	active	\N	\N	\N	\N	t	\N	\N	2026-06-15 15:39:00.417252+00	2026-06-15 15:39:01.278725+00	\N	Adu	\N	\N
69935240-c6be-4cb5-9be1-237f50e15842	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00061	Florince	Cobbinah	1988-12-29	female	married	555497073	\N	Assakae	Hair Dressing	\N	555497073	\N	Mr. Robert	234302802	Spouse	active	2021-01-01	\N	\N	\N	t	\N	\N	2026-06-15 15:39:20.917168+00	2026-06-15 15:39:22.016879+00	\N	\N	\N	\N
b6cf2c5d-3985-4b4c-89e4-527bad8cc12c	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00010	Bernard	Aboagye	1993-12-16	male	single	+233248153589	\N	Adientem - Dr. Tawiah Hospital	Mason	\N	+233509016414	\N	Cecilia	+233538249108	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 11:40:46.817451+00	2026-05-28 11:40:49.376614+00	\N	\N	\N	\N
01afbb3b-fe50-482e-8882-11fec362a8e7	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00070	Elizabeth	Gyan	\N	female	married	559105621	\N	\N	Trader	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-06-21 11:17:35.311756+00	2026-06-21 11:17:36.142661+00	\N	Esi	\N	Mrs.
1448c373-35fc-4535-af71-2de10b315384	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00072	Emmanuel	Koomson	1995-09-20	male	single	233535099715	emmanuelkoomsom38@gmail.com	Assake	Trader	\N	233535099715	\N	Samuel Koomson	233534267152	Sibling	active	\N	\N	\N	\N	t	\N	\N	2026-06-21 11:17:51.404724+00	2026-06-21 11:18:56.43243+00	\N	\N	233208940960	\N
9e9bed3d-2b11-4201-8f33-a0394e5cd453	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00046	Hannah	Peasah	1980-04-14	female	married	\N	\N	No. 33/1, Assakae, Western Region	Hair Dresser	\N	\N	\N	\N	\N	\N	active	2002-05-07	\N	\N	\N	t	\N	\N	2026-05-29 04:36:02.943987+00	2026-05-29 04:36:02.943987+00	\N	\N	\N	\N
009cb3d1-5a78-4cb4-9335-399f733518f3	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00060	Beatrice	Oppong	1993-10-25	female	married	596338877	\N	Assakae	Hair Dressing	\N	\N	\N	Maxwell Cudjoe	254066176	Spouse	active	2026-01-01	\N	\N	\N	t	\N	\N	2026-06-15 15:39:13.186257+00	2026-06-15 15:39:13.802179+00	\N	\N	\N	\N
d90bddbf-a476-4e4d-a247-31e11b34554d	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00071	Gifty	Anokye	1972-07-30	female	\N	2332424759670	\N	Assakae	Trading	\N	2332424759670	\N	Collins	233548063276	Other	active	\N	\N	\N	\N	t	\N	\N	2026-06-21 11:17:44.134537+00	2026-06-21 11:19:44.381917+00	\N	\N	\N	\N
23cd89ae-f65a-4f27-8c4c-16a61d1e356f	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00011	Kezia	Mensah	2011-05-10	female	single	+233541615395	\N	Race Course, Western Region	\N	\N	+233541615395	\N	Mensah Emmanuel	+233248964292	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Abena	\N	\N
7863242f-2c01-4078-8b2e-765fea6de16f	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00012	Perpetual	Mensah	2000-05-23	female	single	+233241095712	eourabenainnocent16@gmail.com	Western Region	\N	\N	+233241095712	\N	Mensah Emmanuel	+233243964292	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Abena	\N	\N
10881204-724e-4185-8db8-6a5fb55389fe	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00013	Agnes	Koomson	\N	female	married	+233271128162	\N	Adientem, Western Region	Trader	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
80fabf04-e048-4d84-87b5-76f96b73f1ba	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00014	Mary	Yalley	1983-07-01	female	single	+233256510605	\N	Assakae	Trader	\N	\N	\N	\N	+233256510605	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
70551419-17af-4ec1-adfc-ce16081ef323	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00016	Mavis	Ahvrimah	2003-05-03	female	single	+233257691842	\N	Assakae, Western Region	Decorator	\N	+233257691842	\N	Solomon Affedzie	+233547228999	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
89c4aebc-071a-4449-b290-10ce4bef77f0	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00017	Hannah	Kwofie	2002-05-28	female	single	+233532340210	hannahkwofie02@gmail.com	Assakae, Western Region	Student	\N	+233581412140	\N	Dorcas Ackon	+233532977095	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
d05afe40-99b8-4fc4-bdce-e3c604761bd8	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00019	Jacobel	Sarpong	2015-12-22	female	single	+233245107127	\N	Assakae, Western Region	Student	\N	\N	\N	Ruby Asante	+233245107127	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Glory	\N	\N
3d992d4f-74ab-4dde-bc8f-b111b817e3cf	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00020	Sarah	Acheampong	2002-09-29	female	single	+233557710069	sarahcheampong@gmail.com	Assakae Market, Western Region	Seamstress	\N	+233557710069	\N	Thomas	+233245324491	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
13202969-fae4-4570-8e52-a459b9d72c50	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00021	Samuel	Amoah	1999-12-26	male	single	+233595762184	samamoah098@gmail.com	Assakae, Western Region	Student	\N	+233595762184	\N	Mercy Quayson	+233591796347	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	+233204727297	\N
4839d65f-5747-47ca-acd3-020d01956db6	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00022	Monica	Tieyir	1983-09-22	female	married	+233592396206	\N	Assakae, Western Region	Trader	\N	+233592396206	\N	Monica	+233592396206	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	+233543477007	\N
3ff54a47-d53d-4047-9412-6b9bf279bcf4	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00023	Abigail	Diibonoba	2010-02-24	female	single	+233206119857	diibonobaabigail@gmail.com	Assakae, Western Region	Student	\N	+233206119857	\N	Josephine Eshun	+233242308121	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
fcc44c6a-2cd5-48a4-97e4-745df7454e12	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00024	Linda	Arthur	1997-05-18	female	single	+233559984390	lindaoliviaarthur@gmail.com	Egyam, Western Region	Trader	\N	+233559984390	\N	Mrs. Rita Amoah	+233241158517	sibling	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Olivia	\N	\N
3973d7af-ed06-4715-9bd5-dbe64619eaf8	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00025	John	Bekoe	2000-07-10	male	single	+233595754730	johnbekoe54@gmail.com	Assakae, Western Region	Unemployed	\N	+233595754730	\N	Elizabeth Bekoe	+233596450632	sibling	active	2019-09-01	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
17eb7287-012a-4dad-ba85-0daf1d11439b	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00026	Richmond	Quayson	2006-03-29	male	single	+233509021595	quaysonrichmond@gmail.com	Assakae, Western Region	Student	\N	+233509021595	\N	Victoria Collins	+233242799028	sibling	active	2022-12-01	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Van	\N	\N
8814952b-8de9-4e72-a0ed-e8a08f439301	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00027	Godina	Adjei	2009-01-15	female	single	+233208537407	\N	Assakae, Western Region	Student	\N	\N	\N	Frimpong Adjei	+233241772780	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
3389287d-0e31-43df-be64-532df09a843e	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00015	Grace	Ackon	\N	female	married	\N	\N	Assakae	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-29 04:36:02.943987+00	2026-05-29 04:36:02.943987+00	\N	\N	\N	\N
e5615449-428f-44e1-b438-cf5169a77307	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00028	Benedicta	Ocran	1987-10-28	female	\N	+233240629944	beneoc@90.com	Assakae, Western Region	Trader	\N	+233240629944	\N	Benedicta	+233240629944	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
d9984f79-17a3-45bc-bce4-ed6e70c6fa1b	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00029	Beatrice	Bentil	1972-04-02	female	married	+233544484102	\N	Assakae, Western Region	Trader	\N	+233544484102	\N	Beatrice	+233544484102	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
85819f14-e476-4946-933c-8631b61a1496	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00030	Dorothy	Oduro	1978-07-18	female	married	+233543045704	\N	Assakae, Western Region	Trader	\N	+233543045704	\N	Dorothy	+233543045704	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	+233592396482	\N
fc25611d-d9ca-4d5f-8304-b3dbacf09861	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00031	Dorcas	Ackon	\N	female	married	+233532770095	\N	Assakae, Western Region	Trader	\N	\N	\N	Hannah Kuofie	+233532340210	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
003387e8-413e-4b5a-80d1-17e507835d00	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00032	Juliana	Quarshie	\N	female	single	+233547599012	\N	Assakae, Western Region	Trader	\N	\N	\N	Joseph Asmah	+233500636498	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
e6c5c1cd-7307-4dc4-abb0-c465dfc4a924	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00033	Florence	Asafua	\N	female	married	+233503818858	\N	Assakae, Western Region	Trader	\N	+233503818858	\N	John Quagson	+233256407202	spouse	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
89a38cb4-4d29-401e-bbb1-8bc33cea0106	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00034	Princess	Adobah	1997-09-05	female	single	+233506805767	\N	Assakae, Western Region	\N	\N	+233506805767	\N	\N	+233553083692	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	+233598221850	\N
c5499049-243e-4557-99d4-315f8fdcd711	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00035	Grace	Sanie	1984-04-05	female	married	+233593021089	\N	Takoradi, Western Region	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
14b12bcb-ee9a-458c-bd0a-61aacaf205a2	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00036	Peter	Asamoah	1994-02-12	male	\N	+233551350889	peter@gmail.com	Takoradi, Western Region	Aboboyaa	\N	+233551350889	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Nkrumah	+233551350889	\N
7e74db1f-f773-4291-a55b-e6b623c989c5	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00037	Francis	Bordoh	1975-08-14	male	\N	+233553699281	\N	Takoradi, Western Region	Mechanic	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Arthur	\N	\N
d3f54d6b-4df9-4fca-b1de-a3b6bccedcbc	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00038	Agness	Arthur	\N	female	\N	+233244905497	\N	Takoradi, Western Region	Trader	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
33f464e5-f0d6-4390-b47e-8aaf8e5f5c0f	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00039	Francis	Okyere	1966-08-19	male	married	+233273369182	\N	Assakae, Agona Yakrom	Mechanic	\N	+233364749133	\N	Francis Okyere	+233273369182	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
9d39ebd1-9241-468a-86e8-4ccad2a84d4b	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00040	Rebecca	Appiah	\N	female	married	+233242549985	\N	Takoradi, Western Region	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
25badbcf-8a3b-4e72-8fd1-a866a8d308d7	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00041	Rebecca	Prah	2002-03-06	female	single	+233535725722	\N	Assakae, Shama, Western Region	Trader	\N	+233535725722	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
83b8a301-0ef6-42e5-82b2-2437ec1519a3	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00042	Emmanuel	Akadey	1976-09-27	male	\N	+233243312141	\N	Takoradi, Western Region	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	+233594297748	\N
321376a2-097d-44df-92c5-e46b5585226e	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00043	Michael	Amoah	1984-04-14	male	married	+233206390774	\N	Takoradi, Assakae, Western Region	Tanker Driver	\N	+233206390774	\N	\N	\N	\N	active	2004-01-01	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	+233552411098	\N
3f3a2f7c-896a-48b1-bf1e-cc6a842aac91	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00044	Elizabeth	Nyantakyi	1990-04-27	female	\N	+233535445839	\N	Takoradi, Western Region	Fashion Designer	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Agyemang	+233506641039	\N
c879c403-9cdd-4d91-94cc-c5161264e88a	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00045	Frempong	Philipa	2007-08-03	female	single	+233247699783	\N	\N	Hair Stylist	\N	+233264990151	\N	Emelia Addision	+233594238006	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
7c4ccc42-8f9d-430e-b3a9-ca157b57d3be	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00047	Hannah	Mensah	1991-06-20	female	married	+233545898943	\N	Yabeaw	Trader	\N	+233545898943	\N	Solomon Ayi Mensah	+233243055536	spouse	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Ayi	\N	\N
a8128cee-adba-43d5-a0dc-1511a109bf32	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00048	Ruth	Appiah	\N	female	married	+233244345089	\N	\N	Trader	\N	\N	\N	Abiba	+233551719009	other	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
4121e8ee-364d-4888-957b-3cd242d64e29	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00050	Mary	Quaicoe	\N	female	single	+233203387744	\N	Assakae, Western Region	Trader | Farmer	\N	\N	\N	Mena Ekua	+233550615044	parent	active	2013-01-01	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
c9108db1-49e9-4172-be98-f20407908113	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00051	Comfort	Aduamah	2014-05-20	female	single	+233248381187	\N	Assakae, Western Region	Student	\N	\N	\N	Rose Gama	+233248381187	parent	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Abena	\N	\N
a7cf1abf-38a6-4215-81e0-040b2c227ce4	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00052	Emmanuella	Manu	2000-04-14	female	single	+233558440490	\N	Takoradi, Western Region	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	\N	\N	\N
fd71ca1a-eb80-4c71-9c18-85f0f6b115c5	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00053	Frank	Bimpong	2010-06-18	male	single	+233506641039	frankbimpong34@gmail.com	Western Region	Student	\N	+233535445839	\N	Elizabeth Agyemang	+233535445839	parent	active	2023-12-31	\N	\N	\N	t	\N	\N	2026-05-28 15:07:50.24896+00	2026-05-28 15:07:50.24896+00	\N	Amoamah	\N	\N
f85475f3-1d5f-4779-a180-26c99a96a693	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00062	Rose	Gyamfi	1972-07-03	female	married	248381187	\N	Race Coarse	Trading	\N	\N	\N	Ruby Asante	245107127	Other	active	\N	\N	\N	\N	t	\N	\N	2026-06-15 16:01:57.656928+00	2026-06-15 16:01:58.768164+00	\N	\N	\N	\N
4a0adf22-b292-47c8-b1f4-1283a226463a	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00063	Abigail	Addae	1999-05-13	female	single	551169557	\N	Assakae After Bridge	Trader	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-06-15 16:02:06.609907+00	2026-06-15 16:02:08.185678+00	\N	\N	\N	\N
8d8b9e21-793a-4216-9e8e-f59ccc14075b	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00064	John	Quayson	\N	male	\N	256407202	\N	Assakae	Trader	\N	256407202	\N	Esther Quayson	532004121	Child	active	\N	\N	\N	\N	t	\N	\N	2026-06-15 16:02:14.84703+00	2026-06-15 16:02:15.447362+00	\N	\N	\N	Mr.
3791d288-7a92-47f9-8c0b-4d1216328b71	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00065	Theresah	Acheampong	1994-05-09	female	married	243264329	\N	Assakae	Trader	\N	243264329	\N	Elder Emma	556280105	Other	active	\N	\N	\N	\N	t	\N	\N	2026-06-15 16:02:20.747739+00	2026-06-15 16:02:21.213215+00	\N	\N	\N	\N
1f274168-433f-4ba7-95d6-0680e77d6e30	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00073	Abigail	Arthur	2001-12-26	female	single	233535351805	\N	Assakae - Abaase	Fashion	\N	\N	\N	Mrs. Christina Andoh	233243452869	Other	active	2021-01-01	\N	\N	\N	t	\N	\N	2026-06-21 11:27:38.410468+00	2026-06-21 11:27:39.348823+00	\N	\N	\N	\N
1deb493f-2794-428a-8ae1-81d10ae3125e	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00049	Cecilia	Akon	\N	female	married	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-05-29 04:36:02.943987+00	2026-05-29 04:36:02.943987+00	\N	\N	\N	\N
77945d59-69f2-4a2f-ab0d-ca83ba47abcd	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00066	Lydia	Adobah	1978-01-08	female	married	556069623	\N	Assakae Promise land	Trader	\N	556069623	\N	Abigail Amoah	550184914	Child	active	2006-01-01	\N	\N	\N	t	\N	\N	2026-06-15 16:06:23.987687+00	2026-06-15 16:06:24.881598+00	\N	\N	\N	\N
c53353e2-15a9-4c65-9e44-be57a029da01	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00074	Rebecca	Quaicoe	\N	female	\N	233540486338	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N	\N	t	\N	\N	2026-06-21 11:51:59.563387+00	2026-06-21 11:52:00.519934+00	\N	\N	\N	\N
ea955165-1ac5-46a4-a137-905b31016cae	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00054	BENJAMIN	MENSAH	1994-05-18	male	married	+233557887388	benjaminkwekumensah@gmail.com	PLY 48 ASSAKAE	PROJECT ADMINISTRATOR	\N	557887388	\N	0243964292	0547110763	parent	active	2005-09-29	\N	\N	\N	t	\N	\N	2026-05-31 10:44:41.281552+00	2026-05-31 10:45:20.421603+00	fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	KWEKU	+233509265188	\N
3309bcf1-5d6c-4fac-80dd-6c4c9e49a48c	1777703f-d720-48e5-9543-eba8d27e6a15	CACI-GH-ASSAK-00055	Ankomah	Enoch Sekyi	2003-04-20	male	single	+233503283907	ankomahenoch3@gmail.com	Assakae	\N	\N	+233503283907	\N	Rev. Stephen Ankomah	024943912[	parent	active	2024-09-25	\N	\N	\N	t	\N	\N	2026-05-31 10:50:56.690581+00	2026-05-31 11:17:47.904262+00	\N	\N	+233505527998	Mr.
\.


--
-- Data for Name: pastoral_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pastoral_cases (id, assembly_id, member_id, case_type, title, description, priority, status, assigned_to, is_private, created_by, created_at, resolved_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: pastoral_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pastoral_visits (id, case_id, member_id, visited_by, visit_type, visit_date, notes, outcome, next_visit_date, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: prayer_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_requests (id, assembly_id, member_id, title, description, is_anonymous, status, is_answered, answered_at, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: push_device_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_device_tokens (id, member_id, assembly_id, device_token, platform, is_active, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_key) FROM stdin;
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	attendance:mark
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	finance.offerings.edit
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	finance.offerings.view
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	financials:view
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	financials:write
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	sermon:edit
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	households.create
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	households.edit
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	households.view
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	member:edit
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	member:view_all
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	members.create
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	members.deactivate
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	members.edit
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	members.import
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	members.view
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	reports.export
0a989e5d-4a1b-4b77-a3b3-224ab43771f0	reports.view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	admin.users.manage
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	admin.view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	attendance:mark
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	finance.offerings.edit
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	finance.offerings.view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	financials:view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	financials:write
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	households.create
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	households.edit
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	households.view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	member:edit
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	member:invite
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	member:view_all
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	members.create
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	members.deactivate
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	members.edit
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	members.import
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	members.view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	reports.export
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	reports.view
19a5bf3f-dfd2-4db2-b300-cbc15b24b783	sermon:edit
\.


--
-- Data for Name: service_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_attendance (id, service_id, member_id, status, notes, marked_by, marked_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: service_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_audit_log (id, service_id, changed_by, field_changed, old_value, new_value, changed_at) FROM stdin;
\.


--
-- Data for Name: service_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_templates (id, assembly_id, group_id, title, service_type, recurrence, day_of_week, start_time, venue, recurrence_end_date, is_active, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, assembly_id, template_id, group_id, title, service_type, service_date, start_time, venue, headcount, notes, status, created_by, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: storage_signed_url_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storage_signed_url_log (id, attachment_id, requested_by, ip_address, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: system_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_permissions (id, description, label, module_name, category, is_assignable, is_active, key) FROM stdin;
member:invite	Provision new user accounts	member:invite	admin	Members	t	t	member:invite
member:view_all	View full member directory	member:view_all	membership	Members	t	t	member:view_all
member:edit	Create and update member records	member:edit	membership	Members	t	t	member:edit
financials:view	View tithing and financial history	financials:view	finance	Finance	t	t	financials:view
financials:write	Log tithes, offerings, and expenses	financials:write	finance	Finance	t	t	financials:write
attendance:mark	Record service and event attendance	attendance:mark	attendance	Attendance	t	t	attendance:mark
sermon:edit	Create, edit, or delete sermons	sermon:edit	media	Media	t	t	sermon:edit
members.view	Allows viewing the member directory and individual member records	View Members	membership	Members	t	t	members.view
members.create	Allows creating new member records	Create Members	membership	Members	t	t	members.create
members.edit	Allows editing existing member records	Edit Members	membership	Members	t	t	members.edit
members.deactivate	Allows soft-deactivating member records	Deactivate Members	membership	Members	t	t	members.deactivate
members.import	Allows bulk importing member records via CSV or spreadsheet	Import Members	membership	Members	t	t	members.import
households.view	Allows viewing household records and member groupings	View Households	membership	Households	t	t	households.view
households.create	Allows creating new household records	Create Households	membership	Households	t	t	households.create
households.edit	Allows editing existing household records	Edit Households	membership	Households	t	t	households.edit
reports.view	Allows viewing generated reports and dashboards	View Reports	reports	Reports	t	t	reports.view
reports.export	Allows downloading and exporting reports to CSV/PDF	Export Reports	reports	Reports	t	t	reports.export
finance.offerings.view	Allows viewing tithes, offerings and financial records	View Offerings	finance	Finance	t	t	finance.offerings.view
finance.offerings.edit	Allows recording and editing tithes, offerings and expenses	Edit Offerings	finance	Finance	t	t	finance.offerings.edit
admin.view	Allows access to the admin panel and audit log	View Admin Panel	admin	Admin	t	t	admin.view
admin.users.manage	Allows creating and managing user accounts and assembly role assignments	Manage Users	admin	Admin	t	t	admin.users.manage
services.view	Allows viewing services and attendance records	View Services	events	Services	t	t	services.view
services.create	Allows creating new services	Create Services	events	Services	t	t	services.create
services.edit	Allows editing existing services	Edit Services	events	Services	t	t	services.edit
services.delete	Allows deleting services	Delete Services	events	Services	t	t	services.delete
services.templates.manage	Allows creating and editing service templates	Manage Service Templates	events	Services	t	t	services.templates.manage
services.attendance.mark	Allows marking attendance for services	Mark Attendance	events	Services	t	t	services.attendance.mark
groups.view	Allows viewing groups and their members	View Groups	membership	Groups	t	t	groups.view
groups.create	Allows creating new groups	Create Groups	membership	Groups	t	t	groups.create
groups.edit	Allows editing existing groups	Edit Groups	membership	Groups	t	t	groups.edit
groups.delete	Allows deleting groups	Delete Groups	membership	Groups	t	t	groups.delete
groups.members.manage	Allows adding and removing members from groups	Manage Group Members	membership	Groups	t	t	groups.members.manage
finance.view	Allows viewing financial records	View Finance	finance	Finance	t	t	finance.view
finance.manage	Allows managing and editing financial records	Manage Finance	finance	Finance	t	t	finance.manage
finance.export	Allows exporting financial records	Export Finance	finance	Finance	t	t	finance.export
pastoral.view	Allows viewing pastoral care records	View Pastoral Care	membership	Pastoral Care	t	t	pastoral.view
pastoral.manage	Allows managing pastoral care records	Manage Pastoral Care	membership	Pastoral Care	t	t	pastoral.manage
pastoral.prayer.manage	Allows managing prayer requests	Manage Prayer Requests	membership	Pastoral Care	t	t	pastoral.prayer.manage
a5e2cd23-56e8-43e3-b523-a55b6443c75e	Create and send broadcast campaigns	Send Broadcasts	communications	messaging	t	t	communications.broadcast.send
f80807d5-6d2d-41f6-82a1-b2a3aefce44f	Schedule broadcast campaigns for future delivery	Schedule Broadcasts	communications	messaging	t	t	communications.broadcast.schedule
394a4dc9-75b5-4db9-abe3-a4200fc99d2a	Send direct messages to members	Send Direct Messages	communications	messaging	t	t	communications.direct.send
f42962f5-67ab-40b1-8182-898ad4d82133	Create pastoral threads and sensitive direct messages	Send Pastoral Messages	communications	pastoral	t	t	communications.direct.send_pastoral
6641a44c-d3d7-4988-b5eb-5378bfffded4	Delete any message in any thread	Moderate Threads	communications	moderation	t	t	communications.direct.moderate
0f9cddc8-c8ea-4db7-9148-86ce7f3d2b6e	Upload and broadcast audio messages (pastor only)	Send Audio Broadcasts	communications	media	t	t	communications.audio.broadcast
ea576c1a-3dde-4cc0-92ea-7ab274862824	Post, edit and pin assembly announcements	Manage Announcements	communications	content	t	t	communications.announcements.manage
c197e9e5-8b02-43c1-aee6-7b959bf2b6d9	Create and edit message templates and trigger rules	Manage Templates	communications	admin	t	t	communications.templates.manage
c3ff7c8f-5e8b-493b-a37b-d0b735fe4dbe	Access media in pastoral and sensitive threads	View Pastoral Attachments	communications	pastoral	t	t	communications.attachments.view_pastoral
c25797a7-4cac-4fe1-9650-e9cb788f6ad2	Delete any attachment in the assembly	Manage Attachments	communications	admin	t	t	communications.attachments.manage
88599937-beeb-4434-9d51-3ee864dd851a	View delivery stats, signed URL logs, storage usage	View Comms Reports	communications	reporting	t	t	communications.reports.view
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_profiles (id, assembly_id, full_name, is_active, created_at, updated_at, must_change_password, assembly_role_id, role) FROM stdin;
3a316d19-9416-43b3-a10b-2ec52522c7f1	1777703f-d720-48e5-9543-eba8d27e6a15	Stephen Ankomah	t	2026-05-31 08:23:10.967521+00	2026-06-13 21:01:17.266712+00	f	19a5bf3f-dfd2-4db2-b300-cbc15b24b783	admin
deed0df7-d6de-404a-853d-0428c4196c9a	1777703f-d720-48e5-9543-eba8d27e6a15	Abraham Nhyiraba Obboye Bossman	t	2026-05-25 05:03:26.787975+00	2026-05-30 13:03:48.204059+00	f	\N	admin
fb71f8ba-67d0-4217-8c2e-cd4ae284ced5	1777703f-d720-48e5-9543-eba8d27e6a15	BENJAMIN MENSAH	t	2026-05-31 10:45:20.387214+00	2026-05-31 10:46:43.312522+00	t	0a989e5d-4a1b-4b77-a3b3-224ab43771f0	member
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_events (id, provider, event_type, payload, message_id, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_06; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_06 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_07; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_07 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_08; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_08 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_09; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_09 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_10; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_10 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_11; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_11 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: messages_2026_07_12; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_07_12 (topic, extension, payload, event, private, updated_at, inserted_at, id, binary_payload) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-04-26 05:40:46
20211116045059	2026-04-26 05:40:46
20211116050929	2026-04-26 05:40:46
20211116051442	2026-04-26 05:40:46
20211116212300	2026-04-26 05:40:46
20211116213355	2026-04-26 05:40:46
20211116213934	2026-04-26 05:40:46
20211116214523	2026-04-26 05:40:46
20211122062447	2026-04-26 05:40:46
20211124070109	2026-04-26 05:40:46
20211202204204	2026-04-26 05:40:46
20211202204605	2026-04-26 05:40:46
20211210212804	2026-04-26 05:40:46
20211228014915	2026-04-26 05:40:46
20220107221237	2026-04-26 05:40:46
20220228202821	2026-04-26 05:40:46
20220312004840	2026-04-26 05:40:46
20220603231003	2026-04-26 05:40:46
20220603232444	2026-04-26 05:40:46
20220615214548	2026-04-26 05:40:46
20220712093339	2026-04-26 05:40:46
20220908172859	2026-04-26 05:40:46
20220916233421	2026-04-26 05:40:46
20230119133233	2026-04-26 05:40:46
20230128025114	2026-04-26 05:40:46
20230128025212	2026-04-26 05:40:46
20230227211149	2026-04-26 05:40:46
20230228184745	2026-04-26 05:40:46
20230308225145	2026-04-26 05:40:46
20230328144023	2026-04-26 05:40:46
20231018144023	2026-04-26 05:40:46
20231204144023	2026-04-26 05:40:46
20231204144024	2026-04-26 05:40:46
20231204144025	2026-04-26 05:40:46
20240108234812	2026-04-26 05:40:46
20240109165339	2026-04-26 05:40:46
20240227174441	2026-04-26 05:40:46
20240311171622	2026-04-26 05:40:46
20240321100241	2026-04-26 05:40:46
20240401105812	2026-04-26 05:40:46
20240418121054	2026-04-26 05:40:46
20240523004032	2026-04-26 05:40:46
20240618124746	2026-04-26 05:40:46
20240801235015	2026-04-26 05:40:46
20240805133720	2026-04-26 05:40:46
20240827160934	2026-04-26 05:40:46
20240919163303	2026-04-26 05:40:46
20240919163305	2026-04-26 05:40:46
20241019105805	2026-04-26 05:40:47
20241030150047	2026-04-26 05:40:47
20241108114728	2026-04-26 05:40:47
20241121104152	2026-04-26 05:40:47
20241130184212	2026-04-26 05:40:47
20241220035512	2026-04-26 05:40:47
20241220123912	2026-04-26 05:40:47
20241224161212	2026-04-26 05:40:47
20250107150512	2026-04-26 05:40:47
20250110162412	2026-04-26 05:40:47
20250123174212	2026-04-26 05:40:47
20250128220012	2026-04-26 05:40:47
20250506224012	2026-04-26 05:40:47
20250523164012	2026-04-26 05:40:47
20250714121412	2026-04-26 05:40:47
20250905041441	2026-04-26 05:40:47
20251103001201	2026-04-26 05:40:47
20251120212548	2026-04-26 05:40:47
20251120215549	2026-04-26 05:40:47
20260218120000	2026-04-26 05:40:47
20260326120000	2026-04-26 05:40:47
20260514120000	2026-06-03 07:20:38
20260527120000	2026-06-03 07:20:38
20260528120000	2026-06-03 07:20:38
20260603120000	2026-06-03 21:23:06
20260605120000	2026-06-20 11:58:09
20260606110000	2026-06-20 11:58:09
20260616120000	2026-06-27 23:36:36
20260624120000	2026-06-27 23:36:36
20260626120000	2026-07-06 04:12:03
20260706120000	2026-07-09 07:48:11
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
member-photos	member-photos	\N	2026-05-01 04:48:15.526938+00	2026-05-01 04:48:15.526938+00	t	f	\N	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-04-26 05:38:54.82097
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-04-26 05:38:54.874366
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-04-26 05:38:54.877894
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-04-26 05:38:54.902685
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-04-26 05:38:54.919741
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-04-26 05:38:54.924745
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-04-26 05:38:54.930967
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-04-26 05:38:54.93621
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-04-26 05:38:54.940982
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-04-26 05:38:54.94552
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-04-26 05:38:54.949636
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-04-26 05:38:54.953757
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-04-26 05:38:54.958423
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-04-26 05:38:54.962491
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-04-26 05:38:54.966886
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-04-26 05:38:54.995618
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-04-26 05:38:55.000458
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-04-26 05:38:55.004574
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-04-26 05:38:55.008459
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-04-26 05:38:55.014636
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-04-26 05:38:55.018496
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-04-26 05:38:55.025262
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-04-26 05:38:55.037989
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-04-26 05:38:55.047037
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-04-26 05:38:55.050848
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-04-26 05:38:55.054826
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-04-26 05:38:55.058974
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-04-26 05:38:55.062313
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-04-26 05:38:55.065637
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-04-26 05:38:55.069003
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-04-26 05:38:55.072098
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-04-26 05:38:55.076188
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-04-26 05:38:55.079984
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-04-26 05:38:55.083224
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-04-26 05:38:55.086608
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-04-26 05:38:55.089637
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-04-26 05:38:55.092777
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-04-26 05:38:55.096415
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-04-26 05:38:55.101828
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-04-26 05:38:55.11527
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-04-26 05:38:55.12074
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-04-26 05:38:55.124731
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-04-26 05:38:55.128304
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-04-26 05:38:55.131467
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-04-26 05:38:55.134722
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-04-26 05:38:55.139738
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-04-26 05:38:55.151467
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-04-26 05:38:55.156325
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-04-26 05:38:55.159842
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-04-26 05:38:55.175783
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-04-26 05:38:55.180267
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-04-26 05:38:55.195089
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-04-26 05:38:55.196958
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-04-26 05:38:55.207055
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-04-26 05:38:55.209666
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-04-26 05:38:55.211324
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-04-26 05:38:55.220652
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-04-26 05:38:55.22414
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-04-26 05:38:55.215913
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-06 12:05:04.393105
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-06 12:05:04.404474
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
64a24674-d1c3-466e-8391-0d9618b71e34	member-photos	1777703f-d720-48e5-9543-eba8d27e6a15/8cf54258-0050-423d-b9a3-7f344ead04df/profile.jpg	deed0df7-d6de-404a-853d-0428c4196c9a	2026-05-01 04:51:27.088884+00	2026-05-01 04:51:27.088884+00	2026-05-01 04:51:27.088884+00	{"eTag": "\\"b630cae37162375cf68b6f25309de565\\"", "size": 57036, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-05-01T04:51:28.000Z", "contentLength": 57036, "httpStatusCode": 200}	89779ecc-bfbd-49c6-a093-ebf5adbfe851	deed0df7-d6de-404a-853d-0428c4196c9a	{}
45441e62-8b96-4270-b32b-bada3c303065	member-photos	1777703f-d720-48e5-9543-eba8d27e6a15/1be32cba-2c0b-4574-af0a-8dbaf4e063a7/profile.jpg	deed0df7-d6de-404a-853d-0428c4196c9a	2026-05-01 05:02:54.26572+00	2026-05-01 05:02:54.26572+00	2026-05-01 05:02:54.26572+00	{"eTag": "\\"4cf17a88a4919675ae15775924b66466\\"", "size": 61914, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-05-01T05:02:55.000Z", "contentLength": 61914, "httpStatusCode": 200}	9426d250-208d-4ea4-b2ff-6beb4df85ab3	deed0df7-d6de-404a-853d-0428c4196c9a	{}
8358bcdf-3918-466f-b8ab-7333d060e724	member-photos	1777703f-d720-48e5-9543-eba8d27e6a15/6c4680f5-63ae-4c0a-b76b-d4312cba8558/profile.jpg	deed0df7-d6de-404a-853d-0428c4196c9a	2026-05-02 05:48:44.38534+00	2026-05-02 05:48:44.38534+00	2026-05-02 05:48:44.38534+00	{"eTag": "\\"c8d5de00b9ee7ccccb0a34a5eb169e6a\\"", "size": 42728, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-05-02T05:48:45.000Z", "contentLength": 42728, "httpStatusCode": 200}	03374685-178c-4efe-8b8c-c5bf7cad6f0f	deed0df7-d6de-404a-853d-0428c4196c9a	{}
9f56f673-413c-4d01-9230-738469941a35	member-photos	1777703f-d720-48e5-9543-eba8d27e6a15/7f728448-ee43-4716-bf48-f6ef98f7644f/profile.jpg	deed0df7-d6de-404a-853d-0428c4196c9a	2026-05-02 05:49:25.083351+00	2026-05-02 05:49:25.083351+00	2026-05-02 05:49:25.083351+00	{"eTag": "\\"5cc756b3488bfb89bb3718da22280287\\"", "size": 75933, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-05-02T05:49:26.000Z", "contentLength": 75933, "httpStatusCode": 200}	2735948e-ab42-4cde-96e7-f27d34082e7b	deed0df7-d6de-404a-853d-0428c4196c9a	{}
b7db9145-61c6-4220-bad1-7662a0175d2a	member-photos	deed0df7-d6de-404a-853d-0428c4196c9a/profile_1780821453772_86782.jpg	deed0df7-d6de-404a-853d-0428c4196c9a	2026-06-07 08:37:35.153672+00	2026-06-07 08:37:35.153672+00	2026-06-07 08:37:35.153672+00	{"eTag": "\\"7e79bb43f65e5bf5e58b00b7c052073b\\"", "size": 17215, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-07T08:37:36.000Z", "contentLength": 17215, "httpStatusCode": 200}	29153f74-4599-4974-8810-cfc40fed06eb	deed0df7-d6de-404a-853d-0428c4196c9a	{}
e97de362-a438-4e09-bbe1-79bb6c410860	member-photos	3a316d19-9416-43b3-a10b-2ec52522c7f1/profile_1781384860245_1001076624.jpg	3a316d19-9416-43b3-a10b-2ec52522c7f1	2026-06-13 21:07:42.02904+00	2026-06-13 21:07:42.02904+00	2026-06-13 21:07:42.02904+00	{"eTag": "\\"4ee6b862726bab3a132482e2d756c502\\"", "size": 257957, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2026-06-13T21:07:42.000Z", "contentLength": 257957, "httpStatusCode": 200}	73ed86c0-f26b-422b-b7ce-e8ca05e5a8a5	3a316d19-9416-43b3-a10b-2ec52522c7f1	{}
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: -
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20260427000001	{"-- =============================================================\n-- Migration: 20260427000001_create_enums.sql\n-- Purpose:   Define all PostgreSQL enum types for Phase 1.\n--            These must exist before any table that references them.\n--            Enum values include Phase 1 active roles and future-phase\n--            placeholders so later phases can activate them without\n--            ALTER TYPE (which locks the table in PostgreSQL).\n-- Author:    Abraham N. O. Bossman\n-- Date:      April 27, 2026\n-- =============================================================\n\n-- ------------------------------------------------------------\n-- 1. user_role\n--    Phase 1 active: admin, pastor, secretary, volunteer, member\n--    Future placeholders grouped by planned phase\n-- ------------------------------------------------------------\nCREATE TYPE public.user_role AS ENUM (\n  -- Phase 1 active\n  'admin',\n  'pastor',\n  'secretary',\n  'volunteer',\n  'member',\n\n  -- Phase 3 — Finance module\n  'finance_officer',\n\n  -- Phase 5 — Pastoral Care & Groups\n  'welfare_officer',      -- benevolence/needs tracking\n  'cell_leader',          -- home cell / small group leader\n  'elder',                -- senior oversight, assembly-scoped\n\n  -- Phase 6 — Children's Ministry\n  'children_worker',\n\n  -- Phase 6 — Media & Communications\n  'media_officer',        -- announcements, bulletin, broadcast access\n\n  -- Phase 7 — Multi-assembly\n  'district_overseer',\n  'national_admin'\n)","-- ------------------------------------------------------------\n-- 2. membership_status\n-- ------------------------------------------------------------\nCREATE TYPE public.membership_status AS ENUM (\n  'active',\n  'inactive',\n  'visitor',\n  'prospect',\n  'transfer',\n  'deceased'\n)","-- ------------------------------------------------------------\n-- 3. gender_type\n-- ------------------------------------------------------------\nCREATE TYPE public.gender_type AS ENUM (\n  'male',\n  'female'\n)","-- ------------------------------------------------------------\n-- 4. marital_status_type\n-- ------------------------------------------------------------\nCREATE TYPE public.marital_status_type AS ENUM (\n  'single',\n  'married',\n  'widowed',\n  'divorced',\n  'separated'\n)"}	create_enums
20260427000002	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000002\n-- Table: assemblies\n-- Author: Abraham N. O. Bossman\n-- Phase: Phase 1 — Database Foundation\n-- Day: 12\n-- Date: May 5, 2026\n-- =============================================================================\n-- Depends on: None. The assemblies table does not reference any enums.\n-- Referenced by: user_profiles, households, members, member_audit_log (all carry assembly_id FK)\n-- =============================================================================\n-- Decisions applied in this file:\n--   Day 10 Decision 2 — assembly_code format: [A-Z]{2}-[A-Z]{3,6} regex constraint\n--   Day 10 Decision 4 — digital_address column added (GhanaPostGPS code, NULLable)\n--   Day 10 Decision 6 — no standalone `country` column in Phase 1\n--   Day 11 Decision 2 — migration timestamp uses project start date (20260427), not execution date\n-- =============================================================================\n\n-- -----------------------------------------------------------------------------\n-- 1. Create assemblies table\n-- -----------------------------------------------------------------------------\n\nCREATE TABLE public.assemblies (\n  id               uuid          PRIMARY KEY DEFAULT gen_random_uuid(),\n  name             text          NOT NULL,\n\n  -- Format: [2-letter country code]-[3-6 letter assembly abbreviation]\n  -- Examples: GH-ASSAK, GH-ACCR, UK-LDN, US-ATL\n  -- Day 10 Decision 2\n  assembly_code    text          NOT NULL UNIQUE\n                   CHECK (assembly_code ~ '^[A-Z]{2}-[A-Z]{3,6}$'),\n\n  address          text,\n\n  -- GhanaPostGPS digital address code e.g. WR-1234-5678.\n  -- NULL until confirmed by the assembly. Day 10 Decision 4.\n  digital_address  text,\n\n  -- Soft-disable flag. Used by future Super Admin UI (multi-assembly phase).\n  is_active        boolean       NOT NULL DEFAULT true,\n\n  created_at       timestamptz   NOT NULL DEFAULT now(),\n  updated_at       timestamptz   NOT NULL DEFAULT now()\n)","-- -----------------------------------------------------------------------------\n-- 2. Comment the table and columns for Supabase dashboard discoverability\n-- -----------------------------------------------------------------------------\n\nCOMMENT ON TABLE public.assemblies IS\n  'Assembly (church branch) registry. Pre-seeded in Phase 1 — not user-managed via UI until the multi-assembly management phase.'","COMMENT ON COLUMN public.assemblies.assembly_code IS\n  'Short structured code used in membership number generation. Format: [2-letter country ISO]-[3–6 letter abbreviation]. e.g. GH-ASSAK. Enforced by CHECK constraint.'","COMMENT ON COLUMN public.assemblies.digital_address IS\n  'Ghana GhanaPostGPS digital address code. e.g. WR-1234-5678. NULL until the GPS code is confirmed for the assembly location.'","COMMENT ON COLUMN public.assemblies.is_active IS\n  'Soft-disable flag. Set to false to deactivate an assembly without deleting its records. Not used in Phase 1 (single assembly).'","-- -----------------------------------------------------------------------------\n-- 3. updated_at auto-maintenance trigger\n-- -----------------------------------------------------------------------------\n-- This trigger keeps updated_at in sync on every UPDATE to the assemblies row.\n-- The same pattern is used on all Phase 1 tables (user_profiles, households,\n-- members). The trigger function is defined once here and reused by all tables.\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.set_updated_at()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nAS $$\nBEGIN\n  NEW.updated_at = now();\n  RETURN NEW;\nEND;\n$$","COMMENT ON FUNCTION public.set_updated_at() IS\n  'Generic trigger function that sets updated_at = now() on every row UPDATE. Shared across all Phase 1 tables.'","CREATE TRIGGER trg_assemblies_set_updated_at\n  BEFORE UPDATE ON public.assemblies\n  FOR EACH ROW\n  EXECUTE FUNCTION public.set_updated_at()","-- -----------------------------------------------------------------------------\n-- 4. Enable Row Level Security\n-- -----------------------------------------------------------------------------\n-- RLS is enabled manually per migration, not via Supabase auto-RLS.\n-- Day 3 project setting: \\"Enable automatic RLS\\" was DISABLED. (IDR-001 §4.2)\n-- Actual RLS policies are defined in Document 5 — RLS Policy Specification\n-- and will be applied in a dedicated RLS migration. Enabling RLS here without\n-- policies locks the table down to zero rows for all roles until policies are\n-- added — this is the correct, secure default.\n-- -----------------------------------------------------------------------------\n\nALTER TABLE public.assemblies ENABLE ROW LEVEL SECURITY","-- -----------------------------------------------------------------------------\n-- 5. Indexes\n-- -----------------------------------------------------------------------------\n-- assembly_code already carries a UNIQUE constraint which PostgreSQL implements\n-- as a unique B-tree index automatically. No additional index is needed on it.\n-- An index on is_active supports future dashboard aggregate queries that filter\n-- active assemblies, though with a single row in Phase 1 this is a readiness\n-- index for future phases.\n\nCREATE INDEX idx_assemblies_is_active\n  ON public.assemblies (is_active)","-- =============================================================================\n-- END OF MIGRATION 20260427000002\n-- ============================================================================="}	create_assemblies
20260427000003	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000003\n-- Table:   user_profiles\n-- Author:  Abraham N. O. Bossman\n-- Phase:   Phase 1 — Database Foundation\n-- Day:     13\n-- Date:    May 6, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000001_create_enums.sql       (user_role enum must exist)\n--   20260427000002_create_assemblies.sql  (assemblies table + set_updated_at() must exist)\n-- Referenced by:\n--   households, members, member_audit_log\n--   (created_by / changed_by FKs all point to user_profiles.id)\n-- =============================================================================\n-- Decisions applied in this file:\n--   Day 10 Decision 1  — admin must have a member record first (app-layer\n--                         enforcement; member_id FK deferred to a later migration)\n--   Day 11 Decision 2  — migration timestamp uses project start date (20260427)\n--   Day 12 Decision 1  — set_updated_at() already defined in migration 2;\n--                         referenced here via EXECUTE FUNCTION, not redefined\n--   Day 12 Decision 2  — RLS enabled immediately with no data-access policies\n--                         (secure default; policies applied in dedicated RLS migration)\n-- =============================================================================\n-- Naming note — helper function names:\n--   Document 4 (ERD §4.2) lists current_user_role() / current_user_assembly().\n--   Document 5 (RLS Policy Spec §3) supersedes those with get_user_role() /\n--   get_user_assembly_id() — the names actually called by every RLS policy.\n--   Document 5 also adds four additional helpers not in Document 4:\n--   is_admin(), is_admin_or_pastor(), is_admin_or_secretary(), can_read_directory().\n--   This migration uses Document 5 names throughout. Document 4 should be\n--   updated to align in its next revision.\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- 1. Create user_profiles table\n-- -----------------------------------------------------------------------------\n-- Links a Supabase Auth user (auth.users.id) to an assembly and a system role.\n-- The Flutter app reads this table immediately after login to determine the\n-- user's role and assembly, which drives all navigation and RLS policy results.\n-- Rows are created by the Admin when provisioning a new staff/volunteer account.\n-- They are NOT auto-created on Supabase Auth sign-up.\n-- Reference: Document 4 §4.2\n-- -----------------------------------------------------------------------------\n\nCREATE TABLE public.user_profiles (\n\n  -- PK mirrors auth.users.id — this is NOT a standalone generated UUID.\n  -- ON DELETE CASCADE: removing the Auth user also removes the profile row.\n  id           uuid                NOT NULL\n               PRIMARY KEY\n               REFERENCES auth.users(id) ON DELETE CASCADE,\n\n  -- Every user belongs to exactly one assembly.\n  -- All RLS cross-assembly isolation (IMR-04) derives from this column.\n  assembly_id  uuid                NOT NULL\n               REFERENCES public.assemblies(id),\n\n  -- System role. Phase 1 active: admin, pastor, secretary, volunteer, member.\n  -- Future-phase roles pre-declared in the enum (Day 11 Decision 1).\n  -- Only admin may change this column (RLS policy: user_profiles_update_admin).\n  -- Default 'member' is a safe, low-privilege fallback.\n  role         public.user_role    NOT NULL DEFAULT 'member',\n\n  -- Display name surfaced in audit log entries and the Flutter UI header.\n  -- Supplied by the Admin at account creation time.\n  full_name    text                NOT NULL,\n\n  -- Soft-disable flag. false = account deactivated; user may not log in.\n  -- Set by Admin via SCR-16 (User Management). Profiles are never hard-deleted.\n  -- Reference: Document 3 §4.10\n  is_active    boolean             NOT NULL DEFAULT true,\n\n  created_at   timestamptz         NOT NULL DEFAULT now(),\n  updated_at   timestamptz         NOT NULL DEFAULT now()\n\n)","-- -----------------------------------------------------------------------------\n-- 2. Table and column comments\n-- -----------------------------------------------------------------------------\n\nCOMMENT ON TABLE public.user_profiles IS\n  'Links a Supabase Auth user to their assembly and system role. '\n  'Source of truth for all RLS helper functions '\n  '(get_user_role, get_user_assembly_id, is_admin, etc.). '\n  'Rows are Admin-created — not auto-created on sign-up. '\n  'Never hard-deleted; deactivation via is_active = false only.'","COMMENT ON COLUMN public.user_profiles.id IS\n  'Primary key. Must equal auth.users.id for the corresponding Auth account. '\n  'Not a standalone UUID — cascade-deleted when the Auth user is removed.'","COMMENT ON COLUMN public.user_profiles.assembly_id IS\n  'The assembly this user account belongs to. '\n  'Every RLS policy derives the requesting user''s assembly scope from this column. '\n  'Enforces IMR-04 (no cross-assembly data access) at the database layer.'","COMMENT ON COLUMN public.user_profiles.role IS\n  'System role. Controls which RLS policy branches apply and which Flutter UI '\n  'features are visible. Phase 1 active: admin, pastor, secretary, volunteer, member. '\n  'Only an admin may UPDATE this column (RLS-enforced). '\n  'Default member is a safe fallback for any account not explicitly assigned a role.'","COMMENT ON COLUMN public.user_profiles.full_name IS\n  'User display name. Written to member_audit_log.changed_by context on every '\n  'audited member change. Does not need to match auth.users metadata.'","COMMENT ON COLUMN public.user_profiles.is_active IS\n  'Soft-disable flag. Set to false by Admin to deactivate an account. '\n  'The Supabase Auth session should also be revoked at the same time — '\n  'RLS alone does not invalidate an existing JWT for an inactive user. '\n  'All six RLS helper functions filter AND is_active = true, '\n  'so an inactive user effectively has no role and no assembly access.'","-- -----------------------------------------------------------------------------\n-- 3. updated_at trigger\n-- -----------------------------------------------------------------------------\n-- set_updated_at() was defined once in 20260427000002_create_assemblies.sql\n-- and is shared across all Phase 1 tables. Do NOT redefine it here.\n-- Reference: Day 12 Decision 1\n-- -----------------------------------------------------------------------------\n\nCREATE TRIGGER trg_user_profiles_set_updated_at\n  BEFORE UPDATE ON public.user_profiles\n  FOR EACH ROW\n  EXECUTE FUNCTION public.set_updated_at()","-- -----------------------------------------------------------------------------\n-- 4. Enable Row Level Security\n-- -----------------------------------------------------------------------------\n-- Enabled immediately on table creation — the table is never left unprotected.\n-- With RLS on and no policies defined, PostgreSQL denies all rows to all roles\n-- (except the table owner). This is the correct secure default.\n-- Reference: Day 12 Decision 2\n--\n-- Data-access policies for user_profiles are applied in the dedicated RLS\n-- migration (Document 5 §6):\n--   user_profiles_select_admin   — admin reads all profiles in their assembly\n--   user_profiles_select_own     — any authenticated user reads their own row\n--   user_profiles_insert_admin   — admin creates profiles within their assembly\n--   user_profiles_update_admin   — admin updates profiles within their assembly\n--   (No DELETE policy — deactivation via is_active = false only)\n-- -----------------------------------------------------------------------------\n\nALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY","-- -----------------------------------------------------------------------------\n-- 5. Indexes\n-- -----------------------------------------------------------------------------\n\n-- assembly_id FK — every RLS helper does a WHERE on this; essential for performance.\nCREATE INDEX idx_user_profiles_assembly_id\n  ON public.user_profiles (assembly_id)","-- role — used in RLS helper WHERE clauses and admin role-filter dashboard queries.\nCREATE INDEX idx_user_profiles_role\n  ON public.user_profiles (role)","-- is_active — all six RLS helpers filter AND is_active = true on every query.\nCREATE INDEX idx_user_profiles_is_active\n  ON public.user_profiles (is_active)","-- =============================================================================\n-- 6. RLS Helper Functions\n-- =============================================================================\n-- All six helper functions required by Document 5 (RLS Policy Specification §3)\n-- are defined here in full. These are not stubs — they are the complete,\n-- production implementations that all subsequent RLS policies will call.\n--\n-- Why defined in this migration (not a separate one)?\n--   These functions SELECT from user_profiles. They can only be defined after\n--   user_profiles exists. Placing them here makes the dependency explicit:\n--   table first, then the functions that read it.\n--\n-- Why SECURITY DEFINER?\n--   RLS is enabled on user_profiles. If a policy on another table (e.g. members)\n--   calls a helper that reads user_profiles, that inner read is itself subject\n--   to user_profiles RLS — causing infinite recursion or an empty result.\n--   SECURITY DEFINER elevates the function to run as its definer (the DB owner),\n--   bypassing user_profiles RLS for that lookup only. This is the standard\n--   Supabase pattern for role-based RLS helpers.\n--   Reference: Document 5 §3 \\"Why SECURITY DEFINER?\\"\n--\n-- Why SET search_path = public?\n--   Pins the function to the public schema, preventing search_path injection\n--   attacks where an attacker creates a shadowing function in another schema.\n--\n-- Why STABLE?\n--   Tells the query planner the function returns the same result within a\n--   single query execution. The planner can cache and reuse the result across\n--   all rows in a result set rather than re-executing the SELECT for every row.\n--   Critical on large tables (members, member_audit_log).\n--\n-- Why AND is_active = true?\n--   A deactivated user must be treated as if they have no role and no assembly.\n--   Returning NULL from all helpers means every RLS USING clause evaluates to\n--   false — the deactivated user sees zero rows and cannot write anything.\n--\n-- Why LIMIT 1?\n--   id is the PK on user_profiles, so auth.uid() maps to at most one row.\n--   LIMIT 1 is defensive — explicit intent, and future-safe against any schema\n--   change that might inadvertently allow duplicate id values.\n--\n-- All functions use CREATE OR REPLACE — idempotent, safe to re-apply.\n-- Reference: Document 5 §3.1–3.6\n-- =============================================================================\n\n\n-- ---------------------------------------------------------------------------\n-- 6.1  get_user_role()\n-- ---------------------------------------------------------------------------\n-- Returns the user_role enum of the currently authenticated user.\n-- Returns NULL if the user has no active profile — all RLS policies then\n-- evaluate to false, so the user can access nothing.\n-- Usage in policies: public.get_user_role() = 'pastor'\n-- Reference: Document 5 §3.1\n-- ---------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.get_user_role()\nRETURNS public.user_role\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT role\n  FROM public.user_profiles\n  WHERE id        = auth.uid()\n    AND is_active = true\n  LIMIT 1;\n$$","COMMENT ON FUNCTION public.get_user_role() IS\n  'Returns the user_role of the currently authenticated Supabase user. '\n  'Returns NULL if no active user_profiles row exists for auth.uid(). '\n  'SECURITY DEFINER prevents infinite recursion when called from inside '\n  'an RLS policy on a table that itself reads user_profiles. '\n  'Used in every RLS policy that branches on the requesting user''s role.'","-- ---------------------------------------------------------------------------\n-- 6.2  get_user_assembly_id()\n-- ---------------------------------------------------------------------------\n-- Returns the assembly_id UUID of the currently authenticated user.\n-- Returns NULL if the user has no active profile — every assembly-scoped\n-- RLS USING clause (assembly_id = get_user_assembly_id()) then evaluates\n-- to false, so the user can read or write no assembly data.\n-- Usage in policies: assembly_id = public.get_user_assembly_id()\n-- Reference: Document 5 §3.2; enforces IMR-04\n-- ---------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.get_user_assembly_id()\nRETURNS uuid\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT assembly_id\n  FROM public.user_profiles\n  WHERE id        = auth.uid()\n    AND is_active = true\n  LIMIT 1;\n$$","COMMENT ON FUNCTION public.get_user_assembly_id() IS\n  'Returns the assembly_id of the currently authenticated Supabase user. '\n  'Returns NULL if no active user_profiles row exists for auth.uid(). '\n  'A NULL result causes every assembly_id = get_user_assembly_id() RLS '\n  'clause to evaluate to false — inactive or unassigned users access nothing. '\n  'SECURITY DEFINER to bypass user_profiles RLS during lookup. '\n  'Primary enforcement mechanism for IMR-04 (no cross-assembly data access).'","-- ---------------------------------------------------------------------------\n-- 6.3  is_admin()\n-- ---------------------------------------------------------------------------\n-- Convenience predicate: true iff the current user is an active admin.\n-- Returns false (not NULL) for unauthenticated or inactive users.\n-- Usage in policies: public.is_admin()\n-- Reference: Document 5 §3.3\n-- ---------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.is_admin()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id        = auth.uid()\n      AND role      = 'admin'\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin() IS\n  'Returns true iff the current user is an active admin. '\n  'Returns false (not NULL) for unauthenticated or inactive users — '\n  'EXISTS always returns a boolean, never NULL. '\n  'Used as a shorthand predicate in admin-only RLS policies.'","-- ---------------------------------------------------------------------------\n-- 6.4  is_admin_or_pastor()\n-- ---------------------------------------------------------------------------\n-- True iff the current user is an active admin or pastor.\n-- Used in policies granting elevated read access (e.g. pastoral_notes\n-- visibility, soft-deleted record access).\n-- Reference: Document 5 §3.4\n-- ---------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.is_admin_or_pastor()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id        = auth.uid()\n      AND role      IN ('admin', 'pastor')\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin_or_pastor() IS\n  'Returns true iff the current user is an active admin or pastor. '\n  'Used in RLS policies that grant elevated read access, '\n  'including pastoral_notes visibility (IMR-03).'","-- ---------------------------------------------------------------------------\n-- 6.5  is_admin_or_secretary()\n-- ---------------------------------------------------------------------------\n-- True iff the current user is an active admin or secretary.\n-- Used in INSERT and UPDATE policies on members and households —\n-- the two roles permitted to create and edit records.\n-- Reference: Document 5 §3.5\n-- ---------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.is_admin_or_secretary()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id        = auth.uid()\n      AND role      IN ('admin', 'secretary')\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin_or_secretary() IS\n  'Returns true iff the current user is an active admin or secretary. '\n  'Used in INSERT and UPDATE RLS policies on members and households — '\n  'the two roles authorised to create and modify records.'","-- ---------------------------------------------------------------------------\n-- 6.6  can_read_directory()\n-- ---------------------------------------------------------------------------\n-- True iff the current user holds a role permitted to read the member\n-- directory: admin, pastor, secretary, volunteer.\n-- The 'member' role is deliberately excluded — members use a separate\n-- own-record-only SELECT policy (members_select_own_member_role in Doc 5 §8).\n-- Reference: Document 5 §3.6\n-- ---------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.can_read_directory()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id        = auth.uid()\n      AND role      IN ('admin', 'pastor', 'secretary', 'volunteer')\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.can_read_directory() IS\n  'Returns true iff the current user may read the member directory. '\n  'Permitted roles: admin, pastor, secretary, volunteer. '\n  'The member role is excluded — members use a separate own-record-only SELECT policy. '\n  'Used in SELECT policies on members and households.'","-- =============================================================================\n-- END OF MIGRATION 20260427000003\n-- =============================================================================\n--\n-- Post-apply verification (run in Supabase SQL Editor after supabase db push):\n--\n-- 1. Confirm table columns:\n--    SELECT column_name, data_type, is_nullable, column_default\n--    FROM information_schema.columns\n--    WHERE table_schema = 'public' AND table_name = 'user_profiles'\n--    ORDER BY ordinal_position;\n--    -- Expected: 7 columns — id, assembly_id, role, full_name, is_active,\n--    --           created_at, updated_at\n--\n-- 2. Confirm RLS is enabled:\n--    SELECT tablename, rowsecurity\n--    FROM pg_tables\n--    WHERE schemaname = 'public' AND tablename = 'user_profiles';\n--    -- Expected: rowsecurity = true\n--\n-- 3. Confirm all six helper functions are present and SECURITY DEFINER:\n--    SELECT proname, prosecdef\n--    FROM pg_proc\n--    WHERE pronamespace = 'public'::regnamespace\n--      AND proname IN (\n--        'get_user_role',\n--        'get_user_assembly_id',\n--        'is_admin',\n--        'is_admin_or_pastor',\n--        'is_admin_or_secretary',\n--        'can_read_directory'\n--      )\n--    ORDER BY proname;\n--    -- Expected: 6 rows, all with prosecdef = true\n--\n-- 4. Confirm updated_at trigger is attached:\n--    SELECT trigger_name, event_manipulation, action_timing\n--    FROM information_schema.triggers\n--    WHERE event_object_schema = 'public'\n--      AND event_object_table  = 'user_profiles';\n--    -- Expected: trg_user_profiles_set_updated_at | UPDATE | BEFORE\n--\n-- 5. Confirm indexes:\n--    SELECT indexname FROM pg_indexes\n--    WHERE schemaname = 'public' AND tablename = 'user_profiles';\n--    -- Expected: user_profiles_pkey, idx_user_profiles_assembly_id,\n--    --           idx_user_profiles_role, idx_user_profiles_is_active\n--\n-- Day 13 commit:\n--   git add . && git commit -m \\"Day 13 — Migration 3: user_profiles table + RLS helper functions\\"\n--\n-- Day 14 task: 20260427000004_create_households.sql\n--   Remember: households.primary_contact_id FK to members.id must be added\n--   AFTER the members table exists (circular reference — deferrable FK).\n--   Remember: set_updated_at() trigger — do not redefine, just call.\n-- ============================================================================="}	create_user_profiles
20260427000004	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000004\n-- Table:   households\n-- Author:  Abraham N. O. Bossman\n-- Phase:   Phase 1 — Database Foundation\n-- Day:     14\n-- Date:    April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000001_create_enums.sql       (enum types must exist)\n--   20260427000002_create_assemblies.sql  (assemblies table + set_updated_at() must exist)\n--   20260427000003_create_user_profiles.sql (RLS helper functions must exist)\n-- Referenced by:\n--   members (members.household_id references households.id)\n--   Migration 7 (deferrable FK: households.primary_contact_id -> members.id)\n-- =============================================================================\n-- Decisions applied in this file:\n--   Day 11 Decision 2  — migration timestamp uses project start date (20260427)\n--   Day 12 Decision 1  — set_updated_at() already defined in migration 2;\n--                         referenced here via EXECUTE FUNCTION, not redefined\n--   Day 12 Decision 2  — RLS enabled immediately with no data-access policies\n--                         (secure default; policies applied in dedicated RLS migration)\n-- =============================================================================\n-- Circular reference note:\n--   households.primary_contact_id (uuid) will eventually reference members.id.\n--   members.household_id (uuid) references households.id.\n--   PostgreSQL cannot resolve this circular dependency if both FKs are declared\n--   simultaneously. Solution: declare primary_contact_id as a plain nullable uuid\n--   here (no FK), then add the deferrable FK constraint in Migration 7 after the\n--   members table exists.\n--   Reference: Document 4, Section 4.3\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- 1. Create households table\n-- -----------------------------------------------------------------------------\n\nCREATE TABLE public.households (\n\n  id                 uuid          PRIMARY KEY DEFAULT gen_random_uuid(),\n\n  -- Assembly scope — all RLS policies filter on this column.\n  assembly_id        uuid          NOT NULL\n                     REFERENCES public.assemblies(id),\n\n  -- Household display name: e.g. \\"Asante Family\\", \\"Mensah Household\\".\n  family_name        text          NOT NULL,\n\n  -- Optional household address — may differ from individual member addresses.\n  address            text,\n\n  -- The primary contact within this household.\n  -- Stored as a plain uuid here — no FK constraint yet.\n  -- NOTE: FK for primary_contact_id to members.id is added as a deferrable\n  -- constraint in Migration 7 to resolve the circular reference.\n  -- When the FK is eventually added: ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED.\n  primary_contact_id uuid,\n\n  created_at         timestamptz   NOT NULL DEFAULT now(),\n  updated_at         timestamptz   NOT NULL DEFAULT now()\n\n)","-- -----------------------------------------------------------------------------\n-- 2. Table and column comments\n-- -----------------------------------------------------------------------------\n\nCOMMENT ON TABLE public.households IS\n  'Groups member records into family units. Scoped to a single assembly. '\n  'primary_contact_id is a plain uuid here; the FK to members.id is added '\n  'as a deferrable constraint in Migration 7 to resolve the circular reference '\n  'caused by members.household_id referencing this table.'","COMMENT ON COLUMN public.households.assembly_id IS\n  'Assembly this household belongs to. All RLS policies scope households '\n  'to the requesting user''s assembly via this column.'","COMMENT ON COLUMN public.households.family_name IS\n  'Display name for the household. e.g. \\"Asante Family\\". '\n  'Required — a household must have a name to be meaningful.'","COMMENT ON COLUMN public.households.address IS\n  'Optional household address. May differ from individual member addresses '\n  '(e.g. a family home vs a member''s personal residence).'","COMMENT ON COLUMN public.households.primary_contact_id IS\n  'UUID of the primary contact member for this household. '\n  'Stored without a FK constraint until Migration 7 adds the deferrable FK '\n  '(households.primary_contact_id -> members.id ON DELETE SET NULL '\n  'DEFERRABLE INITIALLY DEFERRED). Will be NULL until explicitly set by the Admin.'","-- -----------------------------------------------------------------------------\n-- 3. updated_at trigger\n-- -----------------------------------------------------------------------------\n-- set_updated_at() defined once in 20260427000002_create_assemblies.sql.\n-- Do NOT redefine here. Reference: Day 12 Decision 1.\n-- -----------------------------------------------------------------------------\n\nCREATE TRIGGER trg_households_set_updated_at\n  BEFORE UPDATE ON public.households\n  FOR EACH ROW\n  EXECUTE FUNCTION public.set_updated_at()","-- -----------------------------------------------------------------------------\n-- 4. Enable Row Level Security\n-- -----------------------------------------------------------------------------\n-- Enabled immediately — table is never left unprotected between migrations.\n-- With RLS on and no policies, all roles see zero rows (secure default).\n-- Data-access policies applied in the dedicated RLS migration (Document 5 §7):\n--   households_select_directory_roles  — admin, pastor, secretary, volunteer\n--   households_insert_admin_secretary  — admin, secretary\n--   households_update_admin_secretary  — admin, secretary\n--   households_delete_admin            — admin (only if no members assigned)\n-- Reference: Day 12 Decision 2\n-- -----------------------------------------------------------------------------\n\nALTER TABLE public.households ENABLE ROW LEVEL SECURITY","-- -----------------------------------------------------------------------------\n-- 5. Indexes\n-- -----------------------------------------------------------------------------\n\n-- Primary access pattern: all household queries filter by assembly first.\nCREATE INDEX idx_households_assembly_id\n  ON public.households (assembly_id)","-- Lookup by primary contact — used in household profile view and member unlink.\n-- Partial index: only indexed when a primary contact is actually set.\nCREATE INDEX idx_households_primary_contact_id\n  ON public.households (primary_contact_id)\n  WHERE primary_contact_id IS NOT NULL","-- =============================================================================\n-- END OF MIGRATION 20260427000004\n-- =============================================================================\n--\n-- Post-apply verification (run in Supabase SQL Editor after supabase db push):\n--\n-- 1. Confirm table columns:\n--    SELECT column_name, data_type, is_nullable, column_default\n--    FROM information_schema.columns\n--    WHERE table_schema = 'public' AND table_name = 'households'\n--    ORDER BY ordinal_position;\n--    -- Expected: 7 columns — id, assembly_id, family_name, address,\n--    --           primary_contact_id, created_at, updated_at\n--\n-- 2. Confirm NO FK on primary_contact_id yet (only the assemblies FK should exist):\n--    SELECT constraint_name, constraint_type\n--    FROM information_schema.table_constraints\n--    WHERE table_schema = 'public' AND table_name = 'households';\n--    -- Expected: households_pkey (PRIMARY KEY), one FK for assembly_id.\n--    --           NO fk_households_primary_contact — that comes in Migration 7.\n--\n-- 3. Confirm RLS is enabled:\n--    SELECT tablename, rowsecurity FROM pg_tables\n--    WHERE schemaname = 'public' AND tablename = 'households';\n--    -- Expected: rowsecurity = true\n--\n-- 4. Confirm updated_at trigger is attached:\n--    SELECT trigger_name FROM information_schema.triggers\n--    WHERE event_object_schema = 'public'\n--      AND event_object_table = 'households';\n--    -- Expected: trg_households_set_updated_at\n--\n-- Day 14 commit:\n--   git add . && git commit -m \\"Day 14 — Migration 4: households table\\"\n--\n-- Day 15 task: 20260427000005_create_members.sql (first half — identity + biographical fields)\n--   Remember: members.household_id FK references households.id (safe — households exists now).\n--   Remember: set_updated_at() — do not redefine, just call.\n-- ============================================================================="}	create_households
20260427000005	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000005\n-- Table:   members (COMPLETE — Days 15 + 16)\n-- Author:  Abraham N. O. Bossman\n-- Phase:   Phase 1 — Database Foundation\n-- Days:    15–16\n-- Date:    April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000001_create_enums.sql           (gender_type, marital_status_type,\n--                                              membership_status enums)\n--   20260427000002_create_assemblies.sql      (assemblies table + set_updated_at())\n--   20260427000003_create_user_profiles.sql   (RLS helper functions)\n--   20260427000004_create_households.sql      (households table for household_id FK)\n-- Referenced by:\n--   member_audit_log (member_id FK)\n--   Migration 7     (deferrable FK: households.primary_contact_id -> members.id)\n-- =============================================================================\n-- Decisions applied in this file:\n--   Day 11 Decision 2  — migration timestamp uses project start date (20260427)\n--   Day 12 Decision 1  — set_updated_at() shared; referenced via EXECUTE FUNCTION\n--   Day 12 Decision 2  — RLS enabled immediately, no data-access policies yet\n--   Day 15 Decision 1  — membership_number is nullable at insert time (see below)\n--   Day 16 Decision 1  — soft delete uses both is_active + deleted_at (see below)\n--   Day 16 Decision 2  — partial UNIQUE on membership_number (WHERE deleted_at IS NULL)\n-- =============================================================================\n-- Day 15 Decision 1 — membership_number is NULL at INSERT time\n--   Document 4 shows membership_number as NOT NULL UNIQUE. However, the correct\n--   implementation flow is:\n--     1. Flutter client INSERTs the member row (membership_number = NULL).\n--     2. generate-membership-number Edge Function is called immediately after.\n--     3. Edge Function UPDATEs the row with the generated number.\n--   A NOT NULL constraint would block Step 1. The column is therefore nullable\n--   and uniqueness is enforced via a partial index (WHERE deleted_at IS NULL)\n--   to prevent duplicates once populated while excluding soft-deleted rows.\n--   Reference: Document 6, Section 11.1\n-- =============================================================================\n-- Day 16 Decision 1 — dual soft-delete columns (is_active + deleted_at)\n--   Both columns are retained for distinct semantic purposes:\n--     is_active (boolean) — fast, index-friendly flag for active-member lists.\n--     deleted_at (timestamptz) — audit trail for when the soft-delete occurred.\n--   All partial indexes filter on `deleted_at IS NULL` to exclude soft-deleted rows.\n--   `is_active = false` without a deleted_at indicates a suspended/inactive member\n--   (e.g. transfer, long-term absence) — distinct from a deletion.\n-- =============================================================================\n-- Day 16 Decision 2 — partial UNIQUE index on membership_number\n--   Instead of a table-level UNIQUE constraint (which would conflict with NULLs\n--   from Day 15 Decision 1), a partial unique index is used:\n--     CREATE UNIQUE INDEX ... WHERE deleted_at IS NULL\n--   This ensures uniqueness among active records while allowing soft-deleted\n--   records to retain their former number for audit purposes.\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- 1. Create members table\n-- -----------------------------------------------------------------------------\n\nCREATE TABLE public.members (\n\n  -- -------------------------------------------------------------------------\n  -- Identity\n  -- -------------------------------------------------------------------------\n\n  id                 uuid                 PRIMARY KEY DEFAULT gen_random_uuid(),\n\n  -- Assembly scope — applies to every RLS policy on this table (IMR-04).\n  assembly_id        uuid                 NOT NULL\n                     REFERENCES public.assemblies(id),\n\n  -- Nullable at INSERT time. Populated by the generate-membership-number\n  -- Edge Function immediately after the row is created.\n  -- Format: CACI-[assembly_code]-[5-digit-zero-padded-sequence]\n  -- e.g. CACI-GH-ASSAK-00001\n  -- Uniqueness enforced by a partial index below (Day 16 Decision 2).\n  -- Reference: Day 15 Decision 1; Document 6, Section 11.1\n  membership_number  text,\n\n  -- -------------------------------------------------------------------------\n  -- Core biographical fields\n  -- -------------------------------------------------------------------------\n\n  first_name         text                 NOT NULL,\n\n  last_name          text                 NOT NULL,\n\n  -- Day 11 Decision 1 note: join_date ≠ created_at.\n  -- date_of_birth is optional — not all members will know or share it.\n  date_of_birth      date,\n\n  -- Required. Uses gender_type enum from Migration 1.\n  gender             public.gender_type   NOT NULL,\n\n  -- Optional. Uses marital_status_type enum from Migration 1.\n  marital_status     public.marital_status_type,\n\n  -- -------------------------------------------------------------------------\n  -- Contact information\n  -- -------------------------------------------------------------------------\n\n  -- Phone and email are nullable — not every member will have both.\n  -- Uniqueness (per assembly, among non-deleted rows) enforced by partial indexes below.\n  phone_number       text,\n\n  email              text,\n\n  physical_address   text,\n\n  occupation         text,\n\n  -- -------------------------------------------------------------------------\n  -- Social links\n  -- -------------------------------------------------------------------------\n\n  facebook_url       text,\n\n  -- WhatsApp may differ from phone_number (e.g. a different SIM).\n  whatsapp_number    text,\n\n  instagram_url      text,\n\n  -- -------------------------------------------------------------------------\n  -- Emergency contact\n  -- -------------------------------------------------------------------------\n\n  emergency_contact_name          text,\n\n  emergency_contact_phone         text,\n\n  emergency_contact_relationship  text,\n\n  -- -------------------------------------------------------------------------\n  -- Membership\n  -- -------------------------------------------------------------------------\n\n  -- Required. Defaults to 'visitor' on first insert — secretary/admin promotes to 'active'.\n  membership_status  public.membership_status  NOT NULL DEFAULT 'visitor',\n\n  -- Day 11 Decision 1: join_date is explicitly set by admin; ≠ created_at.\n  join_date          date,\n\n  -- Optional FK to households — a member may not belong to a registered household.\n  -- ON DELETE SET NULL: deleting the household does not orphan the member row.\n  household_id       uuid\n                     REFERENCES public.households(id)\n                     ON DELETE SET NULL,\n\n  -- -------------------------------------------------------------------------\n  -- Media\n  -- -------------------------------------------------------------------------\n\n  -- Supabase Storage object path — resolved to a signed URL in the application layer.\n  profile_photo_url  text,\n\n  -- -------------------------------------------------------------------------\n  -- Restricted — pastoral care\n  -- -------------------------------------------------------------------------\n\n  -- Visible only to admin and pastor — enforced by RLS in the dedicated RLS migration.\n  pastoral_notes     text,\n\n  -- -------------------------------------------------------------------------\n  -- Soft delete (Day 16 Decision 1)\n  -- -------------------------------------------------------------------------\n\n  -- Fast boolean flag used in active-member list queries.\n  -- Partial indexes below filter on deleted_at IS NULL rather than is_active\n  -- so that suspended-but-not-deleted members remain indexed.\n  is_active          boolean              NOT NULL DEFAULT true,\n\n  -- Timestamp of soft deletion — NULL means the row is not deleted.\n  -- Set by the application layer; never set by a direct DELETE.\n  deleted_at         timestamptz,\n\n  -- -------------------------------------------------------------------------\n  -- Record management\n  -- -------------------------------------------------------------------------\n\n  -- The auth.users row that created this member record.\n  -- Nullable: allows system-generated seed data; ON DELETE SET NULL preserves\n  -- the member record if the creating admin account is later removed.\n  created_by         uuid\n                     REFERENCES auth.users(id)\n                     ON DELETE SET NULL,\n\n  created_at         timestamptz          NOT NULL DEFAULT now(),\n\n  updated_at         timestamptz          NOT NULL DEFAULT now()\n\n)","-- -----------------------------------------------------------------------------\n-- 2. Table and column comments\n-- -----------------------------------------------------------------------------\n\nCOMMENT ON TABLE public.members IS\n  'Core member registry for CACI Hub. Scoped to a single assembly via assembly_id. '\n  'Membership numbers are assigned by the generate-membership-number Edge Function '\n  'immediately after insert (Day 15 Decision 1). Soft-deleted rows have deleted_at '\n  'set and remain for audit; they are excluded from all active-member indexes and policies.'","COMMENT ON COLUMN public.members.assembly_id IS\n  'Assembly this member belongs to. Every RLS policy filters on this column (IMR-04).'","COMMENT ON COLUMN public.members.membership_number IS\n  'Unique identifier in the format CACI-[assembly_code]-[5-digit-sequence]. '\n  'NULL at insert time; populated by the generate-membership-number Edge Function. '\n  'Uniqueness enforced by idx_members_membership_number_unique (partial, WHERE deleted_at IS NULL).'","COMMENT ON COLUMN public.members.membership_status IS\n  'Lifecycle status of this member. Defaults to ''visitor'' at insert; '\n  'promoted to ''active'' by admin or secretary after formal joining.'","COMMENT ON COLUMN public.members.join_date IS\n  'Date the member formally joined the assembly. Explicitly set by admin; '\n  'distinct from created_at (Day 11 Decision 1).'","COMMENT ON COLUMN public.members.household_id IS\n  'Optional FK to the households table. NULL until the member is assigned to a household. '\n  'ON DELETE SET NULL: deleting the household record does not orphan the member.'","COMMENT ON COLUMN public.members.pastoral_notes IS\n  'Confidential pastoral-care notes visible only to admin and pastor roles. '\n  'RLS column-level restriction applied in the dedicated RLS migration.'","COMMENT ON COLUMN public.members.is_active IS\n  'Fast boolean flag indicating whether the member is active. '\n  'Soft-deleted members have is_active = false AND deleted_at IS NOT NULL. '\n  'Suspended (inactive but not deleted) members have is_active = false AND deleted_at IS NULL.'","COMMENT ON COLUMN public.members.deleted_at IS\n  'Timestamp when the member record was soft-deleted. NULL means the record is not deleted. '\n  'All partial indexes and RLS policies filter on deleted_at IS NULL.'","COMMENT ON COLUMN public.members.created_by IS\n  'auth.users.id of the user who created this member record. '\n  'NULL for system-generated or seeded records. ON DELETE SET NULL preserves the member '\n  'if the creating admin account is later removed.'","-- -----------------------------------------------------------------------------\n-- 3. updated_at trigger\n-- -----------------------------------------------------------------------------\n-- set_updated_at() defined once in 20260427000002_create_assemblies.sql.\n-- Do NOT redefine here. Reference: Day 12 Decision 1.\n-- -----------------------------------------------------------------------------\n\nCREATE TRIGGER trg_members_set_updated_at\n  BEFORE UPDATE ON public.members\n  FOR EACH ROW\n  EXECUTE FUNCTION public.set_updated_at()","-- -----------------------------------------------------------------------------\n-- 4. Enable Row Level Security\n-- -----------------------------------------------------------------------------\n-- Enabled immediately — table is never left unprotected between migrations.\n-- With RLS on and no policies, all roles see zero rows (secure default).\n-- Data-access policies applied in the dedicated RLS migration (Document 5 §8):\n--   members_select_directory_roles  — admin, pastor, secretary, volunteer\n--   members_select_own              — member (own row only)\n--   members_insert_admin_secretary  — admin, secretary\n--   members_update_admin_secretary  — admin, secretary\n--   members_update_own              — member (limited columns, own row only)\n--   members_delete_admin            — admin (soft delete only — sets deleted_at)\n--   members_pastoral_notes_admin_pastor — column-level, admin + pastor only\n-- Reference: Day 12 Decision 2\n-- -----------------------------------------------------------------------------\n\nALTER TABLE public.members ENABLE ROW LEVEL SECURITY","-- -----------------------------------------------------------------------------\n-- 5. Indexes\n-- -----------------------------------------------------------------------------\n\n-- Primary access pattern: every members query starts with an assembly filter.\nCREATE INDEX idx_members_assembly_id\n  ON public.members (assembly_id)","-- Status filter — most common query: active members of an assembly.\n-- Partial: only indexes visible (non-deleted) rows; excludes soft-deleted rows.\nCREATE INDEX idx_members_membership_status\n  ON public.members (assembly_id, membership_status)\n  WHERE deleted_at IS NULL","-- Household group lookup — used when viewing all members of a household.\n-- Partial: only indexed when a household is assigned and row is not deleted.\nCREATE INDEX idx_members_household_id\n  ON public.members (household_id)\n  WHERE household_id IS NOT NULL AND deleted_at IS NULL","-- Uniqueness for membership_number among active rows (Day 15 Decision 1 + Day 16 Decision 2).\n-- Partial unique: NULLs (pre-Edge-Function rows) are excluded from uniqueness check.\n-- Soft-deleted rows may retain their former number without triggering uniqueness violation.\nCREATE UNIQUE INDEX idx_members_membership_number_unique\n  ON public.members (membership_number)\n  WHERE membership_number IS NOT NULL AND deleted_at IS NULL","-- Uniqueness for phone_number within an assembly, among non-deleted rows.\n-- Partial: NULLs excluded (nullable column) and soft-deleted rows excluded.\nCREATE UNIQUE INDEX idx_members_phone_unique\n  ON public.members (assembly_id, phone_number)\n  WHERE phone_number IS NOT NULL AND deleted_at IS NULL","-- Uniqueness for email within an assembly, among non-deleted rows.\nCREATE UNIQUE INDEX idx_members_email_unique\n  ON public.members (assembly_id, email)\n  WHERE email IS NOT NULL AND deleted_at IS NULL","-- =============================================================================\n-- END OF MIGRATION 20260427000005 (Days 15 + 16 — COMPLETE)\n-- =============================================================================\n--\n-- Post-apply verification (run in Supabase SQL Editor after supabase db push):\n--\n-- 1. Confirm column count (expect 24):\n--    SELECT column_name, data_type, is_nullable, column_default\n--    FROM information_schema.columns\n--    WHERE table_schema = 'public' AND table_name = 'members'\n--    ORDER BY ordinal_position;\n--\n-- 2. Confirm RLS is enabled:\n--    SELECT tablename, rowsecurity FROM pg_tables\n--    WHERE schemaname = 'public' AND tablename = 'members';\n--    -- Expected: rowsecurity = true\n--\n-- 3. Confirm updated_at trigger is attached:\n--    SELECT trigger_name FROM information_schema.triggers\n--    WHERE event_object_schema = 'public'\n--      AND event_object_table = 'members';\n--    -- Expected: trg_members_set_updated_at\n--\n-- 4. Confirm all 6 indexes exist:\n--    SELECT indexname, indexdef FROM pg_indexes\n--    WHERE schemaname = 'public' AND tablename = 'members'\n--    ORDER BY indexname;\n--    -- Expected: members_pkey, idx_members_assembly_id,\n--    --           idx_members_membership_status, idx_members_household_id,\n--    --           idx_members_membership_number_unique,\n--    --           idx_members_phone_unique, idx_members_email_unique\n--\n-- 5. Confirm FK constraints (assembly_id, household_id, created_by):\n--    SELECT constraint_name, constraint_type\n--    FROM information_schema.table_constraints\n--    WHERE table_schema = 'public' AND table_name = 'members';\n--\n-- Day 16 commit:\n--   git add . && git commit -m \\"Day 16 — Migration 5 complete: members table with all columns and unique indexes\\"\n--\n-- Day 17 task: Migration 6 — member_audit_log (references members.id)\n-- ============================================================================="}	create_members
20260427000006	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000006\n-- Table:   member_audit_log\n-- Author:  Abraham N. O. Bossman\n-- Phase:   Phase 1 — Database Foundation\n-- Day:     17\n-- Date:    April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000002_create_assemblies.sql  (assemblies table + set_updated_at())\n--   20260427000005_create_members.sql     (members table — member_id FK)\n-- Referenced by:\n--   Migration 11c (RLS: audit_log_select_admin policy)\n-- =============================================================================\n-- Purpose:\n--   Immutable audit trail of every field change on a member record.\n--   Written exclusively by the write_member_audit_log() SECURITY DEFINER trigger\n--   (defined in Migration 9). No application role may INSERT, UPDATE, or DELETE\n--   rows in this table — enforced by the absence of those RLS policies (IMR-02).\n-- =============================================================================\n-- Decisions applied:\n--   Day 11 Decision 2  — migration timestamp uses project start date (20260427)\n--   Day 12 Decision 2  — RLS enabled immediately, no data-access policies yet\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- 1. Create member_audit_log table\n-- -----------------------------------------------------------------------------\n\nCREATE TABLE public.member_audit_log (\n\n  id             uuid          PRIMARY KEY DEFAULT gen_random_uuid(),\n\n  -- The member whose record was changed.\n  -- ON DELETE CASCADE: deleting a member deletes their audit trail.\n  member_id      uuid          NOT NULL\n                 REFERENCES public.members(id)\n                 ON DELETE CASCADE,\n\n  -- Assembly scope — required for the RLS policy that restricts admin to own assembly.\n  assembly_id    uuid          NOT NULL\n                 REFERENCES public.assemblies(id),\n\n  -- The authenticated user who triggered the change.\n  -- ON DELETE SET NULL: removing an admin account preserves the audit entry.\n  changed_by     uuid\n                 REFERENCES auth.users(id)\n                 ON DELETE SET NULL,\n\n  -- Name of the column that changed, e.g. 'first_name', 'membership_status'.\n  field_changed  text          NOT NULL,\n\n  -- Previous value cast to text. NULL if the field was previously NULL.\n  old_value      text,\n\n  -- New value cast to text. NULL if the field was set to NULL.\n  new_value      text,\n\n  -- Timestamp of the change. Set by the trigger; not user-settable.\n  changed_at     timestamptz   NOT NULL DEFAULT now()\n\n)","-- -----------------------------------------------------------------------------\n-- 2. Table and column comments\n-- -----------------------------------------------------------------------------\n\nCOMMENT ON TABLE public.member_audit_log IS\n  'Immutable audit trail of field-level changes to member records. '\n  'Written only by the write_member_audit_log SECURITY DEFINER trigger. '\n  'No application role may INSERT, UPDATE, or DELETE rows — see IMR-02.'","COMMENT ON COLUMN public.member_audit_log.field_changed IS\n  'Name of the members column that changed. One row per changed field per UPDATE.'","COMMENT ON COLUMN public.member_audit_log.old_value IS\n  'Previous column value cast to text. NULL if the column was previously NULL.'","COMMENT ON COLUMN public.member_audit_log.new_value IS\n  'New column value cast to text. NULL if the column was set to NULL.'","COMMENT ON COLUMN public.member_audit_log.changed_by IS\n  'auth.uid() of the user whose request caused the UPDATE. Set by the trigger.'","-- -----------------------------------------------------------------------------\n-- 3. Enable Row Level Security\n-- -----------------------------------------------------------------------------\n-- No policies yet — applied in Migration 11c.\n-- With RLS on and no policies: all roles see zero rows (secure default).\n-- Reference: Day 12 Decision 2\n-- -----------------------------------------------------------------------------\n\nALTER TABLE public.member_audit_log ENABLE ROW LEVEL SECURITY","-- -----------------------------------------------------------------------------\n-- 4. Indexes\n-- -----------------------------------------------------------------------------\n\n-- Most common query: all audit entries for a specific member.\nCREATE INDEX idx_audit_log_member_id\n  ON public.member_audit_log (member_id)","-- Chronological audit view for admin dashboard — filtered by assembly.\nCREATE INDEX idx_audit_log_assembly_changed_at\n  ON public.member_audit_log (assembly_id, changed_at DESC)","-- =============================================================================\n-- END OF MIGRATION 20260427000006\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n-- 1. Confirm table columns (expect 8):\n--    SELECT column_name, data_type, is_nullable\n--    FROM information_schema.columns\n--    WHERE table_schema = 'public' AND table_name = 'member_audit_log'\n--    ORDER BY ordinal_position;\n--\n-- 2. Confirm RLS enabled:\n--    SELECT tablename, rowsecurity FROM pg_tables\n--    WHERE schemaname = 'public' AND tablename = 'member_audit_log';\n--    -- Expected: rowsecurity = true\n--\n-- Day 17 task: also add deferrable FK (see Migration 20260427000007).\n-- ============================================================================="}	create_member_audit_log
20260427000007	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000007\n-- Purpose:  Add deferrable FK — households.primary_contact_id → members.id\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Day:      17\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000004_create_households.sql  (households table — primary_contact_id column)\n--   20260427000005_create_members.sql     (members table — id column)\n-- =============================================================================\n-- Context — circular reference resolution:\n--   households.primary_contact_id (uuid) → members.id\n--   members.household_id (uuid)           → households.id\n--\n--   Migration 4 declared primary_contact_id as a plain nullable uuid (no FK)\n--   because members did not yet exist. Now that members exists, we add the FK\n--   as a DEFERRABLE INITIALLY DEFERRED constraint:\n--   — The FK is only checked at COMMIT time, not per-statement.\n--   — This allows a household and its primary contact member to be inserted\n--     in the same transaction without a constraint violation.\n--\n--   Reference: Document 4, Section 4.3; Day 14 Decision 1\n-- =============================================================================\n\n\nALTER TABLE public.households\n  ADD CONSTRAINT fk_households_primary_contact\n  FOREIGN KEY (primary_contact_id)\n  REFERENCES public.members(id)\n  ON DELETE SET NULL\n  DEFERRABLE INITIALLY DEFERRED","-- =============================================================================\n-- END OF MIGRATION 20260427000007\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n-- Confirm the deferrable FK now exists:\n--   SELECT constraint_name, constraint_type, is_deferrable, initially_deferred\n--   FROM information_schema.table_constraints\n--   WHERE table_schema = 'public'\n--     AND table_name = 'households'\n--     AND constraint_type = 'FOREIGN KEY';\n--   -- Expected: fk_households_primary_contact | FOREIGN KEY | YES | YES\n-- ============================================================================="}	add_deferrable_fk
20260427000008	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000008\n-- Purpose:  Performance indexes — all Phase 1 tables\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Day:      18\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000003_create_user_profiles.sql  (user_profiles table)\n--   20260427000005_create_members.sql        (members table)\n--   20260427000006_create_member_audit_log.sql (member_audit_log table)\n-- Reference: Document 4, Section 6\n-- =============================================================================\n-- Note: indexes already added inline in their respective table migrations\n-- (e.g. idx_members_assembly_id, idx_members_phone_unique, etc.) are NOT\n-- redefined here to avoid duplicate index errors.\n-- This migration adds the additional performance indexes as specified in §6.\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- members table — additional performance indexes\n-- -----------------------------------------------------------------------------\n\n-- Last name prefix search — used in the member directory search bar.\nCREATE INDEX idx_members_last_name\n  ON public.members (last_name)\n  WHERE deleted_at IS NULL","-- Chronological member list — used in admin exports and activity feeds.\nCREATE INDEX idx_members_created_at\n  ON public.members (assembly_id, created_at DESC)\n  WHERE deleted_at IS NULL","-- Soft-delete monitoring — used to list recently deleted members.\nCREATE INDEX idx_members_deleted_at\n  ON public.members (assembly_id, deleted_at DESC)\n  WHERE deleted_at IS NOT NULL","-- Full-text search on member name — used in the directory search bar.\n-- GIN index on the tsvector of first_name + last_name.\nCREATE INDEX idx_members_fulltext\n  ON public.members\n  USING GIN (to_tsvector('english', first_name || ' ' || last_name))","-- -----------------------------------------------------------------------------\n-- user_profiles table — additional performance indexes\n-- -----------------------------------------------------------------------------\n\n-- Already defined inline in migration 3. Confirm only; no redefinition.\n-- idx_user_profiles_assembly_id is added here if not already present.\nCREATE INDEX IF NOT EXISTS idx_user_profiles_assembly_id\n  ON public.user_profiles (assembly_id)","-- =============================================================================\n-- END OF MIGRATION 20260427000008\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n--   SELECT indexname FROM pg_indexes\n--   WHERE schemaname = 'public'\n--   ORDER BY tablename, indexname;\n--   -- Confirm all expected indexes appear.\n-- ============================================================================="}	create_indexes
20260427000009	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000009\n-- Purpose:  write_member_audit_log() trigger function + trigger attachment\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Days:     19–20\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000002_create_assemblies.sql      (set_updated_at() already defined)\n--   20260427000005_create_members.sql         (members table)\n--   20260427000006_create_member_audit_log.sql (member_audit_log table)\n-- =============================================================================\n-- Day 19 note — set_updated_at():\n--   The set_updated_at() trigger function was defined in Migration 2 and is\n--   already attached to assemblies, user_profiles, households, and members via\n--   their respective migration files. DO NOT redefine here.\n--   Reference: Day 12 Decision 1.\n--\n-- Day 20 — write_member_audit_log():\n--   SECURITY DEFINER: runs as the table owner, bypassing RLS on member_audit_log.\n--   This is required because no INSERT policy exists on member_audit_log (IMR-02).\n--   Reference: Document 4, Section 7.2\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- write_member_audit_log() — field-level audit trigger function\n-- -----------------------------------------------------------------------------\n-- Fires AFTER UPDATE on members.\n-- For each column in the auditable_columns list, compares OLD and NEW values.\n-- Inserts one row into member_audit_log per changed field.\n-- Uses dynamic SQL (EXECUTE format) to read column values by name from the\n-- OLD and NEW composite row types — required for the generic column loop.\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.write_member_audit_log()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  auditable_columns TEXT[] := ARRAY[\n    'first_name', 'last_name', 'phone_number', 'email',\n    'membership_status', 'gender', 'marital_status',\n    'household_id', 'profile_photo_url', 'pastoral_notes',\n    'is_active', 'deleted_at', 'join_date'\n  ];\n  col_name  TEXT;\n  old_val   TEXT;\n  new_val   TEXT;\nBEGIN\n  FOREACH col_name IN ARRAY auditable_columns LOOP\n    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO old_val USING OLD;\n    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO new_val USING NEW;\n\n    IF old_val IS DISTINCT FROM new_val THEN\n      INSERT INTO public.member_audit_log (\n        member_id, assembly_id, changed_by, field_changed, old_value, new_value\n      ) VALUES (\n        NEW.id,\n        NEW.assembly_id,\n        auth.uid(),\n        col_name,\n        old_val,\n        new_val\n      );\n    END IF;\n  END LOOP;\n\n  RETURN NEW;\nEND;\n$$","COMMENT ON FUNCTION public.write_member_audit_log() IS\n  'AFTER UPDATE trigger on members. Inserts one member_audit_log row per changed '\n  'auditable field. Runs as SECURITY DEFINER to bypass the absence of an INSERT '\n  'policy on member_audit_log (IMR-02). Reference: Document 4, Section 7.2.'","-- -----------------------------------------------------------------------------\n-- Attach trigger to members table\n-- -----------------------------------------------------------------------------\n\nCREATE TRIGGER trg_members_audit_log\n  AFTER UPDATE ON public.members\n  FOR EACH ROW\n  EXECUTE FUNCTION public.write_member_audit_log()","-- =============================================================================\n-- END OF MIGRATION 20260427000009\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n-- 1. Confirm trigger exists:\n--    SELECT trigger_name, event_manipulation, action_timing\n--    FROM information_schema.triggers\n--    WHERE event_object_schema = 'public'\n--      AND event_object_table = 'members';\n--    -- Expected: trg_members_set_updated_at (BEFORE UPDATE)\n--    --           trg_members_audit_log (AFTER UPDATE)\n--\n-- 2. Smoke test (requires a member row — skip if no seed data yet):\n--    UPDATE public.members SET first_name = first_name WHERE id = '<any-id>';\n--    -- No change → no audit row expected (IS DISTINCT FROM catches this).\n--    UPDATE public.members SET first_name = 'TestName' WHERE id = '<any-id>';\n--    SELECT * FROM public.member_audit_log WHERE field_changed = 'first_name';\n--    -- Expected: one row with old_value = original name, new_value = 'TestName'.\n-- ============================================================================="}	create_triggers
20260427000011	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000011\n-- Purpose:  All 6 RLS helper functions\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Day:      21\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000003_create_user_profiles.sql  (user_profiles table + stub functions)\n-- =============================================================================\n-- All 6 functions replace the stubs written in Migration 3.\n-- All are SECURITY DEFINER to avoid RLS recursion: if user_profiles has RLS\n-- enabled and a policy on another table calls a function that reads\n-- user_profiles, that inner read would be subject to user_profiles RLS —\n-- causing infinite recursion. SECURITY DEFINER elevates the call to run as\n-- the database owner, bypassing RLS on user_profiles for the helper lookup only.\n-- Reference: Document 5, Section 3\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- 1. get_user_role()\n-- -----------------------------------------------------------------------------\n-- Returns the user_role enum for the currently authenticated user.\n-- Returns NULL if the user has no active user_profiles row.\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.get_user_role()\nRETURNS public.user_role\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT role\n  FROM public.user_profiles\n  WHERE id = auth.uid()\n    AND is_active = true\n  LIMIT 1;\n$$","COMMENT ON FUNCTION public.get_user_role() IS\n  'Returns the user_role enum for the authenticated user. NULL if no active profile. '\n  'SECURITY DEFINER prevents RLS recursion on user_profiles.'","-- -----------------------------------------------------------------------------\n-- 2. get_user_assembly_id()\n-- -----------------------------------------------------------------------------\n-- Returns the assembly_id UUID for the currently authenticated user.\n-- Returns NULL if the user has no active user_profiles row.\n-- When NULL, all RLS conditions that reference this function evaluate to FALSE —\n-- ensuring unassigned users have no data access.\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.get_user_assembly_id()\nRETURNS uuid\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT assembly_id\n  FROM public.user_profiles\n  WHERE id = auth.uid()\n    AND is_active = true\n  LIMIT 1;\n$$","COMMENT ON FUNCTION public.get_user_assembly_id() IS\n  'Returns the assembly_id for the authenticated user. NULL if no active profile. '\n  'SECURITY DEFINER prevents RLS recursion on user_profiles.'","-- -----------------------------------------------------------------------------\n-- 3. is_admin()\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.is_admin()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id = auth.uid()\n      AND role = 'admin'\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin() IS\n  'Returns TRUE if the authenticated user has the admin role and is active.'","-- -----------------------------------------------------------------------------\n-- 4. is_admin_or_pastor()\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.is_admin_or_pastor()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id = auth.uid()\n      AND role IN ('admin', 'pastor')\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin_or_pastor() IS\n  'Returns TRUE if the authenticated user has admin or pastor role and is active.'","-- -----------------------------------------------------------------------------\n-- 5. is_admin_or_secretary()\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.is_admin_or_secretary()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id = auth.uid()\n      AND role IN ('admin', 'secretary')\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin_or_secretary() IS\n  'Returns TRUE if the authenticated user has admin or secretary role and is active.'","-- -----------------------------------------------------------------------------\n-- 6. can_read_directory()\n-- -----------------------------------------------------------------------------\n-- Returns TRUE for roles permitted to read the member directory:\n-- admin, pastor, secretary, volunteer. Excludes the member role.\n-- -----------------------------------------------------------------------------\n\nCREATE OR REPLACE FUNCTION public.can_read_directory()\nRETURNS boolean\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id = auth.uid()\n      AND role IN ('admin', 'pastor', 'secretary', 'volunteer')\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.can_read_directory() IS\n  'Returns TRUE for admin, pastor, secretary, and volunteer roles. '\n  'Used in directory-read SELECT policies on members and households.'","-- =============================================================================\n-- END OF MIGRATION 20260427000011\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n-- Confirm all 6 functions exist:\n--   SELECT routine_name, routine_type\n--   FROM information_schema.routines\n--   WHERE routine_schema = 'public'\n--     AND routine_name IN (\n--       'get_user_role', 'get_user_assembly_id', 'is_admin',\n--       'is_admin_or_pastor', 'is_admin_or_secretary', 'can_read_directory'\n--     );\n--   -- Expected: 6 rows, all routine_type = 'FUNCTION'\n-- ============================================================================="}	create_helper_functions
20260427000012	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000012\n-- Purpose:  Enable Row Level Security on all 5 Phase 1 tables\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Day:      22\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000002_create_assemblies.sql          (assemblies)\n--   20260427000003_create_user_profiles.sql       (user_profiles)\n--   20260427000004_create_households.sql          (households)\n--   20260427000005_create_members.sql             (members)\n--   20260427000006_create_member_audit_log.sql    (member_audit_log)\n--   20260427000011_create_helper_functions.sql    (helper functions required by policies)\n-- =============================================================================\n-- Note: RLS was already enabled inline in each table's migration (Day 12 Decision 2).\n-- This migration verifies the secure default is in place before adding policies.\n-- Using IF NOT EXISTS-equivalent pattern: ALTER TABLE ... ENABLE ROW LEVEL SECURITY\n-- is idempotent in PostgreSQL — running it when already enabled is a no-op.\n-- Reference: Document 5, Sections 5–9\n-- =============================================================================\n\nALTER TABLE public.assemblies          ENABLE ROW LEVEL SECURITY","ALTER TABLE public.user_profiles       ENABLE ROW LEVEL SECURITY","ALTER TABLE public.households          ENABLE ROW LEVEL SECURITY","ALTER TABLE public.members             ENABLE ROW LEVEL SECURITY","ALTER TABLE public.member_audit_log    ENABLE ROW LEVEL SECURITY","-- =============================================================================\n-- END OF MIGRATION 20260427000012\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n--   SELECT tablename, rowsecurity\n--   FROM pg_tables\n--   WHERE schemaname = 'public'\n--     AND tablename IN (\n--       'assemblies', 'user_profiles', 'households',\n--       'members', 'member_audit_log'\n--     );\n--   -- Expected: all 5 rows show rowsecurity = true\n-- ============================================================================="}	enable_rls
20260501044604	{BEGIN,"REVOKE INSERT, UPDATE, DELETE ON public.member_audit_log FROM authenticated, anon",COMMIT}	revoke_audit_log_api_writes
20260427000013	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000013\n-- Purpose:  RLS policies — assemblies, user_profiles, households, members\n--           (SELECT + INSERT policies only — Days 22 and 23)\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Days:     22–23\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000011_create_helper_functions.sql  (all 6 helper functions)\n--   20260427000012_enable_rls.sql               (RLS enabled on all tables)\n-- Reference: Document 5, Sections 5–8\n-- =============================================================================\n-- Decisions applied in this file:\n--   Day 22 — assemblies and user_profiles policies\n--   Day 23 — households and members SELECT + INSERT policies\n-- =============================================================================\n\n\n-- =============================================================================\n-- SECTION 1 — assemblies (Day 22)\n-- Reference: Document 5, Section 5\n-- =============================================================================\n-- Authenticated users may read only the assembly to which they are assigned.\n-- No INSERT / UPDATE / DELETE: assemblies are managed exclusively via migrations\n-- or the Supabase dashboard using the service role key.\n-- -----------------------------------------------------------------------------\n\nCREATE POLICY assemblies_select_own\n  ON public.assemblies\n  FOR SELECT\n  TO authenticated\n  USING (\n    id = public.get_user_assembly_id()\n  )","-- No INSERT policy — no role may create assemblies via the API.\n-- No UPDATE policy — no role may modify assemblies via the API.\n-- No DELETE policy — no role may delete assemblies via the API.\n\n\n-- =============================================================================\n-- SECTION 2 — user_profiles (Day 22)\n-- Reference: Document 5, Section 6\n-- =============================================================================\n\n-- Admin sees all active user profiles within their assembly.\nCREATE POLICY user_profiles_select_admin\n  ON public.user_profiles\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- All authenticated users may read their own profile row.\n-- Required for the app to load the user's role and assembly on login.\nCREATE POLICY user_profiles_select_own\n  ON public.user_profiles\n  FOR SELECT\n  TO authenticated\n  USING (\n    id = auth.uid()\n  )","-- Only Admin may create user profile rows (i.e. create accounts) within their assembly.\nCREATE POLICY user_profiles_insert_admin\n  ON public.user_profiles\n  FOR INSERT\n  TO authenticated\n  WITH CHECK (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Only Admin may update user profiles (role reassignment, deactivation).\nCREATE POLICY user_profiles_update_admin\n  ON public.user_profiles\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )\n  WITH CHECK (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- No DELETE policy: user profiles are deactivated via is_active = false, never hard-deleted.\n\n\n-- =============================================================================\n-- SECTION 3 — households (Day 23)\n-- Reference: Document 5, Section 7\n-- =============================================================================\n\n-- Admin, Pastor, Secretary, and Volunteer may read household records in their assembly.\nCREATE POLICY households_select_assembly\n  ON public.households\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.can_read_directory()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Admin and Secretary may create households within their assembly.\nCREATE POLICY households_insert_admin_secretary\n  ON public.households\n  FOR INSERT\n  TO authenticated\n  WITH CHECK (\n    public.is_admin_or_secretary()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Admin and Secretary may update households within their assembly.\nCREATE POLICY households_update_admin_secretary\n  ON public.households\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.is_admin_or_secretary()\n    AND assembly_id = public.get_user_assembly_id()\n  )\n  WITH CHECK (\n    public.is_admin_or_secretary()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Admin may delete household records (only succeeds if no members are linked\n-- — the members.household_id FK will reject the delete otherwise).\nCREATE POLICY households_delete_admin\n  ON public.households\n  FOR DELETE\n  TO authenticated\n  USING (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- =============================================================================\n-- SECTION 4 — members: SELECT and INSERT policies (Day 23)\n-- Reference: Document 5, Section 8\n-- UPDATE and remaining SELECT policies added in Migration 14 (Day 24).\n-- =============================================================================\n\n-- Admin, Pastor, Secretary, and Volunteer may read active (non-deleted) member records\n-- within their assembly.\nCREATE POLICY members_select_directory_roles\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.can_read_directory()\n    AND assembly_id = public.get_user_assembly_id()\n    AND is_active = true\n  )","-- Member role may read only their own record.\n-- Phase 1 limitation: created_by captures the Secretary's auth.uid() at insert time,\n-- not the member's. A dedicated auth_user_id column (planned for Phase 4) will fix this.\n-- Reference: Document 5, Section 8 design decision note.\nCREATE POLICY members_select_own_member_role\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.get_user_role() = 'member'\n    AND created_by = auth.uid()\n  )","-- Admin and Secretary may insert new member records within their assembly.\nCREATE POLICY members_insert_admin_secretary\n  ON public.members\n  FOR INSERT\n  TO authenticated\n  WITH CHECK (\n    public.is_admin_or_secretary()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- =============================================================================\n-- END OF MIGRATION 20260427000013\n-- ============================================================================="}	create_rls_policies
20260427000014	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000014\n-- Purpose:  RLS policies — remaining members policies + member_audit_log policy\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Day:      24\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000011_create_helper_functions.sql  (all 6 helper functions)\n--   20260427000012_enable_rls.sql               (RLS enabled on all tables)\n--   20260427000013_create_rls_policies.sql      (members SELECT + INSERT policies)\n-- Reference: Document 5, Sections 8 and 9\n-- =============================================================================\n-- Immutable Rules enforced by this file:\n--   IMR-01: No DELETE policy on members   — hard deletion blocked for all roles.\n--   IMR-02: No INSERT/UPDATE/DELETE on member_audit_log — trigger-only writes.\n--   Absence of policy = HTTP 403 for the corresponding operation.\n-- =============================================================================\n\n\n-- =============================================================================\n-- SECTION 1 — members: UPDATE and remaining SELECT policies\n-- Reference: Document 5, Section 8\n-- =============================================================================\n\n-- Admin may SELECT all member records within their assembly — including soft-deleted rows.\n-- Without this policy, Admin would only see is_active = true rows via\n-- members_select_directory_roles. This policy's OR logic at evaluation time means\n-- Admin matches this policy and skips the is_active filter entirely.\nCREATE POLICY members_select_admin_include_deleted\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Admin and Secretary may UPDATE member records within their assembly.\n-- USING filters the rows that can be targeted (only active rows — updates to\n-- already-soft-deleted rows must go via a dedicated restore path, not this policy).\n-- WITH CHECK ensures the updated row remains in the same assembly.\nCREATE POLICY members_update_admin_secretary\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.is_admin_or_secretary()\n    AND assembly_id = public.get_user_assembly_id()\n    AND is_active = true\n  )\n  WITH CHECK (\n    public.is_admin_or_secretary()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Pastor may UPDATE member records within their assembly.\n-- At the database level, this grants UPDATE on all member columns.\n-- The application layer restricts the Pastor's edit form to pastoral_notes only.\n-- Risk: a Pastor calling the API directly could update other fields.\n-- This is an accepted Phase 1 trade-off — see Document 5, Section 8 risk note.\n-- Phase 2 mitigation: dedicated update_pastoral_notes Edge Function.\nCREATE POLICY members_update_pastoral_notes\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.get_user_role() = 'pastor'\n    AND assembly_id = public.get_user_assembly_id()\n    AND is_active = true\n  )\n  WITH CHECK (\n    public.get_user_role() = 'pastor'\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- =============================================================================\n-- NO DELETE POLICY on members (IMR-01)\n-- =============================================================================\n-- Hard deletion of member records is permanently blocked for all roles,\n-- including Admin. This is enforced by the ABSENCE of any DELETE policy.\n-- Soft delete is implemented via the UPDATE policies above:\n--   UPDATE members SET is_active = false, deleted_at = now() WHERE id = ...\n-- Any direct DELETE on this table via the API returns HTTP 403 for all roles.\n-- Reference: Document 5, Section 8; Document 3, Section 8, IMR-01\n-- =============================================================================\n-- NO DELETE POLICY exists on public.members.\n\n\n-- =============================================================================\n-- SECTION 2 — member_audit_log: SELECT policy (IMR-02)\n-- Reference: Document 5, Section 9\n-- =============================================================================\n\n-- Only Admin may read audit log entries, scoped to their own assembly.\nCREATE POLICY audit_log_select_admin\n  ON public.member_audit_log\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- =============================================================================\n-- NO INSERT / UPDATE / DELETE POLICIES on member_audit_log (IMR-02)\n-- =============================================================================\n-- Audit log entries are written exclusively by the write_member_audit_log()\n-- SECURITY DEFINER trigger (Migration 9). The trigger bypasses RLS by running\n-- as the database owner.\n--\n-- No INSERT policy  — no role may write audit entries via the API.\n-- No UPDATE policy  — audit log is immutable; no row may be modified.\n-- No DELETE policy  — audit log is immutable; no row may be deleted.\n--\n-- Any API-level INSERT, UPDATE, or DELETE on member_audit_log returns HTTP 403.\n-- Reference: Document 5, Section 9; Document 3, Section 8, IMR-02\n-- =============================================================================\n-- NO INSERT POLICY on public.member_audit_log.\n-- NO UPDATE POLICY on public.member_audit_log.\n-- NO DELETE POLICY on public.member_audit_log.\n\n\n-- =============================================================================\n-- END OF MIGRATION 20260427000014 — Day 24 complete\n-- =============================================================================\n--\n-- Summary of all members policies (after Migrations 13 + 14):\n--   members_select_directory_roles        — SELECT  — admin, pastor, secretary, volunteer (active rows)\n--   members_select_own_member_role        — SELECT  — member (own row via created_by)\n--   members_select_admin_include_deleted  — SELECT  — admin (all rows incl. soft-deleted)\n--   members_insert_admin_secretary        — INSERT  — admin, secretary\n--   members_update_admin_secretary        — UPDATE  — admin, secretary (active rows)\n--   members_update_pastoral_notes         — UPDATE  — pastor (active rows; app restricts to pastoral_notes)\n--   (none)                                — DELETE  — BLOCKED for all roles (IMR-01)\n--\n-- Summary of all member_audit_log policies:\n--   audit_log_select_admin                — SELECT  — admin (own assembly)\n--   (none)                                — INSERT  — BLOCKED (IMR-02; trigger writes only)\n--   (none)                                — UPDATE  — BLOCKED (IMR-02; immutable)\n--   (none)                                — DELETE  — BLOCKED (IMR-02; immutable)\n--\n-- Post-apply verification:\n--\n-- 1. Confirm all members policies exist:\n--    SELECT policyname, cmd\n--    FROM pg_policies\n--    WHERE schemaname = 'public' AND tablename = 'members'\n--    ORDER BY cmd, policyname;\n--\n-- 2. Confirm audit_log policies:\n--    SELECT policyname, cmd\n--    FROM pg_policies\n--    WHERE schemaname = 'public' AND tablename = 'member_audit_log';\n--\n-- 3. Verify IMR-01 — no DELETE policy on members:\n--    SELECT COUNT(*) FROM pg_policies\n--    WHERE schemaname = 'public' AND tablename = 'members' AND cmd = 'DELETE';\n--    -- Expected: 0\n--\n-- 4. Verify IMR-02 — no INSERT/UPDATE/DELETE on member_audit_log:\n--    SELECT COUNT(*) FROM pg_policies\n--    WHERE schemaname = 'public' AND tablename = 'member_audit_log'\n--      AND cmd IN ('INSERT', 'UPDATE', 'DELETE');\n--    -- Expected: 0\n-- ============================================================================="}	rls_members_remaining
20260427000015	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000015\n-- Purpose:  Day 17–23 audit corrections\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Date:     April 27, 2026\n-- =============================================================================\n-- This migration fixes two issues found during the Day 17–24 implementation audit:\n--\n-- ISSUE 1 (Day 18): Missing idx_members_is_active index\n--   Task spec (Document 4, Section 6) lists an index on is_active.\n--   The Day 18 migration omitted it. Added here.\n--\n-- ISSUE 2 (Day 23): members_select_directory_roles missing deleted_at IS NULL\n--   The task spec includes: AND deleted_at IS NULL in the SELECT policy.\n--   Our implementation only had: AND is_active = true\n--   While logically redundant in a well-maintained dataset (is_active = false\n--   when deleted_at IS NOT NULL), the explicit guard is safer and matches the\n--   task spec. Policy recreated with both conditions.\n--\n-- Day 23 Decision (not a bug): members_select_own_member_role uses\n--   created_by = auth.uid() rather than id = auth.uid().\n--   This is an intentional Phase 1 design decision per Document 5, Section 8.\n--   The member's auth.uid() ≠ members.id (members.id is a system UUID).\n--   See DAY_23_DECISIONS.md for full rationale.\n-- =============================================================================\n\n\n-- -----------------------------------------------------------------------------\n-- FIX 1: Add missing is_active index on members (Day 18 gap)\n-- -----------------------------------------------------------------------------\n-- Supports fast queries for suspended members (is_active = false, deleted_at IS NULL)\n-- which are not captured by the membership_status index.\n\nCREATE INDEX IF NOT EXISTS idx_members_is_active\n  ON public.members (assembly_id, is_active)\n  WHERE deleted_at IS NULL","-- -----------------------------------------------------------------------------\n-- FIX 2: Recreate members_select_directory_roles with deleted_at IS NULL guard\n-- (Day 23 gap)\n-- -----------------------------------------------------------------------------\n\nDROP POLICY IF EXISTS members_select_directory_roles ON public.members","CREATE POLICY members_select_directory_roles\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.can_read_directory()\n    AND assembly_id = public.get_user_assembly_id()\n    AND is_active = true\n    AND deleted_at IS NULL\n  )","-- =============================================================================\n-- END OF MIGRATION 20260427000015 — Audit corrections\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n-- 1. Confirm is_active index exists:\n--    SELECT indexname FROM pg_indexes\n--    WHERE schemaname = 'public' AND tablename = 'members'\n--      AND indexname = 'idx_members_is_active';\n--\n-- 2. Confirm the corrected policy includes deleted_at IS NULL:\n--    SELECT policyname, qual FROM pg_policies\n--    WHERE schemaname = 'public' AND tablename = 'members'\n--      AND policyname = 'members_select_directory_roles';\n-- ============================================================================="}	audit_corrections
20260427000016	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000016\n-- Purpose:  members_view — security barrier view with column-level masking\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 1 — Database Foundation\n-- Day:      25\n-- Date:     April 27, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000005_create_members.sql         (members table)\n--   20260427000011_create_helper_functions.sql (get_user_role())\n--   20260427000013_create_rls_policies.sql    (members RLS policies)\n--   20260427000014_rls_members_remaining.sql  (members RLS policies continued)\n-- Reference: Document 5, Section 4.2\n-- =============================================================================\n-- Purpose:\n--   RLS handles ROW-level filtering — which rows a user can see.\n--   This view handles COLUMN-level masking — which fields are visible per role.\n--\n--   Two column groups require masking:\n--     1. emergency_contact_* — hidden from 'volunteer' role (but visible to\n--        'member' so they can view their own emergency contact data).\n--     2. pastoral_notes — hidden from 'secretary', 'volunteer', 'member'.\n--        Visible only to 'admin' and 'pastor'.\n--\n--   security_barrier = true prevents predicate pushdown — a malicious function\n--   in a WHERE clause cannot be used to extract data before the CASE expressions\n--   are evaluated. Required whenever the view applies security restrictions.\n--\n--   ALL application queries must use public.members_view, not public.members\n--   directly. The exception is the write_member_audit_log() trigger, which\n--   operates on the underlying table.\n-- =============================================================================\n-- Day 25 Decision 1: emergency_contact_* includes 'member' role\n--   Task spec allows ('admin', 'pastor', 'secretary').\n--   Document 5 Section 4.2 allows ('admin', 'pastor', 'secretary', 'member').\n--   Document 5 is the authoritative source — 'member' is included so a member\n--   can view their own emergency contact data on their own profile screen.\n-- =============================================================================\n-- Day 25 Decision 2: column name is emergency_contact_relationship\n--   Document 5's view definition uses 'emergency_contact_relation' (no -ship).\n--   Our actual schema column (Migration 5) is 'emergency_contact_relationship'.\n--   The view references the live column name — the Document 5 spec has a typo.\n-- =============================================================================\n-- Day 25 Decision 3: file sequence is 000016, not 000015\n--   Migration 000015 is already taken by the Day 17–24 audit correction file.\n--   This view is assigned the next available sequence number.\n-- =============================================================================\n\n\nCREATE OR REPLACE VIEW public.members_view\nWITH (security_barrier = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.first_name,\n  m.last_name,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.phone_number,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n\n  -- Emergency contact fields\n  -- Visible to: admin, pastor, secretary, member (own record via RLS)\n  -- Hidden from: volunteer\n  -- Reference: Document 5, Section 4.2 + Day 25 Decision 1\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n\n  -- Note: column is emergency_contact_relationship in members table.\n  -- Document 5 section 4.2 shows emergency_contact_relation — that is a typo\n  -- in the spec. The live column name governs here. See Day 25 Decision 2.\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n\n  -- Pastoral notes\n  -- Visible to: admin, pastor only (IMR-03)\n  -- Hidden from: secretary, volunteer, member\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor')\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at\n\nFROM public.members m","COMMENT ON VIEW public.members_view IS\n  'Security barrier view over members. Handles column-level masking of '\n  'emergency_contact_* (hidden from volunteer) and pastoral_notes (hidden '\n  'from secretary, volunteer, member). Row-level filtering is handled by '\n  'the RLS policies on the underlying members table. '\n  'All application queries must use this view, not the table directly. '\n  'Reference: Document 5, Section 4.2; IMR-03.'","-- =============================================================================\n-- END OF MIGRATION 20260427000016 — Phase 1 database layer complete\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n-- 1. Confirm view exists with security_barrier:\n--    SELECT viewname, definition\n--    FROM pg_views\n--    WHERE schemaname = 'public' AND viewname = 'members_view';\n--\n-- 2. Confirm all 5 tables have RLS enabled:\n--    SELECT tablename, rowsecurity\n--    FROM pg_tables\n--    WHERE schemaname = 'public'\n--      AND tablename IN (\n--        'assemblies', 'user_profiles', 'households',\n--        'members', 'member_audit_log'\n--      );\n--    -- Expected: all 5 rows show rowsecurity = true\n--\n-- 3. Confirm column count via view (expect all members columns, 24 total):\n--    SELECT column_name FROM information_schema.columns\n--    WHERE table_schema = 'public' AND table_name = 'members_view'\n--    ORDER BY ordinal_position;\n--\n-- Phase 1 checkpoint (run before Day 26):\n--   [ ] All migration files pushed without errors\n--   [ ] 5 tables present with correct columns\n--   [ ] 4 enum types present\n--   [ ] All indexes present (10 on members + 3 on user_profiles + 2 on audit_log)\n--   [ ] set_updated_at trigger fires on UPDATE (confirmed Day 19)\n--   [ ] write_member_audit_log trigger confirmed (confirmed Day 20)\n--   [ ] All 6 helper functions present\n--   [ ] RLS enabled on all 5 tables\n--   [ ] members_view present with security_barrier = true\n--   [ ] Deferrable FK on households.primary_contact_id present\n-- ============================================================================="}	create_members_view
20260427000017	{"-- =============================================================================\n-- CACI Hub — Migration 20260427000017\n-- Purpose:  Grant table-level privileges to the `authenticated` and `anon`\n--           Postgres roles.\n--\n--           RLS policies control WHICH rows are visible, but Postgres requires\n--           the role to have the underlying table privilege (SELECT/INSERT/etc.)\n--           before it even evaluates RLS. Without these grants, every query\n--           returns 42501 \\"permission denied for table\\" regardless of policies.\n--\n-- Author:   Abraham N. O. Bossman\n-- Day:      28 (bug fix — applied after Day 22 migrations)\n-- =============================================================================\n\n-- -----------------------------------------------------------------------------\n-- authenticated role — users who have signed in via Supabase Auth\n-- RLS policies will further restrict which rows are accessible.\n-- -----------------------------------------------------------------------------\n\nGRANT SELECT                         ON public.assemblies        TO authenticated","GRANT SELECT                         ON public.user_profiles     TO authenticated","GRANT INSERT, UPDATE                 ON public.user_profiles     TO authenticated","GRANT SELECT                         ON public.households        TO authenticated","GRANT INSERT, UPDATE, DELETE         ON public.households        TO authenticated","GRANT SELECT                         ON public.members           TO authenticated","GRANT INSERT, UPDATE                 ON public.members           TO authenticated","GRANT SELECT                         ON public.member_audit_log  TO authenticated","-- No INSERT/UPDATE/DELETE on audit log — written only by SECURITY DEFINER trigger (IMR-02)\n\n-- -----------------------------------------------------------------------------\n-- anon role — unauthenticated requests (should see nothing due to RLS,\n-- but the role must exist as a grantee)\n-- We do NOT grant anon any table access — RLS + absence of grant = 0 rows.\n-- -----------------------------------------------------------------------------\n\n-- (No grants to anon — intentional. All routes require authenticated session.)\n\n-- =============================================================================\n-- END OF MIGRATION 20260427000017\n-- ============================================================================="}	grant_table_privileges
20260428000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260428000001\n-- Purpose:  Data seed for the Admin user.\n--           Ensures the Admin assembly, member record, and user profile\n--           exist in the database.\n--\n--           This is implemented as a migration to ensure it is applied to the\n--           remote database where the standard `seed.sql` might not have\n--           been run.\n--\n-- Author:   Abraham N. O. Bossman\n-- Day:      28 (Data Seed)\n-- =============================================================================\n\n-- -----------------------------------------------------------------------------\n-- 1. Assembly\n-- -----------------------------------------------------------------------------\nINSERT INTO public.assemblies (\n  name,\n  assembly_code,\n  address,\n  digital_address\n)\nVALUES (\n  'Christ Apostolic Church International — Assakae',\n  'GH-ASSAK',\n  'Assakae, Takoradi, Western Region, Ghana',\n  NULL\n)\nON CONFLICT (assembly_code) DO NOTHING","-- -----------------------------------------------------------------------------\n-- 2. Admin member record\n-- -----------------------------------------------------------------------------\nINSERT INTO public.members (\n  id,\n  assembly_id,\n  membership_number,\n  first_name,\n  last_name,\n  phone_number,\n  gender,\n  membership_status,\n  created_by\n)\nVALUES (\n  '8cf54258-0050-423d-b9a3-7f344ead04df',\n  (SELECT id FROM public.assemblies WHERE assembly_code = 'GH-ASSAK'),\n  'CACI-GH-ASSAK-00001',\n  'Abraham',\n  'Bossman',\n  '+233593529509',\n  'male',\n  'active',\n  'deed0df7-d6de-404a-853d-0428c4196c9a'\n)\nON CONFLICT (id) DO NOTHING","-- -----------------------------------------------------------------------------\n-- 3. Admin user_profiles row\n-- -----------------------------------------------------------------------------\nINSERT INTO public.user_profiles (\n  id,\n  assembly_id,\n  role,\n  full_name,\n  is_active\n)\nVALUES (\n  'deed0df7-d6de-404a-853d-0428c4196c9a',\n  (SELECT id FROM public.assemblies WHERE assembly_code = 'GH-ASSAK'),\n  'admin',\n  'Abraham Nhyiraba Obboye Bossman',\n  true\n)\nON CONFLICT (id) DO NOTHING","-- =============================================================================\n-- END OF MIGRATION 20260428000001\n-- ============================================================================="}	seed_admin_data
20260429000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260429000001\n-- Purpose: Grant SELECT permissions on members_view and households\n-- =============================================================================\n\n-- Grant access to the view for authenticated app users\nGRANT SELECT ON public.members_view TO authenticated","GRANT SELECT ON public.members_view TO service_role","-- Ensure authenticated users can also select from households for filters\nGRANT SELECT ON public.households TO authenticated","GRANT SELECT ON public.households TO service_role","-- RLS policies on underlying tables will still enforce assembly-scoping."}	fix_members_view_permissions
20260503063000	{"-- =============================================================================\n-- CACI Hub — Migration 20260503063000\n-- Purpose:  Explicitly grant SELECT/INSERT/UPDATE to service_role.\n--           Ensures Edge Functions (admin context) are never blocked by\n--           table-level Missing Grant errors (42501).\n-- =============================================================================\n\nGRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO service_role","GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO supabase_admin","GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO service_role","GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO supabase_admin"}	grant_service_role_members
20260430000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260430000001\n-- Purpose:  get_next_membership_sequence() — atomic sequence helper\n-- Author:   Abraham N. O. Bossman\n-- Phase:    Phase 4 — Membership Number Generation\n-- Day:      64\n-- Date:     April 30, 2026\n-- =============================================================================\n-- Depends on:\n--   20260427000005_create_members.sql  (members table with membership_number col)\n--   20260427000002_create_assemblies.sql  (assemblies table)\n-- =============================================================================\n-- Returns the CURRENT highest sequence used for a given assembly, so the caller\n-- can do (result + 1) to get the next number.\n-- Uses FOR UPDATE on the aggregate subquery to serialise concurrent calls from\n-- the Edge Function and prevent duplicate membership numbers.\n-- SECURITY DEFINER so the service-role client, which already bypasses RLS, can\n-- still call this without extra grants.\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.get_next_membership_sequence(p_assembly_id uuid)\nRETURNS integer\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_max_seq integer;\nBEGIN\n  -- Lock the relevant rows so concurrent calls queue up rather than racing.\n  -- We derive the sequence by parsing the trailing numeric segment of any\n  -- existing membership_number that matches the CACI-XXX-NNNNN pattern.\n  SELECT COALESCE(\n    MAX(\n      CAST(\n        SPLIT_PART(membership_number, '-', 3) AS integer\n      )\n    ),\n    0\n  )\n  INTO v_max_seq\n  FROM public.members\n  WHERE assembly_id = p_assembly_id\n    AND membership_number IS NOT NULL\n    AND membership_number ~ '^CACI-[A-Z]+-[0-9]+$'\n  FOR UPDATE;           -- row-level lock; serialises concurrent Edge Function calls\n\n  RETURN v_max_seq;\nEND;\n$$","COMMENT ON FUNCTION public.get_next_membership_sequence(uuid) IS\n  'Returns the current highest sequence integer for members in the given assembly. '\n  'Uses FOR UPDATE to serialise concurrent calls and prevent duplicate numbers. '\n  'Result + 1 gives the next sequence to issue. Called by the '\n  'generate-membership-number Edge Function (Day 64).'","-- Grant execute to service_role so the Edge Function can call it\nGRANT EXECUTE ON FUNCTION public.get_next_membership_sequence(uuid) TO service_role","-- =============================================================================\n-- END OF MIGRATION 20260430000001\n-- =============================================================================\n--\n-- Post-apply verification:\n--\n--   SELECT routine_name\n--   FROM information_schema.routines\n--   WHERE routine_schema = 'public'\n--     AND routine_name = 'get_next_membership_sequence';\n--   -- Expected: 1 row\n--\n-- Smoke test (replace <assembly-uuid> with a real one):\n--   SELECT public.get_next_membership_sequence('<assembly-uuid>'::uuid);\n--   -- Expected: 0 if no members assigned yet; N for existing members.\n-- ============================================================================="}	create_membership_sequence_fn
20260430000002	{"-- =============================================================================\n-- CACI Hub — Migration 20260430000002\n-- Purpose:  Fix race condition in membership sequence generation\n-- Author:   Abraham N. O. Bossman (via Day 65 Fix)\n-- Phase:    Phase 4 — Membership Number Generation\n-- Date:     April 30, 2026\n-- =============================================================================\n-- Replaces the Day 64 get_next_membership_sequence function.\n-- The previous version used FOR UPDATE on the members table. However, if there\n-- are no members matching the criteria (e.g. fresh assembly), it locks 0 rows,\n-- failing to serialise concurrent calls. \n-- The true fix is to lock the parent *assembly* row first, which acts as a \n-- guaranteed single lock for all concurrent sequence requests for that assembly.\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.get_next_membership_sequence(p_assembly_id uuid)\nRETURNS integer\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_max_seq integer;\n  v_dummy text;\nBEGIN\n  -- 1. Lock the parent assembly row. This is the crucial fix for the race condition.\n  -- Even if there are 0 members, the assembly row exists. Concurrent calls will be\n  -- blocked here and proceed one by one.\n  SELECT name INTO v_dummy\n  FROM public.assemblies\n  WHERE id = p_assembly_id\n  FOR UPDATE;\n\n  -- 2. Now safely calculate the max sequence. Since we hold the assembly lock,\n  -- no other transaction can be doing this at the same time for this assembly.\n  SELECT COALESCE(\n    MAX(\n      CAST(\n        SPLIT_PART(membership_number, '-', 3) AS integer\n      )\n    ),\n    0\n  )\n  INTO v_max_seq\n  FROM public.members\n  WHERE assembly_id = p_assembly_id\n    AND membership_number IS NOT NULL\n    AND membership_number ~ '^CACI-[A-Z]+-[0-9]+$';\n\n  RETURN v_max_seq;\nEND;\n$$","COMMENT ON FUNCTION public.get_next_membership_sequence(uuid) IS\n  'Returns the current highest sequence integer for members in the given assembly. '\n  'Uses FOR UPDATE on the assemblies table to properly serialise concurrent calls '\n  'preventing duplicate numbers (Day 65 race condition fix).'","-- Grant execute to service_role so the Edge Function can call it\nGRANT EXECUTE ON FUNCTION public.get_next_membership_sequence(uuid) TO service_role","-- =============================================================================\n-- END OF MIGRATION 20260430000002\n-- ============================================================================="}	fix_membership_sequence_race_condition
20260427999999	{"-- 0. Create admin auth user (required for FK)\nINSERT INTO auth.users (\n  id,\n  email,\n  encrypted_password,\n  email_confirmed_at,\n  created_at,\n  updated_at\n)\nVALUES (\n  'deed0df7-d6de-404a-853d-0428c4196c9a',\n  'admin@caci.com',\n  extensions.crypt('password123', extensions.gen_salt('bf')),\n  now(),\n  now(),\n  now()\n)\nON CONFLICT (id) DO NOTHING"}	seed_auth_user
20260430000003	{"-- =============================================================================\n-- CACI Hub — Migration 20260430000003\n-- Purpose:  Atomic membership sequence generation (Fixing race condition)\n-- Author:   Abraham N. O. Bossman (Day 65 Fix)\n-- =============================================================================\n-- We implement the sequence logic in a single atomic database function\n-- to properly prevent the race condition. With FOR UPDATE, we lock the \n-- assembly row until the transaction completes, safely queueing calls.\n-- (FOR UPDATE SKIP LOCKED avoids queuing by bailing out on concurrent calls,\n-- but the correct behaviour for sequence generation is to queue via FOR UPDATE).\n\nCREATE OR REPLACE FUNCTION public.assign_membership_number(p_member_id uuid, p_assembly_id uuid)\nRETURNS text\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_assembly_code text;\n  v_max_seq integer;\n  v_new_seq integer;\n  v_membership_number text;\nBEGIN\n  -- 1. Lock the assembly row to queue concurrent requests.\n  SELECT assembly_code INTO v_assembly_code\n  FROM public.assemblies\n  WHERE id = p_assembly_id\n  FOR UPDATE;\n\n  IF v_assembly_code IS NULL THEN\n    RAISE EXCEPTION 'Assembly not found or could not be locked';\n  END IF;\n\n  -- 2. Calculate the sequence max safely within the lock\n  SELECT COALESCE(\n    MAX(\n      CAST(\n        SPLIT_PART(membership_number, '-', 3) AS integer\n      )\n    ),\n    0\n  )\n  INTO v_max_seq\n  FROM public.members\n  WHERE assembly_id = p_assembly_id\n    AND membership_number IS NOT NULL\n    AND membership_number ~ '^CACI-[A-Z]+-[0-9]+$';\n\n  v_new_seq := v_max_seq + 1;\n  v_membership_number := 'CACI-' || v_assembly_code || '-' || LPAD(v_new_seq::text, 5, '0');\n\n  -- 3. Assign to member record\n  UPDATE public.members\n  SET membership_number = v_membership_number\n  WHERE id = p_member_id;\n\n  RETURN v_membership_number;\nEND;\n$$","COMMENT ON FUNCTION public.assign_membership_number(uuid, uuid) IS\n  'Atomically generates and assigns a membership number. Resolves Day 65 race condition.'","GRANT EXECUTE ON FUNCTION public.assign_membership_number(uuid, uuid) TO service_role"}	atomic_membership_sequence
20260501044602	{"-- Insert the member-photos storage bucket if it doesn't already exist\nINSERT INTO storage.buckets (id, name, public) \nVALUES ('member-photos', 'member-photos', true)\nON CONFLICT (id) DO NOTHING","-- Storage RLS on 'storage.objects' for 'member-photos'\n\n-- 1. Public Read access\nCREATE POLICY \\"Public Access\\" \nON storage.objects FOR SELECT \nUSING (bucket_id = 'member-photos')","-- 2. Authenticated users can INSERT\nCREATE POLICY \\"Auth Insert\\" \nON storage.objects FOR INSERT \nWITH CHECK (bucket_id = 'member-photos' AND auth.role() = 'authenticated')","-- 3. Authenticated users can UPDATE\nCREATE POLICY \\"Auth Update\\" \nON storage.objects FOR UPDATE \nUSING (bucket_id = 'member-photos' AND auth.role() = 'authenticated')","-- 4. Authenticated users can DELETE\nCREATE POLICY \\"Auth Delete\\" \nON storage.objects FOR DELETE \nUSING (bucket_id = 'member-photos' AND auth.role() = 'authenticated')"}	create_member_photos_bucket
20260501044603	{BEGIN,"DROP POLICY IF EXISTS members_update_pastoral_notes ON public.members","CREATE POLICY members_update_pastoral_notes\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.get_user_role() = 'pastor'::public.user_role\n    AND assembly_id = public.get_user_assembly_id()\n    AND is_active = true\n  )\n  WITH CHECK (\n    public.get_user_role() = 'pastor'::public.user_role\n    AND assembly_id = public.get_user_assembly_id()\n  )","CREATE OR REPLACE FUNCTION public.enforce_member_update_columns()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_role public.user_role;\nBEGIN\n  v_role := public.get_user_role();\n\n  IF v_role = 'secretary' THEN\n    IF OLD.pastoral_notes IS DISTINCT FROM NEW.pastoral_notes THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n    END IF;\n  END IF;\n\n  IF v_role = 'pastor' THEN\n    -- Check if ANY column other than pastoral_notes changed\n    IF OLD.first_name IS DISTINCT FROM NEW.first_name OR\n       OLD.last_name IS DISTINCT FROM NEW.last_name OR\n       OLD.occupation IS DISTINCT FROM NEW.occupation OR\n       OLD.gender IS DISTINCT FROM NEW.gender OR\n       OLD.membership_status IS DISTINCT FROM NEW.membership_status OR\n       OLD.assembly_id IS DISTINCT FROM NEW.assembly_id OR\n       OLD.phone_number IS DISTINCT FROM NEW.phone_number\n    THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n    END IF;\n  END IF;\n\n  RETURN NEW;\nEND;\n$$","DROP TRIGGER IF EXISTS trg_enforce_member_update_columns on public.members","CREATE TRIGGER trg_enforce_member_update_columns\n  BEFORE UPDATE ON public.members\n  FOR EACH ROW\n  EXECUTE FUNCTION public.enforce_member_update_columns()",COMMIT}	fix_members_mutation_trigger
20260501044605	{BEGIN,"-- Fix RLS leak in view\nALTER VIEW public.members_view SET (security_invoker = true)","-- Strict 403 Trigger for all roles\nCREATE OR REPLACE FUNCTION public.enforce_member_update_columns()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_role public.user_role;\nBEGIN\n  v_role := public.get_user_role();\n\n  -- Admin: No restrictions in trigger\n  IF v_role = 'admin' THEN\n    RETURN NEW;\n  END IF;\n\n  -- Secretary: Block pastoral_notes\n  IF v_role = 'secretary' THEN\n    IF OLD.pastoral_notes IS DISTINCT FROM NEW.pastoral_notes THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  -- Pastor: Only allow pastoral_notes\n  IF v_role = 'pastor' THEN\n    IF OLD.first_name IS DISTINCT FROM NEW.first_name OR\n       OLD.last_name IS DISTINCT FROM NEW.last_name OR\n       OLD.occupation IS DISTINCT FROM NEW.occupation OR\n       OLD.gender IS DISTINCT FROM NEW.gender OR\n       OLD.membership_status IS DISTINCT FROM NEW.membership_status OR\n       OLD.assembly_id IS DISTINCT FROM NEW.assembly_id OR\n       OLD.phone_number IS DISTINCT FROM NEW.phone_number\n    THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  -- Volunteer and Member: Block ALL updates to get 403\n  IF v_role IN ('volunteer', 'member') THEN\n    RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n  END IF;\n\n  -- Default deny (if any other role somehow calls it)\n  RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\nEND;\n$$",COMMIT}	fix_members_view_and_mutation_403
20260501044606	{BEGIN,"-- Dummy UPDATE policies for member and volunteer roles\n-- These allow the row to be 'matched' for update so the BEFORE UPDATE trigger can fire and RAISE EXCEPTION (403)\nCREATE POLICY members_update_member_role_trigger_allow\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.get_user_role() = 'member'\n    AND created_by = auth.uid()\n  )","CREATE POLICY members_update_volunteer_role_trigger_allow\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.get_user_role() = 'volunteer'\n    AND assembly_id = public.get_user_assembly_id()\n  )",COMMIT}	enable_403_triggers_for_unauthorized_roles
20260501044607	{"-- =============================================================================\n-- CACI Hub — Migration\n-- Purpose: Fix PostgREST implicit join by linking changed_by to user_profiles\n-- =============================================================================\n\nALTER TABLE public.member_audit_log\n  DROP CONSTRAINT IF EXISTS member_audit_log_changed_by_fkey","ALTER TABLE public.member_audit_log\n  ADD CONSTRAINT member_audit_log_changed_by_fkey\n  FOREIGN KEY (changed_by)\n  REFERENCES public.user_profiles(id)\n  ON DELETE SET NULL"}	fix_member_audit_log_fk
20260501161943	{"-- =============================================================================\n-- CACI Hub — Migration\n-- Purpose: Fix the SPLIT_PART and Regex sequence retrieval for membership numbers.\n-- Date: 2026-05-01\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.assign_membership_number(p_member_id uuid, p_assembly_id uuid)\nRETURNS text\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_assembly_code text;\n  v_max_seq integer;\n  v_new_seq integer;\n  v_membership_number text;\nBEGIN\n  -- 1. Lock the assembly row to queue concurrent requests.\n  SELECT assembly_code INTO v_assembly_code\n  FROM public.assemblies\n  WHERE id = p_assembly_id\n  FOR UPDATE;\n\n  IF v_assembly_code IS NULL THEN\n    RAISE EXCEPTION 'Assembly not found or could not be locked';\n  END IF;\n\n  -- 2. Calculate the sequence max safely within the lock\n  SELECT COALESCE(\n    MAX(\n      CAST(\n        SPLIT_PART(membership_number, '-', 4) AS integer\n      )\n    ),\n    0\n  )\n  INTO v_max_seq\n  FROM public.members\n  WHERE assembly_id = p_assembly_id\n    AND membership_number IS NOT NULL\n    AND membership_number ~ '^CACI-[A-Z]{2}-[A-Z]{3,6}-[0-9]+$';\n\n  v_new_seq := v_max_seq + 1;\n  v_membership_number := 'CACI-' || v_assembly_code || '-' || LPAD(v_new_seq::text, 5, '0');\n\n  -- 3. Assign to member record\n  UPDATE public.members\n  SET membership_number = v_membership_number\n  WHERE id = p_member_id;\n\n  RETURN v_membership_number;\nEND;\n$$"}	fix_assign_membership_number
20260501175358	{"-- =============================================================================\n-- CACI Hub — Migration\n-- Purpose: Fix membership sequence extraction to be robust against any assembly format.\n-- Date: 2026-05-01\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.assign_membership_number(p_member_id uuid, p_assembly_id uuid)\nRETURNS text\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_assembly_code text;\n  v_max_seq integer;\n  v_new_seq integer;\n  v_membership_number text;\nBEGIN\n  -- 1. Lock the assembly row to queue concurrent requests.\n  SELECT assembly_code INTO v_assembly_code\n  FROM public.assemblies\n  WHERE id = p_assembly_id\n  FOR UPDATE;\n\n  IF v_assembly_code IS NULL THEN\n    RAISE EXCEPTION 'Assembly not found or could not be locked';\n  END IF;\n\n  -- 2. Calculate the sequence max safely within the lock, using a robust regex to extract digits\n  SELECT COALESCE(\n    MAX(\n      CAST(\n        SUBSTRING(membership_number FROM '-([0-9]+)$') AS integer\n      )\n    ),\n    0\n  )\n  INTO v_max_seq\n  FROM public.members\n  WHERE assembly_id = p_assembly_id\n    AND membership_number IS NOT NULL\n    AND membership_number LIKE ('CACI-' || v_assembly_code || '-%');\n\n  v_new_seq := v_max_seq + 1;\n  v_membership_number := 'CACI-' || v_assembly_code || '-' || LPAD(v_new_seq::text, 5, '0');\n\n  -- 3. Assign to member record\n  UPDATE public.members\n  SET membership_number = v_membership_number\n  WHERE id = p_member_id;\n\n  RETURN v_membership_number;\nEND;\n$$"}	fix_membership_number_generation_robust
20260501181500	{"-- =============================================================================\n-- CACI Hub — Migration\n-- Purpose: Make assign_membership_number idempotent and robust against retries.\n-- Date: 2026-05-01\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.assign_membership_number(p_member_id uuid, p_assembly_id uuid)\nRETURNS text\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_assembly_code text;\n  v_max_seq integer;\n  v_new_seq integer;\n  v_membership_number text;\n  v_existing_number text;\nBEGIN\n  -- 1. Check if the member already has a membership number (Idempotency)\n  SELECT membership_number INTO v_existing_number\n  FROM public.members\n  WHERE id = p_member_id;\n\n  IF v_existing_number IS NOT NULL THEN\n    RETURN v_existing_number;\n  END IF;\n\n  -- 2. Lock the assembly row to queue concurrent requests.\n  SELECT assembly_code INTO v_assembly_code\n  FROM public.assemblies\n  WHERE id = p_assembly_id\n  FOR UPDATE;\n\n  IF v_assembly_code IS NULL THEN\n    RAISE EXCEPTION 'Assembly not found or could not be locked';\n  END IF;\n\n  -- 3. Calculate the sequence max safely within the lock.\n  -- We include both active and soft-deleted members to ensure sequences never overlap.\n  -- We also ensure the regex matches exactly the trailing digits.\n  SELECT COALESCE(\n    MAX(\n      CAST(\n        SUBSTRING(membership_number FROM '-([0-9]+)$') AS integer\n      )\n    ),\n    0\n  )\n  INTO v_max_seq\n  FROM public.members\n  WHERE assembly_id = p_assembly_id\n    AND membership_number IS NOT NULL\n    AND membership_number LIKE ('CACI-' || v_assembly_code || '-%');\n\n  v_new_seq := v_max_seq + 1;\n  v_membership_number := 'CACI-' || v_assembly_code || '-' || LPAD(v_new_seq::text, 5, '0');\n\n  -- 4. Assign to member record\n  UPDATE public.members\n  SET membership_number = v_membership_number\n  WHERE id = p_member_id;\n\n  RETURN v_membership_number;\nEND;\n$$"}	fix_assign_membership_number_idempotent
20260502000000	{"-- =============================================================================\n-- CACI Hub — Migration 20260502000000\n-- Purpose:  Ensure the seeded admin member row has `email` set so\n--           `myMemberProfileProvider` can resolve the directory row when the\n--           user signs in with email/password (Auth has email; phone may be empty).\n--\n-- Implementation note:\n--   1. Migration sessions have no JWT — `auth.uid()` / `get_user_role()` are NULL,\n--      so normal RLS blocks UPDATEs on `members`.\n--   2. `enforce_member_update_columns` (BEFORE UPDATE) treats NULL role as\n--      \\"default deny\\" and raises the same error text as RLS until migration\n--      `20260502040500` applies. So we must skip triggers for this repair.\n--\n--   Pattern: disable RLS for this batch, set `session_replication_role = replica`\n--   so user triggers do not fire, run UPDATE, restore RLS.\n--   See: https://www.postgresql.org/docs/current/runtime-config-client.html\n-- =============================================================================\n\nALTER TABLE public.members DISABLE ROW LEVEL SECURITY","SET LOCAL session_replication_role = 'replica'","UPDATE public.members\nSET email = 'obboyebossman@gmail.com'\nWHERE id = '8cf54258-0050-423d-b9a3-7f344ead04df'\n  AND (email IS NULL OR btrim(email) = '')","ALTER TABLE public.members ENABLE ROW LEVEL SECURITY"}	backfill_admin_member_email
20260502040000	{"-- Migration: Automatic linking of primary contact to household membership\n-- Description: When a member is assigned as the primary contact of a household, \n-- they are automatically added as a member of that household.\n\nCREATE OR REPLACE FUNCTION public.link_household_primary_contact()\nRETURNS TRIGGER AS $$\nBEGIN\n    -- If primary_contact_id is set or changed\n    IF NEW.primary_contact_id IS NOT NULL THEN\n        UPDATE public.members\n        SET household_id = NEW.id\n        WHERE id = NEW.primary_contact_id;\n    END IF;\n    RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql","-- Trigger for households table\nDROP TRIGGER IF EXISTS trg_link_household_primary_contact ON public.households","CREATE TRIGGER trg_link_household_primary_contact\nAFTER INSERT OR UPDATE OF primary_contact_id ON public.households\nFOR EACH ROW\nEXECUTE FUNCTION public.link_household_primary_contact()"}	auto_link_primary_contact
20260502040500	{"-- Migration: Enforce Primary Contact Uniqueness and Auto-Linking Security\n-- Description: \n-- 1. Makes primary_contact_id UNIQUE in households table.\n-- 2. Updates enforce_member_update_columns to allow systemic updates (superuser/service_role).\n\nBEGIN","-- 0. Existing data may reference the same primary_contact_id from multiple households.\n--    The unique index below requires at most one household per contact. Keep the\n--    lexicographically smallest household id per contact; clear the rest.\nALTER TABLE public.households DISABLE ROW LEVEL SECURITY","SET LOCAL session_replication_role = 'replica'","WITH keeper AS (\n  SELECT DISTINCT ON (primary_contact_id) id AS keeper_id, primary_contact_id\n  FROM public.households\n  WHERE primary_contact_id IS NOT NULL\n  ORDER BY primary_contact_id, id ASC\n)\nUPDATE public.households h\nSET primary_contact_id = NULL\nFROM keeper k\nWHERE h.primary_contact_id = k.primary_contact_id\n  AND h.id <> k.keeper_id","ALTER TABLE public.households ENABLE ROW LEVEL SECURITY","-- 1. Ensure primary_contact_id is UNIQUE (Rule #2: Member cannot be part of another/multiple as primary)\n-- Dropping old non-unique index if it exists\nDROP INDEX IF EXISTS public.idx_households_primary_contact_id","CREATE UNIQUE INDEX idx_households_primary_contact_id ON public.households (primary_contact_id) WHERE (primary_contact_id IS NOT NULL)","-- 2. Refactor enforce_member_update_columns to allow internal system updates\nCREATE OR REPLACE FUNCTION public.enforce_member_update_columns()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_role public.user_role;\nBEGIN\n  v_role := public.get_user_role();\n\n  -- Allow superuser (v_role is null) and service_role to proceed\n  -- This is critical for triggers like link_household_primary_contact to work\n  IF v_role IS NULL OR v_role::text = 'service_role' THEN\n    RETURN NEW;\n  END IF;\n\n  -- Admin: No restrictions in trigger\n  IF v_role = 'admin' THEN\n    RETURN NEW;\n  END IF;\n\n  -- Secretary: Block pastoral_notes\n  IF v_role = 'secretary' THEN\n    IF OLD.pastoral_notes IS DISTINCT FROM NEW.pastoral_notes THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  -- Pastor: Only allow pastoral_notes\n  IF v_role = 'pastor' THEN\n    IF OLD.first_name IS DISTINCT FROM NEW.first_name OR\n       OLD.last_name IS DISTINCT FROM NEW.last_name OR\n       OLD.occupation IS DISTINCT FROM NEW.occupation OR\n       OLD.gender IS DISTINCT FROM NEW.gender OR\n       OLD.membership_status IS DISTINCT FROM NEW.membership_status OR\n       OLD.assembly_id IS DISTINCT FROM NEW.assembly_id OR\n       OLD.phone_number IS DISTINCT FROM NEW.phone_number\n    THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  -- Volunteer and Member: Block ALL updates to get 403\n  IF v_role IN ('volunteer', 'member') THEN\n    RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\n  END IF;\n\n  -- Default deny (if any other role somehow calls it)\n  RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"' USING ERRCODE = '42501';\nEND;\n$$",COMMIT}	household_member_constraints
20260502053000	{"-- Migration: get_available_primary_contacts RPC\n-- Description: Returns a list of assembly members matching search criteria,\n-- explicitly excluding members who are ALREADY primary contacts of other households.\n-- This prevents PGRST116 Unique Constraint violations natively in the UI.\n\nCREATE OR REPLACE FUNCTION public.get_available_primary_contacts(\n  p_assembly_id UUID, \n  p_search TEXT, \n  p_current_household_id UUID DEFAULT NULL\n)\nRETURNS TABLE(id UUID, first_name TEXT, last_name TEXT, phone_number TEXT)\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nBEGIN\n  RETURN QUERY\n  SELECT m.id, m.first_name, m.last_name, m.phone_number\n  FROM public.members_view m\n  WHERE m.assembly_id = p_assembly_id\n    AND m.is_active = true\n    AND (\n      p_search IS NULL \n      OR p_search = '' \n      OR m.first_name ILIKE '%' || p_search || '%' \n      OR m.last_name ILIKE '%' || p_search || '%'\n    )\n    AND NOT EXISTS (\n       SELECT 1 FROM public.households h \n       WHERE h.primary_contact_id = m.id \n         AND (p_current_household_id IS NULL OR h.id != p_current_household_id)\n    )\n  ORDER BY m.last_name, m.first_name;\nEND;\n$$"}	get_available_primary_contacts
20260502100000	{"-- Link members.managed login account (one per member when set).\nALTER TABLE public.members\n  ADD COLUMN IF NOT EXISTS auth_user_id uuid\n    REFERENCES auth.users (id) ON DELETE SET NULL","CREATE UNIQUE INDEX IF NOT EXISTS idx_members_auth_user_id_unique\n  ON public.members (auth_user_id)\n  WHERE auth_user_id IS NOT NULL","COMMENT ON COLUMN public.members.auth_user_id IS\n  'Supabase Auth user linked to this member (admin-provisioned login). '\n  'NULL means no app login yet.'","-- Recreate members_view to expose auth_user_id (admin uses it to filter “no account yet”).\nCREATE OR REPLACE VIEW public.members_view\nWITH (security_barrier = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.first_name,\n  m.last_name,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.phone_number,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor')\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at,\n  m.auth_user_id\nFROM public.members m"}	members_auth_user_id
20260509000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260509000001\n-- Purpose:  Restore member_audit_log.changed_by FK to auth.users.\n--           Migration 20260501044607 incorrectly pointed it to user_profiles,\n--           which breaks audit logging when a user has no profile row yet\n--           (e.g. during provisioning or after profile deletion).\n-- =============================================================================\n\nALTER TABLE public.member_audit_log\n  DROP CONSTRAINT IF EXISTS member_audit_log_changed_by_fkey","ALTER TABLE public.member_audit_log\n  ADD CONSTRAINT member_audit_log_changed_by_fkey\n  FOREIGN KEY (changed_by)\n  REFERENCES auth.users(id)\n  ON DELETE SET NULL"}	fix_audit_log_fk
20260509000002	{"-- =============================================================================\n-- CACI Hub — Migration 20260509000002\n-- Purpose:  Revoke INSERT/UPDATE/DELETE on member_audit_log from service_role\n--           and supabase_admin. Migration 20260503063000 granted DELETE/INSERT/\n--           UPDATE on ALL tables, which violated IMR-02 (audit log is immutable;\n--           written only by the SECURITY DEFINER trigger).\n-- =============================================================================\n\nREVOKE INSERT, UPDATE, DELETE ON public.member_audit_log FROM service_role","REVOKE INSERT, UPDATE, DELETE ON public.member_audit_log FROM supabase_admin"}	fix_access on member_audit_log _from_services_role
20260509000003	{"-- =============================================================================\n-- CACI Hub — Migration 20260509000003\n-- Purpose:  Replace overly permissive member-photos storage policies with\n--           ownership-scoped versions. Previously any authenticated user could\n--           overwrite any other user's photo. Photos are now stored under a\n--           per-user prefix: member-photos/<auth.uid()>/<filename>.\n-- =============================================================================\n\n-- Drop the old permissive policies\nDROP POLICY IF EXISTS \\"Auth Insert\\" ON storage.objects","DROP POLICY IF EXISTS \\"Auth Update\\" ON storage.objects","DROP POLICY IF EXISTS \\"Auth Delete\\" ON storage.objects","DROP POLICY IF EXISTS \\"Public Access\\" ON storage.objects","-- Public read — anyone can view member photos (URLs are used in the directory).\nCREATE POLICY \\"member_photos_public_read\\"\n  ON storage.objects FOR SELECT\n  USING (bucket_id = 'member-photos')","-- Insert — authenticated users may only upload under their own UID prefix.\nCREATE POLICY \\"member_photos_owner_insert\\"\n  ON storage.objects FOR INSERT\n  WITH CHECK (\n    bucket_id = 'member-photos'\n    AND auth.role() = 'authenticated'\n    AND (storage.foldername(name))[1] = auth.uid()::text\n  )","-- Update — authenticated users may only update their own files.\nCREATE POLICY \\"member_photos_owner_update\\"\n  ON storage.objects FOR UPDATE\n  USING (\n    bucket_id = 'member-photos'\n    AND auth.role() = 'authenticated'\n    AND (storage.foldername(name))[1] = auth.uid()::text\n  )","-- Delete — authenticated users may only delete their own files.\nCREATE POLICY \\"member_photos_owner_delete\\"\n  ON storage.objects FOR DELETE\n  USING (\n    bucket_id = 'member-photos'\n    AND auth.role() = 'authenticated'\n    AND (storage.foldername(name))[1] = auth.uid()::text\n  )"}	scope_members_photos_storage_policies
20260509000004	{"-- =============================================================================\n-- CACI Hub — Migration 20260509000004\n-- Purpose:  Fix the Pastor branch in enforce_member_update_columns.\n--           The previous implementation used an incomplete deny-list —\n--           fields like email, physical_address, marital_status, household_id,\n--           is_active, deleted_at, profile_photo_url etc. were not checked,\n--           so a Pastor could update them directly via the API.\n--           Replaced with an allow-list: only pastoral_notes may change.\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.enforce_member_update_columns()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_role public.user_role;\nBEGIN\n  v_role := public.get_user_role();\n\n  -- Allow internal system calls (triggers, migrations, service role).\n  IF v_role IS NULL THEN\n    RETURN NEW;\n  END IF;\n\n  -- Admin: unrestricted.\n  IF v_role = 'admin' THEN\n    RETURN NEW;\n  END IF;\n\n  -- Secretary: may update any field EXCEPT pastoral_notes.\n  IF v_role = 'secretary' THEN\n    IF OLD.pastoral_notes IS DISTINCT FROM NEW.pastoral_notes THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n        USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  -- Pastor: allow-list — ONLY pastoral_notes may change.\n  -- Any other column change is rejected.\n  IF v_role = 'pastor' THEN\n    IF OLD.first_name                    IS DISTINCT FROM NEW.first_name OR\n       OLD.last_name                     IS DISTINCT FROM NEW.last_name OR\n       OLD.date_of_birth                 IS DISTINCT FROM NEW.date_of_birth OR\n       OLD.gender                        IS DISTINCT FROM NEW.gender OR\n       OLD.marital_status                IS DISTINCT FROM NEW.marital_status OR\n       OLD.phone_number                  IS DISTINCT FROM NEW.phone_number OR\n       OLD.email                         IS DISTINCT FROM NEW.email OR\n       OLD.physical_address              IS DISTINCT FROM NEW.physical_address OR\n       OLD.occupation                    IS DISTINCT FROM NEW.occupation OR\n       OLD.facebook_url                  IS DISTINCT FROM NEW.facebook_url OR\n       OLD.whatsapp_number               IS DISTINCT FROM NEW.whatsapp_number OR\n       OLD.instagram_url                 IS DISTINCT FROM NEW.instagram_url OR\n       OLD.emergency_contact_name        IS DISTINCT FROM NEW.emergency_contact_name OR\n       OLD.emergency_contact_phone       IS DISTINCT FROM NEW.emergency_contact_phone OR\n       OLD.emergency_contact_relationship IS DISTINCT FROM NEW.emergency_contact_relationship OR\n       OLD.membership_status             IS DISTINCT FROM NEW.membership_status OR\n       OLD.join_date                     IS DISTINCT FROM NEW.join_date OR\n       OLD.household_id                  IS DISTINCT FROM NEW.household_id OR\n       OLD.profile_photo_url             IS DISTINCT FROM NEW.profile_photo_url OR\n       OLD.is_active                     IS DISTINCT FROM NEW.is_active OR\n       OLD.deleted_at                    IS DISTINCT FROM NEW.deleted_at OR\n       OLD.assembly_id                   IS DISTINCT FROM NEW.assembly_id OR\n       OLD.membership_number             IS DISTINCT FROM NEW.membership_number OR\n       OLD.auth_user_id                  IS DISTINCT FROM NEW.auth_user_id\n    THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n        USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  -- Volunteer and Member: block all updates.\n  IF v_role IN ('volunteer', 'member') THEN\n    RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n      USING ERRCODE = '42501';\n  END IF;\n\n  -- Default deny for any future role not yet handled.\n  RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n    USING ERRCODE = '42501';\nEND;\n$$"}	pastor_branch_enforce_member_update_columns
20260509000005	{"-- =============================================================================\n-- CACI Hub — Migration 20260509000005\n-- Purpose:  Replace the Phase 1 members_select_own_member_role policy.\n--           The old policy used created_by = auth.uid() as a workaround\n--           because members.auth_user_id did not exist yet. Now that\n--           auth_user_id is in place (Migration 20260502100000), members\n--           can be correctly identified by their linked Auth account.\n-- =============================================================================\n\nDROP POLICY IF EXISTS members_select_own_member_role ON public.members","CREATE POLICY members_select_own_member_role\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.get_user_role() = 'member'\n    AND auth_user_id = auth.uid()\n  )"}	fix_members_select_own_member_role_to_use_auth_user_id
20260516000000	{"-- =============================================================================\n-- CACI Hub — Migration 20260516000000\n-- Purpose:  Grant SELECT on public.user_profiles to the anon role.\n-- \n--           This migration silences the noisy 42501 \\"permission denied\\" errors\n--           observed in the logs when a session becomes invalid. When the\n--           auth session fails (e.g., refresh token exhaustion), the client\n--           defaults to the 'anon' role.\n-- \n--           Granting SELECT allows the PostgREST client to return a clean\n--           404 or empty response (filtered by RLS) instead of a hard\n--           Postgres error. RLS policies already ensure that the anon role\n--           cannot actually read any data.\n--\n-- Author:   Antigravity AI\n-- Date:     May 16, 2026\n-- =============================================================================\n\nGRANT SELECT ON public.user_profiles TO anon","-- Verification of RLS still being active and restrictive for anon:\n-- SELECT * FROM public.user_profiles; -- Should return 0 rows for anon.\n\n-- =============================================================================\n-- END OF MIGRATION 20260516000000\n-- ============================================================================="}	grant_anon_user_profile_select
20260521000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260521000001\n-- Purpose:  Allow public (anon) access to the assemblies table.\n--           Required for the unauthenticated Assembly Selection screen.\n-- Author:   Antigravity AI\n-- Date:     May 21, 2026\n-- =============================================================================\n\n-- 1. Grant SELECT privilege to the anon role\nGRANT SELECT ON public.assemblies TO anon","-- 2. Create RLS policy for anonymous SELECT\n-- This allows anyone to see the list of active assemblies before logging in.\nCREATE POLICY assemblies_select_public\n  ON public.assemblies\n  FOR SELECT\n  TO anon\n  USING (is_active = true)","-- =============================================================================\n-- END OF MIGRATION 20260521000001\n-- ============================================================================="}	allow_anon_assemblies_select
20260525064305	{"-- 1. Add the new column to the base table\nALTER TABLE public.members\nADD COLUMN other_names text","-- 2. Update the members_view to include the new column\n-- We recreate the view with the identical security policies\n-- and add 'm.other_names' right after 'm.last_name'.\nCREATE OR REPLACE VIEW public.members_view\nWITH (security_barrier = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.first_name,\n  m.last_name,\n  m.other_names,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.phone_number,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n\n  -- Emergency contact fields\n  -- Visible to: admin, pastor, secretary, member (own record via RLS)\n  -- Hidden from: volunteer\n  -- Reference: Document 5, Section 4.2 + Day 25 Decision 1\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n\n  -- Note: column is emergency_contact_relationship in members table.\n  -- Document 5 section 4.2 shows emergency_contact_relation — that is a typo\n  -- in the spec. The live column name governs here. See Day 25 Decision 2.\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n\n  -- Pastoral notes\n  -- Visible to: admin, pastor only (IMR-03)\n  -- Hidden from: secretary, volunteer, member\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor')\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at\n\nFROM public.members m","COMMENT ON VIEW public.members_view IS\n  'Security barrier view over members. Handles column-level masking of '\n  'emergency_contact_* (hidden from volunteer) and pastoral_notes (hidden '\n  'from secretary, volunteer, member). Row-level filtering is handled by '\n  'the RLS policies on the underlying members table. '\n  'All application queries must use this view, not the table directly. '\n  'Reference: Document 5, Section 4.2; IMR-03. Includes other_names column.'"}	add_other_names_field
20260525120926	{"-- =============================================================================\n-- CACI Hub — Migration 20260525120926\n-- Purpose:  Re-grant SELECT on members_view to authenticated and service_role.\n--           The previous migration (20260525064305) used DROP VIEW which wiped\n--           all grants on the view. This restores access.\n-- =============================================================================\n\nGRANT SELECT ON public.members_view TO authenticated","GRANT SELECT ON public.members_view TO service_role"}	regrant_members_view
20260525123900	{"-- =============================================================================\n-- CACI Hub — Migration 20260525123848\n-- Purpose:  Phase 1.2 - Backfill admin auth_user_id\n-- =============================================================================\n\nUPDATE public.members\nSET auth_user_id = 'deed0df7-d6de-404a-853d-0428c4196c9a'\nWHERE id = '8cf54258-0050-423d-b9a3-7f344ead04df'"}	backfill_admin_auth_id
20260526000001	{"ALTER TABLE public.assemblies\n  ADD COLUMN IF NOT EXISTS default_member_password text","COMMENT ON COLUMN public.assemblies.default_member_password IS\n  'Assembly-level temporary password for members with no email.\n   Set once by admin via the set-assembly-default-password Edge Function.\n   NULL means not yet configured. Never stored per-member.'"}	add_assembly_default_password
20260526000002	{"ALTER TABLE public.user_profiles\n  ADD COLUMN IF NOT EXISTS must_change_password boolean NOT NULL DEFAULT false","COMMENT ON COLUMN public.user_profiles.must_change_password IS\n  'True when account was provisioned with a default or custom password.\n   Forces a non-dismissable password change screen on first login.\n   Cleared to false after the member sets their own password.'"}	add_must_change_password
20260526000003	{"ALTER TABLE public.members\n  ALTER COLUMN phone_number DROP NOT NULL,\n  ALTER COLUMN email        DROP NOT NULL","ALTER TABLE public.members\n  ADD CONSTRAINT chk_members_contact_required\n  CHECK (\n    phone_number IS NOT NULL\n    OR email IS NOT NULL\n  )","COMMENT ON CONSTRAINT chk_members_contact_required ON public.members IS\n  'At least one of phone_number or email must be provided.\n   Enforced here and mirrored in the CreateMemberSchema Zod schema.'"}	member_contact_optional
20260526000004	{"-- Migration: 20260526000004_create_roles_permissions\n-- Adds the multi-tenant custom roles & permissions layer.\n--\n-- What this does NOT touch:\n--   - user_profiles.role (the existing user_role enum) — still powers all RLS helpers\n--   - Any existing RLS policy\n--\n-- New tables: permissions, assembly_roles, role_permissions\n-- New column:  user_profiles.role_id (nullable FK → assembly_roles)\n-- New trigger: sync_user_permissions_to_jwt — fires on user_profiles UPDATE\n\n-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 1: System permissions catalogue\n-- Only the developer inserts rows; no API writes allowed (enforced by RLS).\n-- ─────────────────────────────────────────────────────────────────────────────\nCREATE TABLE IF NOT EXISTS public.permissions (\n  id          TEXT PRIMARY KEY,        -- e.g. 'member:invite'\n  description TEXT\n)","-- Seed the initial permission set\nINSERT INTO public.permissions (id, description) VALUES\n  ('member:invite',     'Provision new user accounts'),\n  ('member:view_all',   'View full member directory'),\n  ('member:edit',       'Create and update member records'),\n  ('financials:view',   'View tithing and financial history'),\n  ('financials:write',  'Log tithes, offerings, and expenses'),\n  ('attendance:mark',   'Record service and event attendance'),\n  ('sermon:edit',       'Create, edit, or delete sermons')\nON CONFLICT (id) DO NOTHING","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 2: Assembly-scoped custom roles\n-- ─────────────────────────────────────────────────────────────────────────────\nCREATE TABLE IF NOT EXISTS public.assembly_roles (\n  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id  UUID NOT NULL REFERENCES public.assemblies(id) ON DELETE CASCADE,\n  name         TEXT NOT NULL,\n  description  TEXT,\n  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),\n  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),\n  UNIQUE (assembly_id, name)\n)","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 3: Role ↔ Permission junction\n-- ─────────────────────────────────────────────────────────────────────────────\nCREATE TABLE IF NOT EXISTS public.role_permissions (\n  role_id       UUID NOT NULL REFERENCES public.assembly_roles(id) ON DELETE CASCADE,\n  permission_id TEXT NOT NULL REFERENCES public.permissions(id)    ON DELETE CASCADE,\n  PRIMARY KEY (role_id, permission_id)\n)","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 4: Add role_id FK to user_profiles\n-- Sits alongside the existing `role` enum column — no existing policies break.\n-- ─────────────────────────────────────────────────────────────────────────────\nALTER TABLE public.user_profiles\n  ADD COLUMN IF NOT EXISTS role_id UUID\n    REFERENCES public.assembly_roles(id)\n    ON DELETE SET NULL","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 5: JWT sync\n--\n-- When a user's role_id or assembly_id changes, collect all permission_ids\n-- for that role and write them (plus assembly_id) into auth.users.raw_app_meta_data.\n--\n-- Result inside the JWT app_metadata:\n--   { \\"assembly_id\\": \\"<uuid>\\", \\"permissions\\": [\\"member:invite\\", \\"financials:view\\"] }\n-- ─────────────────────────────────────────────────────────────────────────────\n\n-- Helper function (SECURITY DEFINER so it can write auth.users)\nCREATE OR REPLACE FUNCTION public.sync_user_permissions_to_jwt()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_permissions TEXT[];\nBEGIN\n  -- Collect permission IDs for the new role (empty array when role_id IS NULL)\n  IF NEW.role_id IS NOT NULL THEN\n    SELECT ARRAY_AGG(rp.permission_id)\n      INTO v_permissions\n      FROM public.role_permissions rp\n     WHERE rp.role_id = NEW.role_id;\n  ELSE\n    v_permissions := ARRAY[]::TEXT[];\n  END IF;\n\n  -- Coalesce NULL to empty array\n  v_permissions := COALESCE(v_permissions, ARRAY[]::TEXT[]);\n\n  -- Write into auth.users.raw_app_meta_data (merges with existing keys)\n  UPDATE auth.users\n     SET raw_app_meta_data = raw_app_meta_data\n       || jsonb_build_object(\n            'assembly_id',  NEW.assembly_id,\n            'permissions',  to_jsonb(v_permissions)\n          )\n   WHERE id = NEW.id;\n\n  RETURN NEW;\nEND;\n$$","-- Drop old trigger if it exists (idempotent)\nDROP TRIGGER IF EXISTS sync_permissions_on_profile_update ON public.user_profiles","-- Fire after UPDATE of role_id or assembly_id\nCREATE TRIGGER sync_permissions_on_profile_update\n  AFTER UPDATE OF role_id, assembly_id\n  ON public.user_profiles\n  FOR EACH ROW\n  EXECUTE FUNCTION public.sync_user_permissions_to_jwt()","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 6: RLS\n-- ─────────────────────────────────────────────────────────────────────────────\n\n-- permissions: anyone authenticated can SELECT; no API write access\nALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY","CREATE POLICY \\"permissions_select_authenticated\\"\n  ON public.permissions FOR SELECT\n  TO authenticated\n  USING (true)","-- assembly_roles: scoped to the user's own assembly; mutations restricted to admin\nALTER TABLE public.assembly_roles ENABLE ROW LEVEL SECURITY","CREATE POLICY \\"assembly_roles_select\\"\n  ON public.assembly_roles FOR SELECT\n  TO authenticated\n  USING (assembly_id = public.get_user_assembly_id())","CREATE POLICY \\"assembly_roles_insert\\"\n  ON public.assembly_roles FOR INSERT\n  TO authenticated\n  WITH CHECK (assembly_id = public.get_user_assembly_id() AND public.is_admin())","CREATE POLICY \\"assembly_roles_update\\"\n  ON public.assembly_roles FOR UPDATE\n  TO authenticated\n  USING (assembly_id = public.get_user_assembly_id() AND public.is_admin())","CREATE POLICY \\"assembly_roles_delete\\"\n  ON public.assembly_roles FOR DELETE\n  TO authenticated\n  USING (assembly_id = public.get_user_assembly_id() AND public.is_admin())","-- role_permissions: scoped via join to assembly_roles; mutations restricted to admin\nALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY","CREATE POLICY \\"role_permissions_select\\"\n  ON public.role_permissions FOR SELECT\n  TO authenticated\n  USING (\n    EXISTS (\n      SELECT 1 FROM public.assembly_roles ar\n       WHERE ar.id = role_id\n         AND ar.assembly_id = public.get_user_assembly_id()\n    )\n  )","CREATE POLICY \\"role_permissions_insert\\"\n  ON public.role_permissions FOR INSERT\n  TO authenticated\n  WITH CHECK (\n    public.is_admin() AND\n    EXISTS (\n      SELECT 1 FROM public.assembly_roles ar\n       WHERE ar.id = role_id\n         AND ar.assembly_id = public.get_user_assembly_id()\n    )\n  )","CREATE POLICY \\"role_permissions_delete\\"\n  ON public.role_permissions FOR DELETE\n  TO authenticated\n  USING (\n    public.is_admin() AND\n    EXISTS (\n      SELECT 1 FROM public.assembly_roles ar\n       WHERE ar.id = role_id\n         AND ar.assembly_id = public.get_user_assembly_id()\n    )\n  )"}	create_roles_permissions
20260526000005	{"-- Migration: 20260526000005_grant_roles_permissions_privileges\n-- Grants table-level privileges to the authenticated role for the new permissions tables.\n-- (RLS policies already restrict row-level access, but table-level is required first).\n\nGRANT SELECT ON public.permissions TO authenticated","GRANT SELECT, INSERT, UPDATE, DELETE ON public.assembly_roles TO authenticated","GRANT SELECT, INSERT, DELETE ON public.role_permissions TO authenticated"}	grant_roles_permissions_privileges
20260526000006	{"-- =============================================================================\n-- CACI Hub — Migration 20260526000006_fix_security_advisor_warnings\n-- Purpose:  Resolve all Supabase Security Advisor warnings:\n--\n--  1. Auth RLS Initialization Plan (3 policies):\n--     Replace bare auth.uid() with (SELECT auth.uid()) so it is evaluated\n--     once per statement, not once per row — prevents suboptimal query plans.\n--     Affected policies:\n--       - user_profiles_select_own\n--       - members_select_own_member_role         (latest version uses auth_user_id)\n--       - members_update_member_role_trigger_allow\n--\n--  2. Function Search Path Mutable (1 function):\n--     Add SET search_path = public to set_updated_at() to prevent search_path\n--     injection attacks.\n-- =============================================================================\n\n-- ── 1. user_profiles_select_own ──────────────────────────────────────────────\nDROP POLICY IF EXISTS user_profiles_select_own ON public.user_profiles","CREATE POLICY user_profiles_select_own\n  ON public.user_profiles\n  FOR SELECT\n  TO authenticated\n  USING (\n    id = (SELECT auth.uid())\n  )","-- ── 2. members_select_own_member_role ────────────────────────────────────────\n-- Replaces the version in 20260509000005 (which already improved created_by →\n-- auth_user_id, but still used bare auth.uid()).\nDROP POLICY IF EXISTS members_select_own_member_role ON public.members","CREATE POLICY members_select_own_member_role\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    public.get_user_role() = 'member'\n    AND auth_user_id = (SELECT auth.uid())\n  )","-- ── 3. members_update_member_role_trigger_allow ───────────────────────────────\nDROP POLICY IF EXISTS members_update_member_role_trigger_allow ON public.members","CREATE POLICY members_update_member_role_trigger_allow\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.get_user_role() = 'member'\n    AND created_by = (SELECT auth.uid())\n  )","-- ── 4. set_updated_at — add SET search_path ───────────────────────────────────\nCREATE OR REPLACE FUNCTION public.set_updated_at()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSET search_path = public\nAS $$\nBEGIN\n  NEW.updated_at = now();\n  RETURN NEW;\nEND;\n$$","COMMENT ON FUNCTION public.set_updated_at() IS\n  'Generic trigger function that sets updated_at = now() on every row UPDATE. '\n  'Shared across all Phase 1 tables. SET search_path = public added per security advisor.'"}	fix_security_advisor_warnings
20260526000007	{"-- =============================================================================\n-- CACI Hub — Migration 20260526000007_fix_remaining_security_warnings\n-- Purpose:  Resolve remaining Supabase Security Advisor warnings:\n--\n--  1. Multiple Permissive Policies — public.user_profiles (SELECT)\n--     Merge user_profiles_select_admin + user_profiles_select_own into one\n--     policy using OR so PostgreSQL evaluates a single policy per query.\n--\n--  2. Multiple Permissive Policies — public.members (SELECT)\n--     Merge members_select_admin_include_deleted + members_select_directory_roles\n--     + members_select_own_member_role into one policy using OR.\n--\n--  3. Security Definer View — public.members_view (CRITICAL)\n--     Recreate the view with security_invoker = true so the RLS of the\n--     querying user is enforced, not of the view owner (postgres).\n--\n--  4. Function Search Path Mutable — public.link_household_primary_contact\n--     Add SET search_path = public to the function.\n--\n-- NOTE: \\"Leaked Password Protection Disabled\\" is an Auth dashboard setting\n--       (supabase.com/dashboard → Auth → Security → Leaked Password Protection).\n--       It cannot be set via a migration and must be enabled manually.\n-- =============================================================================\n\n\n-- ── 1. user_profiles — merge two SELECT policies ──────────────────────────────\n\nDROP POLICY IF EXISTS user_profiles_select_admin ON public.user_profiles","DROP POLICY IF EXISTS user_profiles_select_own   ON public.user_profiles","-- Single policy using OR covering both cases.\n-- Admin sees all profiles in their assembly; everyone else sees only their own.\nCREATE POLICY user_profiles_select\n  ON public.user_profiles\n  FOR SELECT\n  TO authenticated\n  USING (\n    id = (SELECT auth.uid())\n    OR (\n      public.is_admin()\n      AND assembly_id = public.get_user_assembly_id()\n    )\n  )","-- ── 2. members — merge three SELECT policies ──────────────────────────────────\n\nDROP POLICY IF EXISTS members_select_admin_include_deleted ON public.members","DROP POLICY IF EXISTS members_select_directory_roles       ON public.members","DROP POLICY IF EXISTS members_select_own_member_role       ON public.members","-- Single policy with three OR branches:\n--   a) Admin: all rows (including soft-deleted) in their assembly\n--   b) Privileged roles (pastor, secretary, volunteer): active rows in their assembly\n--   c) Member: own row matched via auth_user_id\nCREATE POLICY members_select\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    -- Admin: all rows including soft-deleted\n    (\n      public.is_admin()\n      AND assembly_id = public.get_user_assembly_id()\n    )\n    OR\n    -- Directory roles: active rows only\n    (\n      public.can_read_directory()\n      AND assembly_id = public.get_user_assembly_id()\n      AND is_active = true\n    )\n    OR\n    -- Member: own row via linked auth account\n    (\n      public.get_user_role() = 'member'\n      AND auth_user_id = (SELECT auth.uid())\n    )\n  )","-- ── 3. members_view — add security_invoker = true ────────────────────────────\n-- This forces the view to enforce RLS of the QUERYING user, not the view owner.\n-- Only available in PostgreSQL 15+ (Supabase uses PG 15/16).\n\nDROP VIEW IF EXISTS public.members_view","CREATE VIEW public.members_view\nWITH (security_barrier = true, security_invoker = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.first_name,\n  m.last_name,\n  m.other_names,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.phone_number,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n\n  -- Emergency contact fields — hidden from volunteer\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n  m.auth_user_id,\n\n  -- Pastoral notes — visible to admin and pastor only (IMR-03)\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor')\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at\n\nFROM public.members m","COMMENT ON VIEW public.members_view IS\n  'Security barrier + invoker view over members. security_invoker=true ensures '\n  'RLS of the querying user is applied, not the view owner. Handles column-level '\n  'masking of emergency_contact_* (hidden from volunteer) and pastoral_notes '\n  '(hidden from secretary, volunteer, member). Reference: Document 5, Section 4.2; IMR-03.'","-- Re-grant SELECT to authenticated (required after DROP/CREATE of view)\nGRANT SELECT ON public.members_view TO authenticated","-- ── 4. link_household_primary_contact — add SET search_path ──────────────────\n\nCREATE OR REPLACE FUNCTION public.link_household_primary_contact()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSET search_path = public\nAS $$\nBEGIN\n  -- If primary_contact_id is set or changed\n  IF NEW.primary_contact_id IS NOT NULL THEN\n    UPDATE public.members\n    SET household_id = NEW.id\n    WHERE id = NEW.primary_contact_id;\n  END IF;\n  RETURN NEW;\nEND;\n$$"}	fix_remaining_security_warnings
20260526000008	{"-- =============================================================================\n-- CACI Hub — Migration 20260526000008_fix_public_callable_security_definer_functions\n-- Purpose:  Resolve remaining Supabase Security Advisor warnings:\n--\n--  1. Public Bucket Allows Listing — storage.member-photos\n--     The existing \\"member_photos_public_read\\" policy allows the `anon` role to\n--     SELECT (list) any object in the bucket without signing in. Replaced with\n--     a policy restricted to `authenticated` only — public photo URLs remain\n--     accessible via the CDN URL without requiring object listing.\n--\n--  2. Public Can Execute SECURITY DEFINER Function (4 functions)\n--     The following SECURITY DEFINER functions are callable by the `anon` role\n--     through the PostgREST /rest/v1/rpc/ endpoint. Revoke anon EXECUTE and\n--     restrict to `authenticated`:\n--\n--       a. public.assign_membership_number(p_member_id uuid, p_assembly_id uuid)\n--       b. public.can_read_directory()\n--       c. public.enforce_member_update_columns()\n--       d. public.get_available_primary_contacts(p_assembly_id uuid, p_search text, p_current_household_id uuid)\n--\n-- NOTE: The SECURITY DEFINER attribute is intentionally preserved on all helper\n--       functions — it is required to prevent RLS recursion when reading\n--       user_profiles from within an RLS policy (Document 5, Section 3). The fix\n--       here only removes the ability for the `anon` (unauthenticated) role to\n--       call these functions.\n-- =============================================================================\n\n\n-- ── 1. member-photos — restrict SELECT policy to authenticated ─────────────────\n-- The old broad SELECT policy allows `anon` to list ALL objects in the bucket.\n-- For a public bucket, direct object URLs still work without any RLS policy;\n-- the policy only controls who can call storage.list() (the ListObjects API).\n-- Replacing with an authenticated-only check eliminates unauthenticated listing.\n\nDROP POLICY IF EXISTS \\"member_photos_public_read\\" ON storage.objects","CREATE POLICY \\"member_photos_authenticated_read\\"\n  ON storage.objects\n  FOR SELECT\n  TO authenticated\n  USING (bucket_id = 'member-photos')","-- COMMENT ON POLICY \\"member_photos_authenticated_read\\" ON storage.objects IS\n--   'Authenticated users can SELECT (read/download) member photos. '\n--   'The `anon` role cannot list bucket contents. Public CDN URLs remain '\n--   'accessible without this policy because the bucket itself is set to public.';\n\n\n-- ── 2a. assign_membership_number — revoke anon, grant authenticated ────────────\n\nREVOKE EXECUTE ON FUNCTION public.assign_membership_number(uuid, uuid) FROM anon","REVOKE EXECUTE ON FUNCTION public.assign_membership_number(uuid, uuid) FROM PUBLIC","GRANT  EXECUTE ON FUNCTION public.assign_membership_number(uuid, uuid) TO authenticated","GRANT  EXECUTE ON FUNCTION public.assign_membership_number(uuid, uuid) TO service_role","COMMENT ON FUNCTION public.assign_membership_number(uuid, uuid) IS\n  'Generates and assigns a membership number for the given member in the given '\n  'assembly. SECURITY DEFINER (required to bypass RLS on members during sequence '\n  'calculation). Callable by authenticated and service_role only — anon EXECUTE '\n  'revoked to prevent unauthenticated invocation via /rest/v1/rpc/.'","-- ── 2b. can_read_directory — revoke anon, grant authenticated ─────────────────\n-- This is a helper used only inside RLS policies; it should never be called\n-- directly by the anon role.\n\nREVOKE EXECUTE ON FUNCTION public.can_read_directory() FROM anon","REVOKE EXECUTE ON FUNCTION public.can_read_directory() FROM PUBLIC","GRANT  EXECUTE ON FUNCTION public.can_read_directory() TO authenticated","COMMENT ON FUNCTION public.can_read_directory() IS\n  'Returns TRUE for admin, pastor, secretary, and volunteer roles. '\n  'Used in directory-read SELECT policies on members and households. '\n  'SECURITY DEFINER prevents RLS recursion on user_profiles. '\n  'Callable by authenticated only — anon EXECUTE revoked.'","-- ── 2c. enforce_member_update_columns — revoke anon ───────────────────────────\n-- This is a trigger function — it is called by the database engine, not by\n-- external clients. Revoking anon EXECUTE is safe and correct.\n\nREVOKE EXECUTE ON FUNCTION public.enforce_member_update_columns() FROM anon","REVOKE EXECUTE ON FUNCTION public.enforce_member_update_columns() FROM PUBLIC","GRANT  EXECUTE ON FUNCTION public.enforce_member_update_columns() TO authenticated","COMMENT ON FUNCTION public.enforce_member_update_columns() IS\n  'BEFORE UPDATE trigger that enforces column-level write permissions per role. '\n  'Admin: unrestricted. Secretary: all except pastoral_notes. Pastor: pastoral_notes only. '\n  'Volunteer/Member: all updates denied. SECURITY DEFINER to call get_user_role() safely. '\n  'Callable by authenticated only — anon EXECUTE revoked.'","-- ── 2d. get_available_primary_contacts — revoke anon, grant authenticated ─────\n\nREVOKE EXECUTE ON FUNCTION public.get_available_primary_contacts(uuid, text, uuid) FROM anon","REVOKE EXECUTE ON FUNCTION public.get_available_primary_contacts(uuid, text, uuid) FROM PUBLIC","GRANT  EXECUTE ON FUNCTION public.get_available_primary_contacts(uuid, text, uuid) TO authenticated","COMMENT ON FUNCTION public.get_available_primary_contacts(uuid, text, uuid) IS\n  'Returns assembly members eligible to be set as a household primary contact, '\n  'excluding members already serving as a primary contact for another household. '\n  'SECURITY DEFINER to query members_view without triggering RLS recursion. '\n  'Callable by authenticated only — anon EXECUTE revoked.'"}	fix_public_callable_security_definer_functions
20260527000001	{"-- =============================================================================\n-- Migration: 20260527000001_phone_migration.sql\n-- Description: Add phone to user_profiles, rename phone_number to primary_phone,\n--              add secondary_phone to members, and update views/triggers.\n-- =============================================================================\n\n-- 1. Track phone on user profiles for authentication\nALTER TABLE public.user_profiles ADD COLUMN IF NOT EXISTS phone text","-- 2. Drop dependent views and functions\nDROP VIEW IF EXISTS public.members_view","DROP FUNCTION IF EXISTS public.get_available_primary_contacts(UUID, TEXT, UUID)","-- 3. Rename and add columns in members\nALTER TABLE public.members RENAME COLUMN phone_number TO primary_phone","ALTER TABLE public.members ADD COLUMN IF NOT EXISTS secondary_phone text","-- 4. Recreate members_view with other_names, primary_phone, and secondary_phone\nCREATE VIEW public.members_view\nWITH (security_barrier = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.first_name,\n  m.last_name,\n  m.other_names,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.primary_phone,\n  m.secondary_phone,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor')\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at,\n  m.auth_user_id\n\nFROM public.members m","COMMENT ON VIEW public.members_view IS\n  'Security barrier view over members. Handles column-level masking of emergency_contact_* and pastoral_notes.'","GRANT SELECT ON public.members_view TO authenticated","GRANT SELECT ON public.members_view TO service_role","-- 5. Recreate get_available_primary_contacts\nCREATE OR REPLACE FUNCTION public.get_available_primary_contacts(\n  p_assembly_id UUID, \n  p_search TEXT, \n  p_current_household_id UUID DEFAULT NULL\n)\nRETURNS TABLE(id UUID, first_name TEXT, last_name TEXT, primary_phone TEXT)\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nBEGIN\n  RETURN QUERY\n  SELECT m.id, m.first_name, m.last_name, m.primary_phone\n  FROM public.members_view m\n  WHERE m.assembly_id = p_assembly_id\n    AND m.is_active = true\n    AND (\n      p_search IS NULL \n      OR p_search = '' \n      OR m.first_name ILIKE '%' || p_search || '%' \n      OR m.last_name ILIKE '%' || p_search || '%'\n    )\n    AND NOT EXISTS (\n       SELECT 1 FROM public.households h \n       WHERE h.primary_contact_id = m.id \n         AND (p_current_household_id IS NULL OR h.id != p_current_household_id)\n    )\n  ORDER BY m.last_name, m.first_name;\nEND;\n$$","-- 6. Update write_member_audit_log\nCREATE OR REPLACE FUNCTION public.write_member_audit_log()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  auditable_columns TEXT[] := ARRAY[\n    'first_name', 'last_name', 'other_names', 'primary_phone', 'secondary_phone', 'email',\n    'occupation', 'physical_address', 'facebook_url',\n    'whatsapp_number', 'instagram_url',\n    'emergency_contact_name', 'emergency_contact_phone',\n    'emergency_contact_relationship',\n    'membership_status', 'gender', 'marital_status',\n    'household_id', 'profile_photo_url', 'pastoral_notes',\n    'is_active', 'deleted_at', 'join_date'\n  ];\n  col_name  TEXT;\n  old_val   TEXT;\n  new_val   TEXT;\nBEGIN\n  FOREACH col_name IN ARRAY auditable_columns LOOP\n    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO old_val USING OLD;\n    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO new_val USING NEW;\n\n    IF old_val IS DISTINCT FROM new_val THEN\n      INSERT INTO public.member_audit_log (\n        member_id, assembly_id, changed_by, field_changed, old_value, new_value\n      ) VALUES (\n        NEW.id,\n        NEW.assembly_id,\n        auth.uid(),\n        col_name,\n        old_val,\n        new_val\n      );\n    END IF;\n  END LOOP;\n\n  RETURN NEW;\nEND;\n$$","-- 7. Update enforce_member_update_columns\nCREATE OR REPLACE FUNCTION public.enforce_member_update_columns()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_role public.user_role;\nBEGIN\n  v_role := public.get_user_role();\n\n  IF v_role IS NULL THEN\n    RETURN NEW;\n  END IF;\n\n  IF v_role = 'admin' THEN\n    RETURN NEW;\n  END IF;\n\n  IF v_role = 'secretary' THEN\n    IF OLD.pastoral_notes IS DISTINCT FROM NEW.pastoral_notes THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n        USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  IF v_role = 'pastor' THEN\n    IF OLD.first_name                    IS DISTINCT FROM NEW.first_name OR\n       OLD.last_name                     IS DISTINCT FROM NEW.last_name OR\n       OLD.other_names                   IS DISTINCT FROM NEW.other_names OR\n       OLD.date_of_birth                 IS DISTINCT FROM NEW.date_of_birth OR\n       OLD.gender                        IS DISTINCT FROM NEW.gender OR\n       OLD.marital_status                IS DISTINCT FROM NEW.marital_status OR\n       OLD.primary_phone                 IS DISTINCT FROM NEW.primary_phone OR\n       OLD.secondary_phone               IS DISTINCT FROM NEW.secondary_phone OR\n       OLD.email                         IS DISTINCT FROM NEW.email OR\n       OLD.physical_address              IS DISTINCT FROM NEW.physical_address OR\n       OLD.occupation                    IS DISTINCT FROM NEW.occupation OR\n       OLD.facebook_url                  IS DISTINCT FROM NEW.facebook_url OR\n       OLD.whatsapp_number               IS DISTINCT FROM NEW.whatsapp_number OR\n       OLD.instagram_url                 IS DISTINCT FROM NEW.instagram_url OR\n       OLD.emergency_contact_name        IS DISTINCT FROM NEW.emergency_contact_name OR\n       OLD.emergency_contact_phone       IS DISTINCT FROM NEW.emergency_contact_phone OR\n       OLD.emergency_contact_relationship IS DISTINCT FROM NEW.emergency_contact_relationship OR\n       OLD.membership_status             IS DISTINCT FROM NEW.membership_status OR\n       OLD.join_date                     IS DISTINCT FROM NEW.join_date OR\n       OLD.household_id                  IS DISTINCT FROM NEW.household_id OR\n       OLD.profile_photo_url             IS DISTINCT FROM NEW.profile_photo_url OR\n       OLD.is_active                     IS DISTINCT FROM NEW.is_active OR\n       OLD.deleted_at                    IS DISTINCT FROM NEW.deleted_at OR\n       OLD.assembly_id                   IS DISTINCT FROM NEW.assembly_id OR\n       OLD.membership_number             IS DISTINCT FROM NEW.membership_number OR\n       OLD.auth_user_id                  IS DISTINCT FROM NEW.auth_user_id\n    THEN\n      RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n        USING ERRCODE = '42501';\n    END IF;\n    RETURN NEW;\n  END IF;\n\n  IF v_role IN ('volunteer', 'member') THEN\n    RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n      USING ERRCODE = '42501';\n  END IF;\n\n  RAISE EXCEPTION 'new row violates row-level security policy for table \\"members\\"'\n    USING ERRCODE = '42501';\nEND;\n$$"}	phone_migration
20260527000002	{"-- =============================================================================\n-- Migration: 20260527000002_add_member_title.sql\n-- Description: Add an optional `title` column to public.members with a CHECK\n--              constraint, propagate through members_view, and track in the\n--              audit trigger.\n-- =============================================================================\n\n-- 1. Add column\nALTER TABLE public.members\n  ADD COLUMN IF NOT EXISTS title TEXT\n    CHECK (title IN (\n      'Mr.','Mrs.','Ms.','Miss',\n      'Dr.','Prof.',\n      'Rev.','Pastor','Elder','Deacon','Deaconess',\n      'Apostle','Bishop'\n    ))","-- 2. Drop dependent view before recreating\nDROP VIEW IF EXISTS public.members_view","-- 3. Recreate members_view (includes title, security_barrier only — invoker was\n--    set in migration 20260526000007; this migration re-applies the same flags)\nCREATE VIEW public.members_view\nWITH (security_barrier = true, security_invoker = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.title,\n  m.first_name,\n  m.last_name,\n  m.other_names,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.primary_phone,\n  m.secondary_phone,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor', 'secretary', 'member')\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n\n  CASE\n    WHEN public.get_user_role() IN ('admin', 'pastor')\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at,\n  m.auth_user_id\n\nFROM public.members m","COMMENT ON VIEW public.members_view IS\n  'Security barrier + invoker view over members. Includes title field added in '\n  'migration 20260527000002. Handles column-level masking of emergency_contact_* '\n  'and pastoral_notes.'","GRANT SELECT ON public.members_view TO authenticated","GRANT SELECT ON public.members_view TO service_role","-- 4. Update write_member_audit_log to track title changes\nCREATE OR REPLACE FUNCTION public.write_member_audit_log()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  auditable_columns TEXT[] := ARRAY[\n    'title',\n    'first_name', 'last_name', 'other_names', 'primary_phone', 'secondary_phone', 'email',\n    'occupation', 'physical_address', 'facebook_url',\n    'whatsapp_number', 'instagram_url',\n    'emergency_contact_name', 'emergency_contact_phone',\n    'emergency_contact_relationship',\n    'membership_status', 'gender', 'marital_status',\n    'household_id', 'profile_photo_url', 'pastoral_notes',\n    'is_active', 'deleted_at', 'join_date'\n  ];\n  col_name  TEXT;\n  old_val   TEXT;\n  new_val   TEXT;\nBEGIN\n  FOREACH col_name IN ARRAY auditable_columns LOOP\n    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO old_val USING OLD;\n    EXECUTE format('SELECT ($1).%I::TEXT', col_name) INTO new_val USING NEW;\n\n    IF old_val IS DISTINCT FROM new_val THEN\n      INSERT INTO public.member_audit_log (\n        member_id, assembly_id, changed_by, field_changed, old_value, new_value\n      ) VALUES (\n        NEW.id,\n        NEW.assembly_id,\n        auth.uid(),\n        col_name,\n        old_val,\n        new_val\n      );\n    END IF;\n  END LOOP;\n\n  RETURN NEW;\nEND;\n$$"}	add_member_title
20260529000001	{"-- =============================================================================\n-- Migration: 20260529000001_drop_contact_required_constraint.sql\n-- Description: Drop the chk_members_contact_required CHECK constraint so that\n--              members can be registered without a primary phone number OR email.\n--              Both columns remain nullable; no uniqueness rules are affected.\n-- =============================================================================\n\nALTER TABLE public.members\n  DROP CONSTRAINT IF EXISTS chk_members_contact_required"}	drop_contact_required_constraint
20260529000002	{"-- =============================================================================\n-- Migration: 20260529000002_create_clear_must_change_password_fn.sql\n-- Description: Create a SECURITY DEFINER function so users can clear their own\n--              must_change_password flag. Direct updates to user_profiles are\n--              blocked by RLS (only admins can UPDATE user_profiles).\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.clear_must_change_password()\nRETURNS void\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nBEGIN\n  UPDATE public.user_profiles\n     SET must_change_password = false\n   WHERE id = auth.uid();\nEND;\n$$","COMMENT ON FUNCTION public.clear_must_change_password() IS\n  'Allows an authenticated user to clear their own must_change_password flag '\n  'after successfully updating their password. Bypasses user_profiles RLS.'"}	create_clear_must_change_password_fn
20260530000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000001_rbac_rename_permissions_table\n-- Purpose:  RBAC Phase 1 — Rename public.permissions → public.system_permissions\n--           and update the schema to match the new platform-owned permission\n--           catalogue format (key, label, module_name, category, is_assignable,\n--           is_active).\n--\n-- What this changes:\n--   * Renames table: permissions → system_permissions\n--   * Adds columns:  key (becomes new PK alias for id)\n--                    label, module_name, category\n--                    is_assignable boolean DEFAULT true\n--                    is_active     boolean DEFAULT true\n--   * Adds a proper `key` TEXT column as the semantic primary key\n--   * Drops old RLS policies, recreates on new table name\n--   * Keeps old `id` column temporarily aliased so role_permissions migration\n--     can follow safely in the next migration.\n--\n-- NOTE: role_permissions FK to permissions(id) is updated in migration 000002.\n-- =============================================================================\n\n-- Step 1: Rename the table\nALTER TABLE public.permissions\n  RENAME TO system_permissions","-- Step 2: Add new required columns (nullable first so existing rows don't fail)\nALTER TABLE public.system_permissions\n  ADD COLUMN IF NOT EXISTS label          TEXT,\n  ADD COLUMN IF NOT EXISTS module_name    TEXT,\n  ADD COLUMN IF NOT EXISTS category       TEXT,\n  ADD COLUMN IF NOT EXISTS is_assignable  BOOLEAN NOT NULL DEFAULT true,\n  ADD COLUMN IF NOT EXISTS is_active      BOOLEAN NOT NULL DEFAULT true","-- Step 3: Backfill label from description where null\nUPDATE public.system_permissions\nSET label = id\nWHERE label IS NULL","-- Step 4: Set NOT NULL constraints now that data is backfilled\nALTER TABLE public.system_permissions\n  ALTER COLUMN label       SET NOT NULL,\n  ALTER COLUMN module_name SET DEFAULT 'general',\n  ALTER COLUMN category    SET DEFAULT 'General'","-- Step 5: Update default module_name and category for existing seeded permissions\nUPDATE public.system_permissions SET module_name = 'admin',      category = 'Members'   WHERE id = 'member:invite'","UPDATE public.system_permissions SET module_name = 'membership',  category = 'Members'   WHERE id = 'member:view_all'","UPDATE public.system_permissions SET module_name = 'membership',  category = 'Members'   WHERE id = 'member:edit'","UPDATE public.system_permissions SET module_name = 'finance',     category = 'Finance'   WHERE id = 'financials:view'","UPDATE public.system_permissions SET module_name = 'finance',     category = 'Finance'   WHERE id = 'financials:write'","UPDATE public.system_permissions SET module_name = 'attendance',  category = 'Attendance' WHERE id = 'attendance:mark'","UPDATE public.system_permissions SET module_name = 'media',       category = 'Media'     WHERE id = 'sermon:edit'","-- Set NOT NULL now data is populated\nALTER TABLE public.system_permissions\n  ALTER COLUMN module_name SET NOT NULL,\n  ALTER COLUMN category    SET NOT NULL","-- Step 6: Drop old RLS policies (were named on public.permissions)\nDROP POLICY IF EXISTS \\"permissions_select_authenticated\\" ON public.system_permissions","-- Step 7: Recreate RLS on the renamed table\n-- Permission: anyone authenticated can SELECT; no API write access\nCREATE POLICY \\"system_permissions_select_authenticated\\"\n  ON public.system_permissions FOR SELECT\n  TO authenticated\n  USING (true)","COMMENT ON TABLE public.system_permissions IS\n  'Platform-owned permission catalogue. Rows are seeded via migrations only — '\n  'never created at runtime. Permissions are assigned to assembly_roles via '\n  'role_permissions. Assemblies may only use is_assignable = true permissions.'"}	rbac_rename_permissions_table
20260530000002	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000002_rbac_update_role_permissions\n-- Purpose:  RBAC Phase 2 — Update role_permissions to use permission key (text)\n--           instead of permission id, aligned with system_permissions.key.\n--\n-- What this changes:\n--   * Adds a `key` TEXT column to system_permissions (unique, dot-notation)\n--   * Updates role_permissions to use permission_key TEXT instead of permission_id TEXT\n--   * Updates PK on role_permissions to (role_id, permission_key)\n--   * Drops old FK to permissions(id), adds FK to system_permissions(key)\n--\n-- Depends on: 20260530000001 (system_permissions table must exist)\n-- =============================================================================\n\n-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 1: Add `key` column to system_permissions as the new semantic PK\n-- The old `id` column (e.g. 'member:invite') was colon-separated and legacy.\n-- The new `key` uses dot-notation (e.g. 'members.view').\n-- We keep `id` for backward compat in this migration; deprecated going forward.\n-- ─────────────────────────────────────────────────────────────────────────────\nALTER TABLE public.system_permissions\n  ADD COLUMN IF NOT EXISTS key TEXT","-- Backfill key from id for legacy rows\nUPDATE public.system_permissions SET key = id WHERE key IS NULL","-- Now set NOT NULL and add unique constraint\nALTER TABLE public.system_permissions\n  ALTER COLUMN key SET NOT NULL","ALTER TABLE public.system_permissions\n  ADD CONSTRAINT system_permissions_key_unique UNIQUE (key)","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 2: Add permission_key column to role_permissions\n-- ─────────────────────────────────────────────────────────────────────────────\nALTER TABLE public.role_permissions\n  ADD COLUMN IF NOT EXISTS permission_key TEXT","-- Backfill permission_key from the linked permission's key\nUPDATE public.role_permissions rp\nSET permission_key = sp.key\nFROM public.system_permissions sp\nWHERE sp.id = rp.permission_id","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 3: Drop old PK and FK constraints on role_permissions\n-- ─────────────────────────────────────────────────────────────────────────────\nALTER TABLE public.role_permissions\n  DROP CONSTRAINT IF EXISTS role_permissions_pkey","ALTER TABLE public.role_permissions\n  DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey","-- Drop old column\nALTER TABLE public.role_permissions\n  DROP COLUMN IF EXISTS permission_id","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 4: Set NOT NULL and add new FK + PK\n-- ─────────────────────────────────────────────────────────────────────────────\nALTER TABLE public.role_permissions\n  ALTER COLUMN permission_key SET NOT NULL","ALTER TABLE public.role_permissions\n  ADD CONSTRAINT role_permissions_permission_key_fkey\n    FOREIGN KEY (permission_key)\n    REFERENCES public.system_permissions(key)\n    ON DELETE CASCADE","ALTER TABLE public.role_permissions\n  ADD CONSTRAINT role_permissions_pkey\n    PRIMARY KEY (role_id, permission_key)","COMMENT ON TABLE public.role_permissions IS\n  'Many-to-many junction between assembly_roles and system_permissions. '\n  'Multiple roles can share the same permission. Only admin may modify this table. '\n  'Backend must reject assignment of permissions where is_assignable = false.'"}	rbac_update_role_permissions
20260530000003	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000003_rbac_update_assembly_roles\n-- Purpose:  RBAC Phase 3 — Add is_active and is_system columns to assembly_roles.\n--           is_active: allows admins to soft-deactivate roles without deleting.\n--           is_system: reserved for future platform-created default roles.\n--\n-- Depends on: 20260530000001\n-- =============================================================================\n\nALTER TABLE public.assembly_roles\n  ADD COLUMN IF NOT EXISTS is_active  BOOLEAN NOT NULL DEFAULT true,\n  ADD COLUMN IF NOT EXISTS is_system  BOOLEAN NOT NULL DEFAULT false","COMMENT ON COLUMN public.assembly_roles.is_active IS\n  'Soft-disable flag. Deactivated roles still exist in the DB but are excluded '\n  'from UI role pickers. Users assigned a deactivated role lose its permissions '\n  'at next JWT refresh.'","COMMENT ON COLUMN public.assembly_roles.is_system IS\n  'Reserved for platform-default roles seeded by migrations. '\n  'is_system = true roles may not be deleted by assemblies.'"}	rbac_update_assembly_roles
20260530000004	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000004_rbac_rename_user_profiles_role_id\n-- Purpose:  RBAC Phase 4 — Rename user_profiles.role_id → assembly_role_id\n--           to avoid ambiguity and make the FK purpose explicit.\n--\n-- Depends on: 20260530000003\n-- =============================================================================\n\n-- Rename the column\nALTER TABLE public.user_profiles\n  RENAME COLUMN role_id TO assembly_role_id","-- Update the JWT sync trigger to reference the correct column name\n-- The trigger fires on UPDATE OF role_id which needs to be updated too.\nDROP TRIGGER IF EXISTS sync_permissions_on_profile_update ON public.user_profiles","CREATE TRIGGER sync_permissions_on_profile_update\n  AFTER UPDATE OF assembly_role_id, assembly_id\n  ON public.user_profiles\n  FOR EACH ROW\n  EXECUTE FUNCTION public.sync_user_permissions_to_jwt()","COMMENT ON COLUMN public.user_profiles.assembly_role_id IS\n  'Optional FK → assembly_roles(id). The custom role this user holds within '\n  'their assembly (e.g. Secretary, Treasurer). NULL = no custom role assigned; '\n  'user is governed by their system role only. '\n  'Updated by admin via user management. '\n  'Changing this triggers sync_user_permissions_to_jwt to refresh the JWT.'"}	rbac_rename_user_profiles_role_id
20260530000005	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000005_rbac_restrict_user_profiles_role\n-- Purpose:  RBAC Phase 5 — Restrict user_profiles.role to ('admin', 'member')\n--           only. All other enum values (pastor, secretary, etc.) are removed\n--           from the system role model — they belong to assembly_roles instead.\n--\n-- IMPORTANT: This migration migrates all users with non-admin/member roles to\n--            'member' before applying the check constraint. Admins must then\n--            create assembly roles and assign users via user management.\n--\n-- What this changes:\n--   1. Migrates rows: pastor/secretary/volunteer/etc. → 'member'\n--   2. Drops the user_role enum type\n--   3. Changes user_profiles.role to TEXT with CHECK constraint\n--   4. Updates RLS helper functions that return/compare user_role type\n--   5. Drops composite helpers that reference legacy roles\n--\n-- Depends on: 20260530000004\n-- =============================================================================\n\n-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 1: Migrate non-admin users to 'member' role\n-- ─────────────────────────────────────────────────────────────────────────────\nUPDATE public.user_profiles\nSET role = 'member'\nWHERE role NOT IN ('admin', 'member')","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 2: Change user_profiles.role column from enum to text with CHECK\n-- We cannot just alter the type directly when a CHECK constraint uses an enum.\n-- Strategy: add new text column, copy data, drop old, rename.\n-- ─────────────────────────────────────────────────────────────────────────────\n\n-- Add new text column\nALTER TABLE public.user_profiles\n  ADD COLUMN role_text TEXT","-- Copy data\nUPDATE public.user_profiles SET role_text = role::text","-- Drop old enum column\nALTER TABLE public.user_profiles DROP COLUMN role","-- Rename new column and add constraint\nALTER TABLE public.user_profiles\n  RENAME COLUMN role_text TO role","ALTER TABLE public.user_profiles\n  ALTER COLUMN role SET NOT NULL,\n  ALTER COLUMN role SET DEFAULT 'member'","ALTER TABLE public.user_profiles\n  ADD CONSTRAINT user_profiles_role_check\n    CHECK (role IN ('admin', 'member'))","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 3: Recreate get_user_role() — now returns TEXT instead of user_role enum\n-- ─────────────────────────────────────────────────────────────────────────────\nDROP FUNCTION IF EXISTS public.get_user_role() CASCADE","CREATE OR REPLACE FUNCTION public.get_user_role()\nRETURNS TEXT\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT role\n  FROM public.user_profiles\n  WHERE id        = auth.uid()\n    AND is_active = true\n  LIMIT 1;\n$$","COMMENT ON FUNCTION public.get_user_role() IS\n  'Returns the system role (admin | member) of the currently authenticated user. '\n  'Returns NULL if no active user_profiles row exists for auth.uid(). '\n  'SECURITY DEFINER prevents infinite recursion in RLS policies on tables '\n  'that join user_profiles. Used in RLS enforcement for admin override.'","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 4: Update is_admin() — now compares TEXT\n-- ─────────────────────────────────────────────────────────────────────────────\nCREATE OR REPLACE FUNCTION public.is_admin()\nRETURNS BOOLEAN\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id        = auth.uid()\n      AND role      = 'admin'\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_admin() IS\n  'Returns true iff the current user is an active admin. '\n  'Compares against the TEXT system role. Returns false (not NULL) for '\n  'unauthenticated or inactive users. Used in admin-only RLS policies.'","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 5: Add is_member() helper for clarity in RLS policies\n-- ─────────────────────────────────────────────────────────────────────────────\nCREATE OR REPLACE FUNCTION public.is_member()\nRETURNS BOOLEAN\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM public.user_profiles\n    WHERE id        = auth.uid()\n      AND role      = 'member'\n      AND is_active = true\n  );\n$$","COMMENT ON FUNCTION public.is_member() IS\n  'Returns true iff the current user is an active member (non-admin system role). '\n  'In the new RBAC model, permission checks happen at the app layer — not in RLS. '\n  'RLS only uses is_admin() and is_member() for assembly isolation.'","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 6: Drop legacy composite helper functions\n-- These used to check for pastor/secretary/volunteer in RLS. No longer valid\n-- since those are no longer system roles. RLS must not understand custom roles.\n-- ─────────────────────────────────────────────────────────────────────────────\nDROP FUNCTION IF EXISTS public.is_admin_or_pastor() CASCADE","DROP FUNCTION IF EXISTS public.is_admin_or_secretary() CASCADE","DROP FUNCTION IF EXISTS public.can_read_directory() CASCADE","-- ─────────────────────────────────────────────────────────────────────────────\n-- Step 7: Drop the user_role enum type (no longer used)\n-- ─────────────────────────────────────────────────────────────────────────────\n-- Note: we can only drop the enum after the column is changed to TEXT.\nDROP TYPE IF EXISTS public.user_role"}	rbac_restrict_user_profiles_role
20260530000006	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000006_rbac_seed_system_permissions\n-- Purpose:  RBAC Phase 6 — Seed all platform-defined permissions into\n--           system_permissions. These are declared in module manifests and\n--           owned by the platform — not creatable by assemblies at runtime.\n--\n-- Permission naming: <module>.<resource>.<action> (dot-notation only)\n-- Use ON CONFLICT (key) DO UPDATE to keep this idempotent.\n-- Never hard-delete permissions — use is_active = false to deprecate.\n--\n-- Depends on: 20260530000001 (system_permissions table with key column)\n-- =============================================================================\n\nINSERT INTO public.system_permissions (id, key, label, description, module_name, category, is_assignable, is_active) VALUES\n\n  -- ── Membership: Members ────────────────────────────────────────────────────\n  ('members.view',       'members.view',       'View Members',       'Allows viewing the member directory and individual member records',         'membership', 'Members',    true,  true),\n  ('members.create',     'members.create',     'Create Members',     'Allows creating new member records',                                        'membership', 'Members',    true,  true),\n  ('members.edit',       'members.edit',       'Edit Members',       'Allows editing existing member records',                                    'membership', 'Members',    true,  true),\n  ('members.deactivate', 'members.deactivate', 'Deactivate Members', 'Allows soft-deactivating member records',                                   'membership', 'Members',    true,  true),\n  ('members.import',     'members.import',     'Import Members',     'Allows bulk importing member records via CSV or spreadsheet',               'membership', 'Members',    true,  true),\n\n  -- ── Membership: Households ────────────────────────────────────────────────\n  ('households.view',    'households.view',    'View Households',    'Allows viewing household records and member groupings',                     'membership', 'Households', true,  true),\n  ('households.create',  'households.create',  'Create Households',  'Allows creating new household records',                                     'membership', 'Households', true,  true),\n  ('households.edit',    'households.edit',    'Edit Households',    'Allows editing existing household records',                                 'membership', 'Households', true,  true),\n\n  -- ── Reports ────────────────────────────────────────────────────────────────\n  ('reports.view',       'reports.view',       'View Reports',       'Allows viewing generated reports and dashboards',                           'reports',    'Reports',    true,  true),\n  ('reports.export',     'reports.export',     'Export Reports',     'Allows downloading and exporting reports to CSV/PDF',                       'reports',    'Reports',    true,  true),\n\n  -- ── Finance ────────────────────────────────────────────────────────────────\n  ('finance.offerings.view',  'finance.offerings.view',  'View Offerings',  'Allows viewing tithes, offerings and financial records',            'finance',    'Finance',    true,  true),\n  ('finance.offerings.edit',  'finance.offerings.edit',  'Edit Offerings',  'Allows recording and editing tithes, offerings and expenses',       'finance',    'Finance',    true,  true),\n\n  -- ── Admin ──────────────────────────────────────────────────────────────────\n  ('admin.view',          'admin.view',          'View Admin Panel',   'Allows access to the admin panel and audit log',                          'admin',      'Admin',      true,  true),\n  ('admin.users.manage',  'admin.users.manage',  'Manage Users',       'Allows creating and managing user accounts and assembly role assignments', 'admin',      'Admin',      true,  true)\n\nON CONFLICT (key) DO UPDATE SET\n  label        = EXCLUDED.label,\n  description  = EXCLUDED.description,\n  module_name  = EXCLUDED.module_name,\n  category     = EXCLUDED.category,\n  is_assignable = EXCLUDED.is_assignable","-- NOTE: is_active is NOT updated on conflict — deprecation is a manual decision.\n\nCOMMENT ON TABLE public.system_permissions IS\n  'Platform-owned permission catalogue. Rows are seeded via migrations only — '\n  'never created at runtime. Permissions are assigned to assembly_roles via '\n  'role_permissions. Assemblies may only use is_assignable = true permissions.'"}	rbac_seed_system_permissions
20260530000007	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000007_rbac_refactor_rls\n-- Purpose:  RBAC Phase 7 — Refactor all RLS policies and column-level trigger\n--           to remove hardcoded custom role names (pastor, secretary, volunteer).\n--\n--           RLS must only know:\n--             * admin   → bypass, full assembly access\n--             * member  → own-record-only access\n--             * assembly ownership boundaries\n--\n--           Application layer (authorization-service.ts) handles all\n--           fine-grained permission checks post-authentication.\n--\n-- What this changes:\n--   1. members SELECT policy — simplified to admin | member-own-record\n--   2. members_view — removes CASE role IN (...) masking by hardcoded role names.\n--      New rule: admin sees everything; member sees own; others see limited view.\n--   3. enforce_member_update_columns() trigger — removes pastor/secretary/volunteer\n--      branches. New rule: admin = full; member = deny; NULL = allow (internal).\n--   4. sync_user_permissions_to_jwt — update to read permission_key not permission_id\n--\n-- Depends on: 20260530000005 (user_role enum dropped; is_admin_or_pastor etc. dropped)\n-- =============================================================================\n\n\n-- ─────────────────────────────────────────────────────────────────────────────\n-- 1. members SELECT policy\n-- Old policy had 3 branches: admin all | can_read_directory | member own\n-- New policy: admin (all in assembly) | member (own row via auth_user_id)\n-- Fine-grained directory-access decisions are enforced by the app/service layer.\n-- ─────────────────────────────────────────────────────────────────────────────\n\nDROP POLICY IF EXISTS members_select ON public.members","CREATE POLICY members_select\n  ON public.members\n  FOR SELECT\n  TO authenticated\n  USING (\n    -- Admin: all rows including soft-deleted, within their assembly\n    (\n      public.is_admin()\n      AND assembly_id = public.get_user_assembly_id()\n    )\n    OR\n    -- All authenticated members in the same assembly may read active records.\n    -- Fine-grained column visibility is enforced via members_view masking.\n    -- Service-layer checks (authorization-service.ts) gate route-level access.\n    (\n      assembly_id = public.get_user_assembly_id()\n      AND is_active = true\n    )\n    OR\n    -- Member: own row via linked auth account (even if different assembly somehow)\n    (\n      auth_user_id = (SELECT auth.uid())\n    )\n  )","-- ─────────────────────────────────────────────────────────────────────────────\n-- 2. members_view — remove hardcoded role names from CASE expressions\n-- Old: CASE WHEN role IN ('admin', 'pastor', 'secretary', 'member') ...\n-- New:\n--   * Admin → sees all columns\n--   * Member accessing own row → sees emergency contact + no pastoral notes\n--   * All others → masked emergency contact, no pastoral notes\n-- ─────────────────────────────────────────────────────────────────────────────\n\nDROP VIEW IF EXISTS public.members_view","CREATE VIEW public.members_view\nWITH (security_barrier = true, security_invoker = true)\nAS\nSELECT\n  m.id,\n  m.assembly_id,\n  m.membership_number,\n  m.first_name,\n  m.last_name,\n  m.other_names,\n  m.title,\n  m.date_of_birth,\n  m.gender,\n  m.marital_status,\n  m.primary_phone,\n  m.secondary_phone,\n  m.email,\n  m.physical_address,\n  m.occupation,\n  m.facebook_url,\n  m.whatsapp_number,\n  m.instagram_url,\n\n  -- Emergency contact: visible to admin or the member themselves\n  CASE\n    WHEN public.is_admin()\n      OR m.auth_user_id = (SELECT auth.uid())\n    THEN m.emergency_contact_name\n    ELSE NULL\n  END AS emergency_contact_name,\n\n  CASE\n    WHEN public.is_admin()\n      OR m.auth_user_id = (SELECT auth.uid())\n    THEN m.emergency_contact_phone\n    ELSE NULL\n  END AS emergency_contact_phone,\n\n  CASE\n    WHEN public.is_admin()\n      OR m.auth_user_id = (SELECT auth.uid())\n    THEN m.emergency_contact_relationship\n    ELSE NULL\n  END AS emergency_contact_relationship,\n\n  m.membership_status,\n  m.join_date,\n  m.household_id,\n  m.profile_photo_url,\n  m.auth_user_id,\n\n  -- Pastoral notes: admin-only (application layer enforces additional access for\n  -- users with a role that grants pastoral-care permissions — this is the DB floor)\n  CASE\n    WHEN public.is_admin()\n    THEN m.pastoral_notes\n    ELSE NULL\n  END AS pastoral_notes,\n\n  m.is_active,\n  m.deleted_at,\n  m.created_by,\n  m.created_at,\n  m.updated_at\n\nFROM public.members m","COMMENT ON VIEW public.members_view IS\n  'Security barrier + invoker view over members. security_invoker=true ensures '\n  'RLS of the querying user is applied. Column masking: emergency contact '\n  'visible to admin or own member row; pastoral notes visible to admin only. '\n  'All other role-based access decisions are enforced by authorization-service.ts '\n  'at the application layer — RLS only enforces DB-level floor rules.'","-- Re-grant SELECT to authenticated (required after DROP/CREATE of view)\nGRANT SELECT ON public.members_view TO authenticated","-- ─────────────────────────────────────────────────────────────────────────────\n-- 3. enforce_member_update_columns() trigger\n-- Old: complex branches for admin / secretary / pastor / volunteer / member\n-- New: admin = unrestricted; NULL = unrestricted (internal); everyone else = deny\n-- Application layer (authorization-service.ts) prevents unauthorized API calls\n-- before they reach this trigger.\n-- ─────────────────────────────────────────────────────────────────────────────\n\nCREATE OR REPLACE FUNCTION public.enforce_member_update_columns()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_role TEXT;\nBEGIN\n  v_role := public.get_user_role();\n\n  -- Allow internal system calls (triggers, migrations, service role).\n  IF v_role IS NULL THEN\n    RETURN NEW;\n  END IF;\n\n  -- Admin: unrestricted.\n  IF v_role = 'admin' THEN\n    RETURN NEW;\n  END IF;\n\n  -- All other system roles (currently: 'member'): deny direct updates.\n  -- Fine-grained write permissions are enforced by authorization-service.ts\n  -- before the request reaches the database. If a write reaches here from a\n  -- non-admin, it must be rejected as a defence-in-depth measure.\n  RAISE EXCEPTION 'Insufficient permissions to update member record'\n    USING ERRCODE = '42501';\nEND;\n$$","-- ─────────────────────────────────────────────────────────────────────────────\n-- 4. sync_user_permissions_to_jwt — update to use permission_key\n-- The old function referenced permission_id; role_permissions now has permission_key.\n-- ─────────────────────────────────────────────────────────────────────────────\n\nCREATE OR REPLACE FUNCTION public.sync_user_permissions_to_jwt()\nRETURNS TRIGGER\nLANGUAGE plpgsql\nSECURITY DEFINER\nSET search_path = public\nAS $$\nDECLARE\n  v_permissions TEXT[];\nBEGIN\n  -- Collect permission keys for the new assembly role (empty when NULL)\n  IF NEW.assembly_role_id IS NOT NULL THEN\n    SELECT ARRAY_AGG(rp.permission_key)\n      INTO v_permissions\n      FROM public.role_permissions rp\n     WHERE rp.role_id = NEW.assembly_role_id;\n  ELSE\n    v_permissions := ARRAY[]::TEXT[];\n  END IF;\n\n  -- Coalesce NULL to empty array\n  v_permissions := COALESCE(v_permissions, ARRAY[]::TEXT[]);\n\n  -- Write into auth.users.raw_app_meta_data (merges with existing keys)\n  UPDATE auth.users\n     SET raw_app_meta_data = raw_app_meta_data\n       || jsonb_build_object(\n            'assembly_id',  NEW.assembly_id,\n            'permissions',  to_jsonb(v_permissions)\n          )\n   WHERE id = NEW.id;\n\n  RETURN NEW;\nEND;\n$$","COMMENT ON FUNCTION public.sync_user_permissions_to_jwt() IS\n  'Fires after UPDATE of assembly_role_id or assembly_id on user_profiles. '\n  'Collects permission keys for the new assembly role and writes them into '\n  'auth.users.raw_app_meta_data as { assembly_id, permissions: [...] }. '\n  'The frontend reads this from the JWT app_metadata to hydrate the AppUser '\n  'permissions array without an extra DB round-trip.'","-- ─────────────────────────────────────────────────────────────────────────────\n-- 5. Update the JWT sync trigger to fire on assembly_role_id (renamed column)\n-- (Already done in migration 000004 but re-asserting here for safety)\n-- ─────────────────────────────────────────────────────────────────────────────\nDROP TRIGGER IF EXISTS sync_permissions_on_profile_update ON public.user_profiles","CREATE TRIGGER sync_permissions_on_profile_update\n  AFTER UPDATE OF assembly_role_id, assembly_id\n  ON public.user_profiles\n  FOR EACH ROW\n  EXECUTE FUNCTION public.sync_user_permissions_to_jwt()"}	rbac_refactor_rls
20260530000008	{"-- =============================================================================\n-- CACI Hub — Migration 20260530000008_rbac_restore_members_update_rls\n-- Purpose: Restore members UPDATE RLS policies that were dropped cascade\n--          when is_admin_or_secretary() was dropped in the earlier RBAC refactor.\n-- =============================================================================\n\n-- Restoring UPDATE policy for members\n-- In the new RBAC model, 'admin' system-role users bypass fine-grained checks\n-- at the DB trigger level. We must allow them through RLS first.\n\nDROP POLICY IF EXISTS members_update_admin ON public.members","CREATE POLICY members_update_admin\n  ON public.members\n  FOR UPDATE\n  TO authenticated\n  USING (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n    AND is_active = true\n  )\n  WITH CHECK (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )","-- Note: The enforce_member_update_columns trigger already blocks non-admin user\n-- system roles from doing direct updates to this table (defence-in-depth), so\n-- we only need an admin policy here.\n\n-- We also need to restore INSERT policies because those relied on is_admin_or_secretary too!\nDROP POLICY IF EXISTS members_insert_admin ON public.members","CREATE POLICY members_insert_admin\n  ON public.members\n  FOR INSERT\n  TO authenticated\n  WITH CHECK (\n    public.is_admin()\n    AND assembly_id = public.get_user_assembly_id()\n  )"}	rbac_restore_members_update_rls
20260531081636	{"-- Drop the duplicated phone column from user_profiles\n-- User phone numbers should be retrieved via members table\nALTER TABLE user_profiles DROP COLUMN IF EXISTS phone"}	drop_phone_from_user_profiles
20260602000000	{"-- 20260602000000_auth_assembly_id.sql\n-- Extracts the auth_assembly_id() helper so it is available to \n-- pastoral care, groups, services, and finance.\n\nCREATE OR REPLACE FUNCTION auth_assembly_id()\nRETURNS uuid LANGUAGE sql STABLE AS $$\n  SELECT assembly_id FROM user_profiles\n  WHERE id = auth.uid()\n$$"}	auth_assembly_id
20260602000001	{"-- ─────────────────────────────────────────────────────────────────────────────\n-- Pastoral Care Module — Full Schema\n-- Migration: 20260602000001_create_pastoral_care_module.sql\n-- Tables: pastoral_cases, pastoral_visits, prayer_requests\n-- ─────────────────────────────────────────────────────────────────────────────\n\n\n-- ── Enums ─────────────────────────────────────────────────────────────────────\n\nCREATE TYPE pastoral_case_type AS ENUM (\n  'follow_up',       -- absent / missing member\n  'bereavement',     -- death in family\n  'illness',         -- sick member or family\n  'counselling',     -- personal counselling\n  'discipline',      -- church discipline matter\n  'other'\n)","CREATE TYPE pastoral_priority AS ENUM (\n  'low',\n  'medium',\n  'high',\n  'urgent'\n)","CREATE TYPE pastoral_case_status AS ENUM (\n  'open',\n  'in_progress',\n  'resolved',\n  'closed'\n)","CREATE TYPE visit_type AS ENUM (\n  'home_visit',\n  'hospital_visit',\n  'phone_call',\n  'video_call',\n  'in_person'        -- at church premises\n)","CREATE TYPE visit_outcome AS ENUM (\n  'positive',\n  'needs_follow_up',\n  'no_response',\n  'referred'         -- escalated to senior pastor\n)","CREATE TYPE prayer_request_status AS ENUM (\n  'active',\n  'answered',\n  'closed'\n)","-- ── pastoral_cases ────────────────────────────────────────────────────────────\n-- Private. Visible to assigned_to + admins only.\n-- Can be opened by a pastor OR a group leader.\n\nCREATE TABLE pastoral_cases (\n  id           uuid                 PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id  uuid                 NOT NULL REFERENCES assemblies(id),\n  member_id    uuid                 NOT NULL REFERENCES members(id),\n  case_type    pastoral_case_type   NOT NULL,\n  title        text                 NOT NULL,\n  description  text,\n  priority     pastoral_priority    NOT NULL DEFAULT 'medium',\n  status       pastoral_case_status NOT NULL DEFAULT 'open',\n  assigned_to  uuid                 REFERENCES auth.users(id),  -- pastor or group leader\n  is_private   boolean              NOT NULL DEFAULT true,       -- extra lock for sensitive cases\n  created_by   uuid                 REFERENCES auth.users(id),\n  created_at   timestamptz          NOT NULL DEFAULT now(),\n  resolved_at  timestamptz,\n  deleted_at   timestamptz,\n  deleted_by   uuid                 REFERENCES auth.users(id),\n\n  -- prevent duplicate open cases of same type for same member\n  CONSTRAINT uq_open_case\n    UNIQUE (assembly_id, member_id, case_type, status)\n    DEFERRABLE INITIALLY DEFERRED\n)","-- ── pastoral_visits ───────────────────────────────────────────────────────────\n-- Child of pastoral_cases.\n-- Each follow-up action is one row.\n\nCREATE TABLE pastoral_visits (\n  id              uuid          PRIMARY KEY DEFAULT gen_random_uuid(),\n  case_id         uuid          NOT NULL REFERENCES pastoral_cases(id),\n  member_id       uuid          NOT NULL REFERENCES members(id),\n  visited_by      uuid          NOT NULL REFERENCES auth.users(id),\n  visit_type      visit_type    NOT NULL,\n  visit_date      date          NOT NULL,\n  notes           text,                     -- private — not shown to member\n  outcome         visit_outcome NOT NULL DEFAULT 'positive',\n  next_visit_date date,\n  created_at      timestamptz   NOT NULL DEFAULT now(),\n  deleted_at      timestamptz,\n  deleted_by      uuid          REFERENCES auth.users(id)\n)","-- ── prayer_requests ───────────────────────────────────────────────────────────\n-- Lighter and shared across pastoral staff.\n-- Anonymous flag hides member_id in app layer.\n\nCREATE TABLE prayer_requests (\n  id           uuid                   PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id  uuid                   NOT NULL REFERENCES assemblies(id),\n  member_id    uuid                   REFERENCES members(id),  -- nullable for anonymous\n  title        text                   NOT NULL,\n  description  text,\n  is_anonymous boolean                NOT NULL DEFAULT false,\n  status       prayer_request_status  NOT NULL DEFAULT 'active',\n  is_answered  boolean                NOT NULL DEFAULT false,\n  answered_at  timestamptz,\n  created_at   timestamptz            NOT NULL DEFAULT now(),\n  deleted_at   timestamptz,\n  deleted_by   uuid                   REFERENCES auth.users(id),\n\n  CONSTRAINT uq_prayer_request\n    UNIQUE (assembly_id, member_id, title)\n)","-- ── Indexes ───────────────────────────────────────────────────────────────────\n\n-- pastoral_cases\nCREATE INDEX idx_pc_assembly\n  ON pastoral_cases (assembly_id)","CREATE INDEX idx_pc_member\n  ON pastoral_cases (member_id)","-- powers \\"my open cases\\" dashboard per pastor/leader\nCREATE INDEX idx_pc_assigned_status\n  ON pastoral_cases (assigned_to, status)\n  WHERE deleted_at IS NULL","CREATE INDEX idx_pc_priority\n  ON pastoral_cases (assembly_id, priority)\n  WHERE status != 'closed' AND deleted_at IS NULL","-- pastoral_visits\nCREATE INDEX idx_pv_case\n  ON pastoral_visits (case_id)","CREATE INDEX idx_pv_member\n  ON pastoral_visits (member_id)","CREATE INDEX idx_pv_visited_by\n  ON pastoral_visits (visited_by)","-- powers \\"upcoming follow-ups\\" view\nCREATE INDEX idx_pv_next_visit\n  ON pastoral_visits (next_visit_date)\n  WHERE next_visit_date IS NOT NULL\n    AND deleted_at IS NULL","-- prayer_requests\nCREATE INDEX idx_pr_assembly\n  ON prayer_requests (assembly_id)","CREATE INDEX idx_pr_member\n  ON prayer_requests (member_id)\n  WHERE member_id IS NOT NULL","CREATE INDEX idx_pr_active\n  ON prayer_requests (assembly_id, status)\n  WHERE deleted_at IS NULL","-- ── Row Level Security ────────────────────────────────────────────────────────\n\nALTER TABLE pastoral_cases   ENABLE ROW LEVEL SECURITY","ALTER TABLE pastoral_visits  ENABLE ROW LEVEL SECURITY","ALTER TABLE prayer_requests  ENABLE ROW LEVEL SECURITY","-- Helper: checks the current user has the given pastoral permission.\n-- Mirrors has_finance_permission() pattern — hooks into system_permissions /\n-- role_permissions tables.\nCREATE OR REPLACE FUNCTION has_pastoral_permission(perm text)\nRETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM role_permissions rp\n    JOIN assembly_roles ar\n      ON ar.id = (\n        SELECT assembly_role_id FROM user_profiles\n        WHERE id = auth.uid()\n      )\n    JOIN system_permissions sp\n      ON sp.id = rp.permission_key\n    WHERE sp.key = perm\n      AND ar.assembly_id = auth_assembly_id()\n  )\n$$","-- ── pastoral_cases RLS ────────────────────────────────────────────────────────\n-- Read: assigned pastor OR case creator OR non-private cases (all pastoral staff) OR admin\n-- Write: assigned pastor OR case creator OR admin\n\nCREATE POLICY \\"pc: read assigned or admin\\"\n  ON pastoral_cases FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND (\n      assigned_to = auth.uid()           -- assigned pastor/leader\n      OR created_by = auth.uid()         -- whoever opened the case\n      OR is_private = false              -- non-private visible to all pastoral staff\n      OR EXISTS (                        -- assembly admin override\n        SELECT 1 FROM user_profiles\n        WHERE id = auth.uid()\n          AND assembly_id = auth_assembly_id()\n          AND role = 'admin'\n      )\n    )\n    AND has_pastoral_permission('pastoral.view')\n  )","CREATE POLICY \\"pc: insert own assembly\\"\n  ON pastoral_cases FOR INSERT\n  WITH CHECK (\n    assembly_id = auth_assembly_id()\n    AND has_pastoral_permission('pastoral.manage')\n  )","CREATE POLICY \\"pc: update assigned or admin\\"\n  ON pastoral_cases FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND (\n      assigned_to = auth.uid()\n      OR created_by = auth.uid()\n      OR EXISTS (\n        SELECT 1 FROM user_profiles\n        WHERE id = auth.uid()\n          AND assembly_id = auth_assembly_id()\n          AND role = 'admin'\n      )\n    )\n    AND has_pastoral_permission('pastoral.manage')\n  )","-- ── pastoral_visits RLS ───────────────────────────────────────────────────────\n-- Scoped through parent pastoral_case.\n\nCREATE POLICY \\"pv: read via case access\\"\n  ON pastoral_visits FOR SELECT\n  USING (\n    deleted_at IS NULL\n    AND has_pastoral_permission('pastoral.view')\n    AND EXISTS (\n      SELECT 1 FROM pastoral_cases pc\n      WHERE pc.id = pastoral_visits.case_id\n        AND pc.assembly_id = auth_assembly_id()\n        AND pc.deleted_at IS NULL\n        AND (\n          pc.assigned_to = auth.uid()\n          OR pc.created_by = auth.uid()\n          OR pc.is_private = false\n          OR EXISTS (\n            SELECT 1 FROM user_profiles\n            WHERE id = auth.uid()\n              AND assembly_id = auth_assembly_id()\n              AND role = 'admin'\n          )\n        )\n    )\n  )","CREATE POLICY \\"pv: insert via case access\\"\n  ON pastoral_visits FOR INSERT\n  WITH CHECK (\n    has_pastoral_permission('pastoral.manage')\n    AND EXISTS (\n      SELECT 1 FROM pastoral_cases pc\n      WHERE pc.id = case_id\n        AND pc.assembly_id = auth_assembly_id()\n        AND (\n          pc.assigned_to = auth.uid()\n          OR pc.created_by = auth.uid()\n        )\n    )\n  )","CREATE POLICY \\"pv: update own visits\\"\n  ON pastoral_visits FOR UPDATE\n  USING (\n    visited_by = auth.uid()\n    AND deleted_at IS NULL\n    AND has_pastoral_permission('pastoral.manage')\n  )","-- ── prayer_requests RLS ───────────────────────────────────────────────────────\n-- All pastoral staff can read non-anonymous.\n-- Anonymous: member_id hidden at app layer —\n-- DB still stores it for admin audit purposes.\n\nCREATE POLICY \\"pr: read own assembly staff\\"\n  ON prayer_requests FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_pastoral_permission('pastoral.view')\n  )","CREATE POLICY \\"pr: insert own assembly\\"\n  ON prayer_requests FOR INSERT\n  WITH CHECK (\n    assembly_id = auth_assembly_id()\n    AND has_pastoral_permission('pastoral.manage')\n  )","CREATE POLICY \\"pr: update own or admin\\"\n  ON prayer_requests FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_pastoral_permission('pastoral.manage')\n    AND (\n      member_id = (\n        SELECT m.id FROM members m\n        WHERE m.auth_user_id = auth.uid()\n          AND m.assembly_id = auth_assembly_id()\n        LIMIT 1\n      )\n      OR EXISTS (\n        SELECT 1 FROM user_profiles\n        WHERE id = auth.uid()\n          AND assembly_id = auth_assembly_id()\n          AND role = 'admin'\n      )\n    )\n  )","-- ── Grants ────────────────────────────────────────────────────────────────────\nGRANT SELECT, INSERT, UPDATE ON pastoral_cases   TO authenticated","GRANT SELECT, INSERT, UPDATE ON pastoral_visits  TO authenticated","GRANT SELECT, INSERT, UPDATE ON prayer_requests  TO authenticated"}	create_pastoral_care_module
20260602000002	{"-- ─────────────────────────────────────────────────────────────────────────────\n-- Groups Module — Full Schema\n-- Migration: 20260602000002_create_groups_module.sql\n-- Tables: groups, group_members\n-- Note: auth_assembly_id() is already defined in an earlier migration.\n-- ─────────────────────────────────────────────────────────────────────────────\n\n\n-- ── Enums ─────────────────────────────────────────────────────────────────────\n\nCREATE TYPE group_type AS ENUM (\n  'department',   -- choir, ushers, media, etc.\n  'age_group'     -- youth, children, men, women\n)","CREATE TYPE group_member_role AS ENUM (\n  'leader',\n  'assistant_leader',\n  'member'\n)","-- ── groups ────────────────────────────────────────────────────────────────────\n-- Flat structure — no nesting. group_type enum locks to department | age_group.\n\nCREATE TABLE groups (\n  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id  uuid        NOT NULL REFERENCES assemblies(id),\n  name         text        NOT NULL,\n  group_type   group_type  NOT NULL,\n  description  text,\n  is_active    boolean     NOT NULL DEFAULT true,\n  leader_id    uuid        REFERENCES members(id),\n  created_by   uuid        REFERENCES auth.users(id),\n  created_at   timestamptz NOT NULL DEFAULT now(),\n  deleted_at   timestamptz,\n  deleted_by   uuid        REFERENCES auth.users(id),\n\n  -- no two groups with the same name and type in an assembly\n  CONSTRAINT uq_group_name\n    UNIQUE (assembly_id, name, group_type)\n)","-- ── group_members ─────────────────────────────────────────────────────────────\n-- Links a member to a group with a role and active window.\n-- One member can belong to multiple groups.\n\nCREATE TABLE group_members (\n  id          uuid              PRIMARY KEY DEFAULT gen_random_uuid(),\n  group_id    uuid              NOT NULL REFERENCES groups(id),\n  member_id   uuid              NOT NULL REFERENCES members(id),\n  role        group_member_role NOT NULL DEFAULT 'member',\n  joined_at   date              NOT NULL DEFAULT current_date,\n  left_at     date,\n  is_active   boolean           NOT NULL DEFAULT true,\n  created_by  uuid              REFERENCES auth.users(id),\n  created_at  timestamptz       NOT NULL DEFAULT now(),\n  deleted_at  timestamptz,\n  deleted_by  uuid              REFERENCES auth.users(id),\n\n  -- one active membership per member per group at a time\n  CONSTRAINT uq_active_membership\n    UNIQUE (group_id, member_id)\n)","-- ── Indexes ───────────────────────────────────────────────────────────────────\n\n-- groups\nCREATE INDEX idx_groups_assembly\n  ON groups (assembly_id)","CREATE INDEX idx_groups_active\n  ON groups (assembly_id, group_type)\n  WHERE is_active = true AND deleted_at IS NULL","-- group_members\nCREATE INDEX idx_gm_group\n  ON group_members (group_id)","CREATE INDEX idx_gm_member\n  ON group_members (member_id)","-- powers \\"list active members of a group\\"\nCREATE INDEX idx_gm_active\n  ON group_members (group_id, is_active)\n  WHERE is_active = true AND deleted_at IS NULL","-- powers \\"list all groups a member belongs to\\"\nCREATE INDEX idx_gm_member_active\n  ON group_members (member_id)\n  WHERE is_active = true AND deleted_at IS NULL","-- ── Row Level Security ────────────────────────────────────────────────────────\n-- auth_assembly_id() is already defined — no need to redefine it.\n\nALTER TABLE groups        ENABLE ROW LEVEL SECURITY","ALTER TABLE group_members ENABLE ROW LEVEL SECURITY","-- groups RLS\nCREATE POLICY \\"groups: read own assembly\\"\n  ON groups FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n  )","CREATE POLICY \\"groups: insert own assembly\\"\n  ON groups FOR INSERT\n  WITH CHECK (assembly_id = auth_assembly_id())","CREATE POLICY \\"groups: update own assembly\\"\n  ON groups FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n  )","-- group_members RLS\n-- Scoped through parent groups table.\n\nCREATE POLICY \\"gm: read own assembly\\"\n  ON group_members FOR SELECT\n  USING (\n    EXISTS (\n      SELECT 1 FROM groups g\n      WHERE g.id = group_members.group_id\n        AND g.assembly_id = auth_assembly_id()\n        AND g.deleted_at IS NULL\n    )\n    AND deleted_at IS NULL\n  )","CREATE POLICY \\"gm: insert own assembly\\"\n  ON group_members FOR INSERT\n  WITH CHECK (\n    EXISTS (\n      SELECT 1 FROM groups g\n      WHERE g.id = group_id\n        AND g.assembly_id = auth_assembly_id()\n    )\n  )","CREATE POLICY \\"gm: update own assembly\\"\n  ON group_members FOR UPDATE\n  USING (\n    EXISTS (\n      SELECT 1 FROM groups g\n      WHERE g.id = group_members.group_id\n        AND g.assembly_id = auth_assembly_id()\n    )\n    AND deleted_at IS NULL\n  )","-- members can read their own group memberships\nCREATE POLICY \\"gm: members read own\\"\n  ON group_members FOR SELECT\n  USING (\n    member_id IN (\n      SELECT id FROM members\n      WHERE assembly_id = auth_assembly_id()\n    )\n  )","-- ── Grants ────────────────────────────────────────────────────────────────────\nGRANT SELECT, INSERT, UPDATE ON groups        TO authenticated","GRANT SELECT, INSERT, UPDATE ON group_members TO authenticated"}	create_groups_module
20260602000003	{"-- ─────────────────────────────────────────────────────────────────────────────\n-- Services Module — Full Schema\n-- Migration: 20260602000003_create_services_module.sql\n-- Tables: service_templates, services, service_attendance, service_audit_log\n-- ─────────────────────────────────────────────────────────────────────────────\n\n\n-- ── Enums ─────────────────────────────────────────────────────────────────────\n\nCREATE TYPE service_status AS ENUM (\n  'scheduled',\n  'completed',\n  'cancelled'\n)","CREATE TYPE attendance_status AS ENUM (\n  'present',\n  'absent',\n  'excused'\n)","CREATE TYPE recurrence_type AS ENUM (\n  'none',\n  'daily',\n  'weekly',\n  'biweekly',\n  'monthly'\n)","-- ── service_templates ─────────────────────────────────────────────────────────\n-- Recurring service blueprints. group_id = NULL means open to all members.\n\nCREATE TABLE service_templates (\n  id                  uuid            PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id         uuid            NOT NULL REFERENCES assemblies(id),\n  group_id            uuid            REFERENCES groups(id),      -- NULL = open to all\n  title               text            NOT NULL,\n  service_type        text            NOT NULL,\n  recurrence          recurrence_type NOT NULL DEFAULT 'weekly',\n  day_of_week         text,\n  start_time          time,\n  venue               text,\n  recurrence_end_date date,\n  is_active           boolean         NOT NULL DEFAULT true,\n  created_by          uuid            REFERENCES auth.users(id),\n  created_at          timestamptz     NOT NULL DEFAULT now(),\n  deleted_at          timestamptz,\n  deleted_by          uuid            REFERENCES auth.users(id),\n\n  CONSTRAINT uq_template_assembly_title\n    UNIQUE (assembly_id, title, recurrence, day_of_week)\n)","-- ── services ──────────────────────────────────────────────────────────────────\n-- Individual service instances. Can optionally be linked to a template.\n\nCREATE TABLE services (\n  id           uuid           PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id  uuid           NOT NULL REFERENCES assemblies(id),\n  template_id  uuid           REFERENCES service_templates(id),\n  group_id     uuid           REFERENCES groups(id),      -- NULL = open to all\n  title        text           NOT NULL,\n  service_type text           NOT NULL,\n  service_date date           NOT NULL,\n  start_time   time,\n  venue        text,\n  headcount    integer        CHECK (headcount >= 0),\n  notes        text,\n  status       service_status NOT NULL DEFAULT 'scheduled',\n  created_by   uuid           REFERENCES auth.users(id),\n  created_at   timestamptz    NOT NULL DEFAULT now(),\n  deleted_at   timestamptz,\n  deleted_by   uuid           REFERENCES auth.users(id),\n\n  CONSTRAINT uq_service_per_day\n    UNIQUE (assembly_id, group_id, service_date, service_type)\n)","-- ── service_attendance ────────────────────────────────────────────────────────\n-- One row per member per service. Soft-deletable.\n\nCREATE TABLE service_attendance (\n  id         uuid              PRIMARY KEY DEFAULT gen_random_uuid(),\n  service_id uuid              NOT NULL REFERENCES services(id),\n  member_id  uuid              NOT NULL REFERENCES members(id),\n  status     attendance_status NOT NULL DEFAULT 'present',\n  notes      text,\n  marked_by  uuid              REFERENCES auth.users(id),\n  marked_at  timestamptz       NOT NULL DEFAULT now(),\n  deleted_at timestamptz,\n  deleted_by uuid              REFERENCES auth.users(id),\n\n  -- one record per member per service\n  CONSTRAINT uq_attendance_per_service\n    UNIQUE (service_id, member_id)\n)","-- ── service_audit_log ─────────────────────────────────────────────────────────\n-- Append-only. Never updated or deleted.\n-- Populated by the log_service_changes() trigger.\n\nCREATE TABLE service_audit_log (\n  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),\n  service_id    uuid        NOT NULL REFERENCES services(id),\n  changed_by    uuid        REFERENCES auth.users(id),\n  field_changed text        NOT NULL,\n  old_value     text,\n  new_value     text,\n  changed_at    timestamptz NOT NULL DEFAULT now()\n)","-- ── Indexes ───────────────────────────────────────────────────────────────────\n\n-- service_templates\nCREATE INDEX idx_tmpl_assembly\n  ON service_templates (assembly_id)","CREATE INDEX idx_tmpl_group\n  ON service_templates (group_id)\n  WHERE group_id IS NOT NULL","CREATE INDEX idx_tmpl_active\n  ON service_templates (assembly_id, is_active)\n  WHERE deleted_at IS NULL","-- services\nCREATE INDEX idx_svc_assembly\n  ON services (assembly_id)","CREATE INDEX idx_svc_template\n  ON services (template_id)\n  WHERE template_id IS NOT NULL","CREATE INDEX idx_svc_group\n  ON services (group_id)\n  WHERE group_id IS NOT NULL","CREATE INDEX idx_svc_date\n  ON services (service_date)","CREATE INDEX idx_svc_active\n  ON services (assembly_id, service_date)\n  WHERE deleted_at IS NULL","CREATE INDEX idx_svc_status\n  ON services (status)\n  WHERE deleted_at IS NULL","-- service_attendance\nCREATE INDEX idx_att_service\n  ON service_attendance (service_id)","CREATE INDEX idx_att_member\n  ON service_attendance (member_id)","CREATE INDEX idx_att_active\n  ON service_attendance (service_id)\n  WHERE deleted_at IS NULL","-- powers \\"absent 3+ weeks\\" query\nCREATE INDEX idx_att_status\n  ON service_attendance (member_id, status)\n  WHERE deleted_at IS NULL","-- service_audit_log\nCREATE INDEX idx_audit_service\n  ON service_audit_log (service_id)","CREATE INDEX idx_audit_changed_at\n  ON service_audit_log (changed_at)","-- ── Row Level Security ────────────────────────────────────────────────────────\n-- auth_assembly_id() is already defined — no need to redefine it.\n\nALTER TABLE service_templates   ENABLE ROW LEVEL SECURITY","ALTER TABLE services            ENABLE ROW LEVEL SECURITY","ALTER TABLE service_attendance  ENABLE ROW LEVEL SECURITY","ALTER TABLE service_audit_log   ENABLE ROW LEVEL SECURITY","-- service_templates\nCREATE POLICY \\"tmpl: read own assembly\\"\n  ON service_templates FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n  )","CREATE POLICY \\"tmpl: insert own assembly\\"\n  ON service_templates FOR INSERT\n  WITH CHECK (assembly_id = auth_assembly_id())","CREATE POLICY \\"tmpl: update own assembly\\"\n  ON service_templates FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n  )","-- services\nCREATE POLICY \\"svc: read own assembly\\"\n  ON services FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n  )","CREATE POLICY \\"svc: insert own assembly\\"\n  ON services FOR INSERT\n  WITH CHECK (assembly_id = auth_assembly_id())","CREATE POLICY \\"svc: update own assembly\\"\n  ON services FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n  )","-- service_attendance — scoped through parent services table\nCREATE POLICY \\"att: read own assembly\\"\n  ON service_attendance FOR SELECT\n  USING (\n    EXISTS (\n      SELECT 1 FROM services s\n      WHERE s.id = service_attendance.service_id\n        AND s.assembly_id = auth_assembly_id()\n        AND s.deleted_at IS NULL\n    )\n    AND deleted_at IS NULL\n  )","CREATE POLICY \\"att: insert own assembly\\"\n  ON service_attendance FOR INSERT\n  WITH CHECK (\n    EXISTS (\n      SELECT 1 FROM services s\n      WHERE s.id = service_id\n        AND s.assembly_id = auth_assembly_id()\n    )\n  )","CREATE POLICY \\"att: update own assembly\\"\n  ON service_attendance FOR UPDATE\n  USING (\n    EXISTS (\n      SELECT 1 FROM services s\n      WHERE s.id = service_attendance.service_id\n        AND s.assembly_id = auth_assembly_id()\n    )\n    AND deleted_at IS NULL\n  )","-- service_audit_log — read + insert only; no UPDATE or DELETE (immutable)\nCREATE POLICY \\"audit: read own assembly\\"\n  ON service_audit_log FOR SELECT\n  USING (\n    EXISTS (\n      SELECT 1 FROM services s\n      WHERE s.id = service_audit_log.service_id\n        AND s.assembly_id = auth_assembly_id()\n    )\n  )","CREATE POLICY \\"audit: insert only\\"\n  ON service_audit_log FOR INSERT\n  WITH CHECK (\n    EXISTS (\n      SELECT 1 FROM services s\n      WHERE s.id = service_id\n        AND s.assembly_id = auth_assembly_id()\n    )\n  )","-- ── Audit Trigger ─────────────────────────────────────────────────────────────\n-- Fires after every UPDATE on services.\n-- Compares old vs new for each tracked field and inserts one row per change.\n\nCREATE OR REPLACE FUNCTION log_service_changes()\nRETURNS TRIGGER LANGUAGE plpgsql\nSECURITY DEFINER AS $$\nDECLARE\n  col     text;\n  old_val text;\n  new_val text;\nBEGIN\n  FOREACH col IN ARRAY ARRAY[\n    'title', 'status', 'service_date',\n    'start_time', 'venue', 'headcount',\n    'notes', 'group_id', 'deleted_at'\n  ] LOOP\n    EXECUTE format('SELECT ($1).%I::text', col)\n      INTO old_val USING OLD;\n    EXECUTE format('SELECT ($1).%I::text', col)\n      INTO new_val USING NEW;\n\n    IF old_val IS DISTINCT FROM new_val THEN\n      INSERT INTO service_audit_log (\n        service_id, changed_by,\n        field_changed, old_value, new_value\n      ) VALUES (\n        NEW.id, auth.uid(),\n        col, old_val, new_val\n      );\n    END IF;\n  END LOOP;\n  RETURN NEW;\nEND;\n$$","CREATE TRIGGER trg_service_audit\n  AFTER UPDATE ON services\n  FOR EACH ROW\n  EXECUTE FUNCTION log_service_changes()","-- ── Grants ────────────────────────────────────────────────────────────────────\nGRANT SELECT, INSERT, UPDATE ON service_templates   TO authenticated","GRANT SELECT, INSERT, UPDATE ON services            TO authenticated","GRANT SELECT, INSERT, UPDATE ON service_attendance  TO authenticated","GRANT SELECT, INSERT         ON service_audit_log   TO authenticated"}	create_services_module
20260602000004	{"-- ─────────────────────────────────────────────────────────────────────────────\n-- Finance Module — Full Schema\n-- Migration: 20260601000001_create_finance_module.sql\n-- Tables: finance_categories, finance_transactions, finance_pledges,\n--         finance_budgets\n-- ─────────────────────────────────────────────────────────────────────────────\n\n\n-- ── Enums ─────────────────────────────────────────────────────────────────────\n\nCREATE TYPE finance_transaction_type AS ENUM (\n  'tithe',\n  'offering',\n  'special_offering',\n  'pledge_payment',\n  'donation',\n  'expense'\n)","CREATE TYPE finance_payment_method AS ENUM (\n  'cash',\n  'momo',\n  'bank_transfer',\n  'cheque',\n  'other'\n)","CREATE TYPE finance_pledge_status AS ENUM (\n  'active',\n  'completed',\n  'defaulted',\n  'cancelled'\n)","CREATE TYPE finance_budget_period AS ENUM (\n  'monthly',\n  'quarterly',\n  'annual'\n)","CREATE TYPE finance_category_type AS ENUM (\n  'income',\n  'expense'\n)","-- ── finance_categories ────────────────────────────────────────────────────────\n-- Chart of accounts for the assembly. Separates income from expense lines.\n\nCREATE TABLE finance_categories (\n  id            uuid                   PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id   uuid                   NOT NULL REFERENCES assemblies(id),\n  name          text                   NOT NULL,\n  category_type finance_category_type  NOT NULL,\n  description   text,\n  is_active     boolean                NOT NULL DEFAULT true,\n  created_by    uuid                   REFERENCES auth.users(id),\n  created_at    timestamptz            NOT NULL DEFAULT now(),\n  deleted_at    timestamptz,\n  deleted_by    uuid                   REFERENCES auth.users(id),\n\n  CONSTRAINT uq_category_name\n    UNIQUE (assembly_id, name, category_type)\n)","-- ── finance_pledges ───────────────────────────────────────────────────────────\n-- Defined BEFORE finance_transactions because transactions have a FK to pledges.\n\nCREATE TABLE finance_pledges (\n  id            uuid                  PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id   uuid                  NOT NULL REFERENCES assemblies(id),\n  member_id     uuid                  NOT NULL REFERENCES members(id),\n  pledge_name   text                  NOT NULL,\n  total_amount  numeric(12, 2)        NOT NULL CHECK (total_amount > 0),\n  amount_paid   numeric(12, 2)        NOT NULL DEFAULT 0 CHECK (amount_paid >= 0),\n  currency      text                  NOT NULL DEFAULT 'GHS',\n  start_date    date                  NOT NULL DEFAULT current_date,\n  end_date      date,\n  status        finance_pledge_status NOT NULL DEFAULT 'active',\n  notes         text,\n  created_by    uuid                  REFERENCES auth.users(id),\n  created_at    timestamptz           NOT NULL DEFAULT now(),\n  deleted_at    timestamptz,\n  deleted_by    uuid                  REFERENCES auth.users(id),\n\n  CONSTRAINT chk_pledge_amount\n    CHECK (amount_paid <= total_amount),\n\n  CONSTRAINT uq_pledge\n    UNIQUE (assembly_id, member_id, pledge_name)\n)","-- ── finance_transactions ──────────────────────────────────────────────────────\n-- Main ledger. Every income or expense entry.\n\nCREATE TABLE finance_transactions (\n  id               uuid                      PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id      uuid                      NOT NULL REFERENCES assemblies(id),\n  category_id      uuid                      NOT NULL REFERENCES finance_categories(id),\n  member_id        uuid                      REFERENCES members(id),\n  transaction_type finance_transaction_type  NOT NULL,\n  amount           numeric(12, 2)            NOT NULL CHECK (amount > 0),\n  currency         text                      NOT NULL DEFAULT 'GHS',\n  payment_method   finance_payment_method    NOT NULL,\n  reference_number text,\n  transaction_date date                      NOT NULL DEFAULT current_date,\n  description      text,\n  service_id       uuid                      REFERENCES services(id),\n  group_id         uuid                      REFERENCES groups(id),\n  pledge_id        uuid                      REFERENCES finance_pledges(id),\n  recorded_by      uuid                      REFERENCES auth.users(id),\n  created_at       timestamptz               NOT NULL DEFAULT now(),\n  deleted_at       timestamptz,\n  deleted_by       uuid                      REFERENCES auth.users(id),\n\n  CONSTRAINT uq_transaction_reference\n    UNIQUE (assembly_id, reference_number)\n    DEFERRABLE INITIALLY DEFERRED\n)","-- ── finance_budgets ───────────────────────────────────────────────────────────\n-- Planned vs actual per category per period.\n\nCREATE TABLE finance_budgets (\n  id               uuid                  PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id      uuid                  NOT NULL REFERENCES assemblies(id),\n  category_id      uuid                  NOT NULL REFERENCES finance_categories(id),\n  period           finance_budget_period NOT NULL,\n  year             integer               NOT NULL CHECK (year >= 2000),\n  month            integer               CHECK (month BETWEEN 1 AND 12),\n  quarter          integer               CHECK (quarter BETWEEN 1 AND 4),\n  budgeted_amount  numeric(12, 2)        NOT NULL CHECK (budgeted_amount >= 0),\n  actual_amount    numeric(12, 2)        NOT NULL DEFAULT 0,\n  notes            text,\n  created_by       uuid                  REFERENCES auth.users(id),\n  created_at       timestamptz           NOT NULL DEFAULT now(),\n  deleted_at       timestamptz,\n  deleted_by       uuid                  REFERENCES auth.users(id),\n\n  CONSTRAINT uq_budget_period\n    UNIQUE (assembly_id, category_id, period, year, month, quarter)\n)","-- ── Indexes ───────────────────────────────────────────────────────────────────\n\n-- finance_categories\nCREATE INDEX idx_fcat_assembly\n  ON finance_categories (assembly_id)","CREATE INDEX idx_fcat_active\n  ON finance_categories (assembly_id, category_type)\n  WHERE is_active = true AND deleted_at IS NULL","-- finance_transactions\nCREATE INDEX idx_ftx_assembly\n  ON finance_transactions (assembly_id)","CREATE INDEX idx_ftx_date\n  ON finance_transactions (assembly_id, transaction_date)\n  WHERE deleted_at IS NULL","CREATE INDEX idx_ftx_member\n  ON finance_transactions (member_id)\n  WHERE member_id IS NOT NULL AND deleted_at IS NULL","CREATE INDEX idx_ftx_category\n  ON finance_transactions (category_id)\n  WHERE deleted_at IS NULL","CREATE INDEX idx_ftx_service\n  ON finance_transactions (service_id)\n  WHERE service_id IS NOT NULL","CREATE INDEX idx_ftx_pledge\n  ON finance_transactions (pledge_id)\n  WHERE pledge_id IS NOT NULL","-- finance_pledges\nCREATE INDEX idx_fpl_assembly\n  ON finance_pledges (assembly_id)","CREATE INDEX idx_fpl_member\n  ON finance_pledges (member_id)","CREATE INDEX idx_fpl_active\n  ON finance_pledges (assembly_id, status)\n  WHERE status = 'active' AND deleted_at IS NULL","-- finance_budgets\nCREATE INDEX idx_fbg_assembly\n  ON finance_budgets (assembly_id)","CREATE INDEX idx_fbg_category_period\n  ON finance_budgets (assembly_id, category_id, year)\n  WHERE deleted_at IS NULL","-- ── Row Level Security ────────────────────────────────────────────────────────\n\nALTER TABLE finance_categories   ENABLE ROW LEVEL SECURITY","ALTER TABLE finance_transactions  ENABLE ROW LEVEL SECURITY","ALTER TABLE finance_pledges       ENABLE ROW LEVEL SECURITY","ALTER TABLE finance_budgets       ENABLE ROW LEVEL SECURITY","-- Helper: checks that the current user has the given finance permission\n-- Hooks into the existing system_permissions / role_permissions tables.\nCREATE OR REPLACE FUNCTION has_finance_permission(perm text)\nRETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM role_permissions rp\n    JOIN assembly_roles ar\n      ON ar.id = (\n        SELECT assembly_role_id FROM user_profiles\n        WHERE id = auth.uid()\n      )\n    JOIN system_permissions sp\n      ON sp.id = rp.permission_key\n    WHERE sp.key = perm\n      AND ar.assembly_id = auth_assembly_id()\n  )\n$$","-- finance_categories RLS\nCREATE POLICY \\"fcat: read with finance.view\\"\n  ON finance_categories FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.view')\n  )","CREATE POLICY \\"fcat: write with finance.manage\\"\n  ON finance_categories FOR INSERT\n  WITH CHECK (\n    assembly_id = auth_assembly_id()\n    AND has_finance_permission('finance.manage')\n  )","CREATE POLICY \\"fcat: update with finance.manage\\"\n  ON finance_categories FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.manage')\n  )","-- finance_transactions RLS\nCREATE POLICY \\"ftx: read with finance.view\\"\n  ON finance_transactions FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.view')\n  )","CREATE POLICY \\"ftx: insert with finance.manage\\"\n  ON finance_transactions FOR INSERT\n  WITH CHECK (\n    assembly_id = auth_assembly_id()\n    AND has_finance_permission('finance.manage')\n  )","CREATE POLICY \\"ftx: update with finance.manage\\"\n  ON finance_transactions FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.manage')\n  )","-- finance_pledges RLS\nCREATE POLICY \\"fpl: read with finance.view\\"\n  ON finance_pledges FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.view')\n  )","CREATE POLICY \\"fpl: insert with finance.manage\\"\n  ON finance_pledges FOR INSERT\n  WITH CHECK (\n    assembly_id = auth_assembly_id()\n    AND has_finance_permission('finance.manage')\n  )","CREATE POLICY \\"fpl: update with finance.manage\\"\n  ON finance_pledges FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.manage')\n  )","-- finance_budgets RLS\nCREATE POLICY \\"fbg: read with finance.view\\"\n  ON finance_budgets FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.view')\n  )","CREATE POLICY \\"fbg: insert with finance.manage\\"\n  ON finance_budgets FOR INSERT\n  WITH CHECK (\n    assembly_id = auth_assembly_id()\n    AND has_finance_permission('finance.manage')\n  )","CREATE POLICY \\"fbg: update with finance.manage\\"\n  ON finance_budgets FOR UPDATE\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND has_finance_permission('finance.manage')\n  )","-- ── Grants ────────────────────────────────────────────────────────────────────\nGRANT SELECT, INSERT, UPDATE ON finance_categories   TO authenticated","GRANT SELECT, INSERT, UPDATE ON finance_transactions  TO authenticated","GRANT SELECT, INSERT, UPDATE ON finance_pledges       TO authenticated","GRANT SELECT, INSERT, UPDATE ON finance_budgets       TO authenticated"}	create_finance_module
20260606000001	{"-- =============================================================================\n-- CACI Hub — Migration 20260606000001_seed_missing_permissions\n-- Purpose:  Seed recently added modules' permissions (Services, Groups,\n--           Pastoral Care, Finance updates) that were added to frontend\n--           constants but missing from the database.\n-- =============================================================================\n\nINSERT INTO public.system_permissions (id, key, label, description, module_name, category, is_assignable, is_active) VALUES\n\n  -- ── Services ─────────────────────────────────────────────────────────────\n  ('services.view',              'services.view',              'View Services',             'Allows viewing services and attendance records',     'events', 'Services', true, true),\n  ('services.create',            'services.create',            'Create Services',           'Allows creating new services',                       'events', 'Services', true, true),\n  ('services.edit',              'services.edit',              'Edit Services',             'Allows editing existing services',                   'events', 'Services', true, true),\n  ('services.delete',            'services.delete',            'Delete Services',           'Allows deleting services',                           'events', 'Services', true, true),\n  ('services.templates.manage',  'services.templates.manage',  'Manage Service Templates',  'Allows creating and editing service templates',      'events', 'Services', true, true),\n  ('services.attendance.mark',   'services.attendance.mark',   'Mark Attendance',           'Allows marking attendance for services',             'events', 'Services', true, true),\n\n  -- ── Groups ───────────────────────────────────────────────────────────────\n  ('groups.view',                'groups.view',                'View Groups',               'Allows viewing groups and their members',            'membership', 'Groups', true, true),\n  ('groups.create',              'groups.create',              'Create Groups',             'Allows creating new groups',                         'membership', 'Groups', true, true),\n  ('groups.edit',                'groups.edit',                'Edit Groups',               'Allows editing existing groups',                     'membership', 'Groups', true, true),\n  ('groups.delete',              'groups.delete',              'Delete Groups',             'Allows deleting groups',                             'membership', 'Groups', true, true),\n  ('groups.members.manage',      'groups.members.manage',      'Manage Group Members',      'Allows adding and removing members from groups',     'membership', 'Groups', true, true),\n\n  -- ── Finance ──────────────────────────────────────────────────────────────\n  ('finance.view',               'finance.view',               'View Finance',              'Allows viewing financial records',                   'finance', 'Finance', true, true),\n  ('finance.manage',             'finance.manage',             'Manage Finance',            'Allows managing and editing financial records',      'finance', 'Finance', true, true),\n  ('finance.export',             'finance.export',             'Export Finance',            'Allows exporting financial records',                 'finance', 'Finance', true, true),\n\n  -- ── Pastoral Care ────────────────────────────────────────────────────────\n  ('pastoral.view',              'pastoral.view',              'View Pastoral Care',        'Allows viewing pastoral care records',               'membership', 'Pastoral Care', true, true),\n  ('pastoral.manage',            'pastoral.manage',            'Manage Pastoral Care',      'Allows managing pastoral care records',              'membership', 'Pastoral Care', true, true),\n  ('pastoral.prayer.manage',     'pastoral.prayer.manage',     'Manage Prayer Requests',    'Allows managing prayer requests',                    'membership', 'Pastoral Care', true, true)\n\nON CONFLICT (key) DO UPDATE SET\n  label         = EXCLUDED.label,\n  description   = EXCLUDED.description,\n  module_name   = EXCLUDED.module_name,\n  category      = EXCLUDED.category,\n  is_assignable = EXCLUDED.is_assignable"}	seed_missing_permissions
20260610000001	{"-- Communication module schema\n-- Adds templates, campaigns, and messages tables for multi-channel outreach.\n\nCREATE TABLE communication_templates (\n  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id            uuid NOT NULL REFERENCES assemblies(id),\n  title                  text NOT NULL,\n  body                   text NOT NULL,\n  channel                text NOT NULL CHECK (channel IN ('in_app', 'email', 'sms', 'whatsapp', 'push')),\n  category               text NOT NULL CHECK (category IN ('broadcast', 'direct', 'automated', 'announcement')),\n  variables              jsonb DEFAULT '[]',\n  whatsapp_template_name text,\n  is_active              bool DEFAULT true,\n  created_by             uuid REFERENCES user_profiles(id),\n  created_at             timestamptz DEFAULT now(),\n  updated_at             timestamptz DEFAULT now(),\n  deleted_at             timestamptz,\n  deleted_by             uuid REFERENCES user_profiles(id)\n)","CREATE TABLE communication_campaigns (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  template_id           uuid REFERENCES communication_templates(id),\n  title                 text NOT NULL,\n  channel               text NOT NULL CHECK (channel IN ('in_app', 'email', 'sms', 'whatsapp', 'push')),\n  audience_type         text NOT NULL CHECK (audience_type IN ('assembly', 'group', 'member_list', 'filter')),\n  audience_ids          uuid[] DEFAULT '{}',\n  trigger_type          text NOT NULL DEFAULT 'manual'\n                          CHECK (trigger_type IN ('manual', 'birthday', 'event_reminder', 'pledge_reminder', 'custom')),\n  status                text NOT NULL DEFAULT 'draft'\n                          CHECK (status IN ('draft', 'scheduled', 'sending', 'sent', 'failed', 'cancelled')),\n  scheduled_at          timestamptz,\n  sent_at               timestamptz,\n  total_recipients      int4 DEFAULT 0,\n  created_by            uuid REFERENCES user_profiles(id),\n  created_at            timestamptz DEFAULT now(),\n  deleted_at            timestamptz,\n  deleted_by            uuid REFERENCES user_profiles(id)\n)","CREATE TABLE communication_messages (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  campaign_id           uuid REFERENCES communication_campaigns(id),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  member_id             uuid NOT NULL REFERENCES members(id),\n  channel               text NOT NULL,\n  body_resolved         text NOT NULL,\n  status                text NOT NULL DEFAULT 'queued'\n                          CHECK (status IN ('queued', 'sent', 'delivered', 'read', 'failed')),\n  provider              text CHECK (provider IN ('sendgrid', 'twilio', 'arkesel', 'fcm', 'internal')),\n  external_ref          text,\n  provider_status       text,\n  failed_reason         text,\n  cost_units            int4 DEFAULT 0,\n  delivered_at          timestamptz,\n  read_at               timestamptz,\n  created_at            timestamptz DEFAULT now(),\n  deleted_at            timestamptz\n)","CREATE TABLE communication_threads (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  subject               text,\n  is_pastoral           bool DEFAULT false,\n  is_sensitive          bool DEFAULT false,\n  created_by            uuid REFERENCES user_profiles(id),\n  created_at            timestamptz DEFAULT now(),\n  deleted_at            timestamptz,\n  deleted_by            uuid REFERENCES user_profiles(id)\n)","CREATE TABLE communication_thread_participants (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  thread_id             uuid NOT NULL REFERENCES communication_threads(id),\n  member_id             uuid NOT NULL REFERENCES members(id),\n  role                  text DEFAULT 'member' CHECK (role IN ('member','pastor','admin')),\n  joined_at             timestamptz DEFAULT now(),\n  left_at               timestamptz,\n  last_read_at          timestamptz,\n  UNIQUE(thread_id, member_id)\n)","CREATE TABLE communication_thread_messages (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  thread_id             uuid NOT NULL REFERENCES communication_threads(id),\n  sender_id             uuid NOT NULL REFERENCES members(id),\n  message_type          text NOT NULL DEFAULT 'text'\n                          CHECK (message_type IN ('text','audio','image','document')),\n  body                  text,\n  storage_tier          text DEFAULT 'hot'\n                          CHECK (storage_tier IN ('hot','warm','cold')),\n  created_at            timestamptz DEFAULT now(),\n  edited_at             timestamptz,\n  deleted_at            timestamptz,\n  deleted_by            uuid REFERENCES user_profiles(id)\n)","CREATE TABLE communication_attachments (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  thread_message_id     uuid REFERENCES communication_thread_messages(id),\n  campaign_id           uuid REFERENCES communication_campaigns(id),\n\n  -- Storage location\n  storage_tier          text NOT NULL DEFAULT 'hot'\n                          CHECK (storage_tier IN ('hot','warm','cold')),\n  storage_provider      text NOT NULL DEFAULT 'supabase'\n                          CHECK (storage_provider IN ('supabase','r2')),\n  storage_bucket        text NOT NULL,\n  storage_path          text NOT NULL,\n  public_url            text,\n\n  -- File metadata\n  mime_type             text NOT NULL,\n  file_size_bytes       int8 NOT NULL,\n  original_filename     text,\n  checksum              text,\n\n  -- Audio specific\n  duration_seconds      int4,\n  waveform_data         jsonb,\n  normalised_path       text,\n  transcription_text    text,\n  transcription_status  text DEFAULT 'skipped'\n                          CHECK (transcription_status IN ('pending','processing','done','failed','skipped')),\n\n  -- Security\n  is_sensitive          bool DEFAULT false,\n  virus_scan_status     text DEFAULT 'pending'\n                          CHECK (virus_scan_status IN ('pending','clean','infected','skipped')),\n\n  -- Lifecycle\n  uploaded_by           uuid REFERENCES user_profiles(id),\n  archive_after         timestamptz,\n  purge_after           timestamptz,\n  archived_at           timestamptz,\n  created_at            timestamptz DEFAULT now(),\n  deleted_at            timestamptz,\n  deleted_by            uuid REFERENCES user_profiles(id)\n)","CREATE TABLE announcement_posts (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  title                 text NOT NULL,\n  body                  text NOT NULL,\n  target_group_ids      uuid[] DEFAULT '{}',\n  is_pinned             bool DEFAULT false,\n  visible_from          timestamptz DEFAULT now(),\n  visible_until         timestamptz,\n  posted_by             uuid REFERENCES user_profiles(id),\n  created_at            timestamptz DEFAULT now(),\n  deleted_at            timestamptz,\n  deleted_by            uuid REFERENCES user_profiles(id)\n)","CREATE TABLE communication_trigger_rules (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  trigger_event         text NOT NULL\n                          CHECK (trigger_event IN (\n                            'member.birthday','service.reminder',\n                            'pledge.overdue','member.join_anniversary'\n                          )),\n  template_id           uuid NOT NULL REFERENCES communication_templates(id),\n  channels              text[] NOT NULL,\n  days_offset           int4 DEFAULT 0,\n  offset_direction      text DEFAULT 'before' CHECK (offset_direction IN ('before','after')),\n  is_active             bool DEFAULT true,\n  created_by            uuid REFERENCES user_profiles(id),\n  created_at            timestamptz DEFAULT now()\n)","CREATE TABLE communication_preferences (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  member_id             uuid NOT NULL REFERENCES members(id),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  channel               text NOT NULL,\n  category              text NOT NULL,\n  opted_in              bool DEFAULT true,\n  updated_at            timestamptz DEFAULT now(),\n  UNIQUE(member_id, channel, category)\n)","CREATE TABLE push_device_tokens (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  member_id             uuid NOT NULL REFERENCES members(id),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  device_token          text NOT NULL,\n  platform              text NOT NULL CHECK (platform IN ('ios','android','web')),\n  is_active             bool DEFAULT true,\n  last_used_at          timestamptz,\n  created_at            timestamptz DEFAULT now(),\n  UNIQUE(member_id, device_token)\n)","CREATE TABLE webhook_events (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  provider              text NOT NULL,\n  event_type            text NOT NULL,\n  payload               jsonb NOT NULL,\n  message_id            uuid REFERENCES communication_messages(id),\n  processed_at          timestamptz,\n  created_at            timestamptz DEFAULT now()\n)","CREATE TABLE storage_signed_url_log (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  attachment_id         uuid NOT NULL REFERENCES communication_attachments(id),\n  requested_by          uuid NOT NULL REFERENCES user_profiles(id),\n  ip_address            text,\n  expires_at            timestamptz NOT NULL,\n  created_at            timestamptz DEFAULT now()\n)","CREATE TABLE assembly_storage_usage (\n  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n  assembly_id           uuid NOT NULL REFERENCES assemblies(id),\n  snapshot_month        date NOT NULL,\n  supabase_bytes        int8 DEFAULT 0,\n  r2_warm_bytes         int8 DEFAULT 0,\n  r2_cold_bytes         int8 DEFAULT 0,\n  total_bytes           int8 GENERATED ALWAYS AS (supabase_bytes + r2_warm_bytes + r2_cold_bytes) STORED,\n  sms_segments_sent     int4 DEFAULT 0,\n  whatsapp_msgs_sent    int4 DEFAULT 0,\n  created_at            timestamptz DEFAULT now(),\n  UNIQUE(assembly_id, snapshot_month)\n)","CREATE INDEX idx_comm_messages_campaign   ON communication_messages(campaign_id)","CREATE INDEX idx_comm_messages_member     ON communication_messages(member_id)","CREATE INDEX idx_comm_messages_status     ON communication_messages(status)","CREATE INDEX idx_comm_attachments_tier    ON communication_attachments(storage_tier, storage_provider)","CREATE INDEX idx_comm_attachments_archive ON communication_attachments(archive_after)\n  WHERE archived_at IS NULL AND deleted_at IS NULL","CREATE INDEX idx_thread_messages_thread   ON communication_thread_messages(thread_id, created_at)","CREATE INDEX idx_webhook_events_msg       ON webhook_events(message_id)","CREATE INDEX idx_push_tokens_member       ON push_device_tokens(member_id) WHERE is_active = true"}	create_communication_module
20260610000002	{"-- Communication module RLS policies and helpers\n-- Adds row-level security to all communication tables + permission seeds\n\n---\n-- PART 1: Helper functions\n---\n\n-- Helper function: get assembly_id for the current auth user\nCREATE OR REPLACE FUNCTION auth_assembly_id()\nRETURNS uuid\nLANGUAGE sql STABLE SECURITY DEFINER\nAS $$\n  SELECT assembly_id FROM user_profiles WHERE id = auth.uid() LIMIT 1;\n$$","-- Helper function: check a permission key for the current auth user\nCREATE OR REPLACE FUNCTION auth_has_permission(perm_key text)\nRETURNS boolean\nLANGUAGE sql STABLE SECURITY DEFINER\nAS $$\n  SELECT EXISTS (\n    SELECT 1\n    FROM user_profiles up\n    JOIN assembly_roles ar  ON ar.id = up.assembly_role_id\n    JOIN role_permissions rp ON rp.role_id = ar.id\n    WHERE up.id = auth.uid()\n    AND   rp.permission_key = perm_key\n    AND   ar.is_active = true\n    AND   up.is_active = true\n  );\n$$","-- Helper function: check if current user is a member of an assembly\nCREATE OR REPLACE FUNCTION auth_member_id()\nRETURNS uuid\nLANGUAGE sql STABLE SECURITY DEFINER\nAS $$\n  SELECT id FROM members\n  WHERE auth_user_id = auth.uid()\n  AND   is_active = true\n  LIMIT 1;\n$$","---\n-- PART 2: Enable RLS on all communication tables\n---\n\nALTER TABLE communication_templates          ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_campaigns          ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_messages           ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_threads            ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_thread_participants ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_thread_messages    ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_attachments        ENABLE ROW LEVEL SECURITY","ALTER TABLE announcement_posts               ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_trigger_rules      ENABLE ROW LEVEL SECURITY","ALTER TABLE communication_preferences        ENABLE ROW LEVEL SECURITY","ALTER TABLE push_device_tokens               ENABLE ROW LEVEL SECURITY","ALTER TABLE webhook_events                   ENABLE ROW LEVEL SECURITY","ALTER TABLE storage_signed_url_log           ENABLE ROW LEVEL SECURITY","ALTER TABLE assembly_storage_usage           ENABLE ROW LEVEL SECURITY","---\n-- PART 3: RLS Policies\n---\n\n-- communication_templates\nCREATE POLICY \\"templates: members read own assembly\\"\nON communication_templates FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND is_active = true\n  AND deleted_at IS NULL\n)","CREATE POLICY \\"templates: managers insert\\"\nON communication_templates FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.templates.manage')\n)","CREATE POLICY \\"templates: managers update\\"\nON communication_templates FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.templates.manage')\n)","CREATE POLICY \\"templates: managers soft delete\\"\nON communication_templates FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.templates.manage')\n)","-- communication_campaigns\nCREATE POLICY \\"campaigns: members read own assembly\\"\nON communication_campaigns FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n)","CREATE POLICY \\"campaigns: senders insert\\"\nON communication_campaigns FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.broadcast.send')\n)","CREATE POLICY \\"campaigns: senders update own or admin any\\"\nON communication_campaigns FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND (\n    created_by = auth.uid()\n    OR auth_has_permission('communications.broadcast.schedule')\n  )\n  AND deleted_at IS NULL\n)","-- communication_messages\nCREATE POLICY \\"messages: members read own\\"\nON communication_messages FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND member_id = auth_member_id()\n  AND deleted_at IS NULL\n)","CREATE POLICY \\"messages: reporters read assembly\\"\nON communication_messages FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.reports.view')\n  AND deleted_at IS NULL\n)","-- communication_threads\nCREATE POLICY \\"threads: participants read\\"\nON communication_threads FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND EXISTS (\n    SELECT 1 FROM communication_thread_participants ctp\n    WHERE ctp.thread_id = id\n    AND   ctp.member_id = auth_member_id()\n    AND   ctp.left_at IS NULL\n  )\n)","CREATE POLICY \\"threads: pastoral restricted\\"\nON communication_threads FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND (\n    is_sensitive = false\n    OR auth_has_permission('communications.attachments.view_pastoral')\n  )\n  AND EXISTS (\n    SELECT 1 FROM communication_thread_participants ctp\n    WHERE ctp.thread_id = id\n    AND   ctp.member_id = auth_member_id()\n    AND   ctp.left_at IS NULL\n  )\n)","CREATE POLICY \\"threads: members insert non-pastoral\\"\nON communication_threads FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND is_pastoral = false\n  AND is_sensitive = false\n)","CREATE POLICY \\"threads: pastoral role insert sensitive\\"\nON communication_threads FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.direct.send_pastoral')\n)","-- communication_thread_participants\nCREATE POLICY \\"thread_participants: read own threads\\"\nON communication_thread_participants FOR SELECT\nUSING (\n  EXISTS (\n    SELECT 1 FROM communication_threads ct\n    WHERE ct.id = thread_id\n    AND   ct.assembly_id = auth_assembly_id()\n    AND   ct.deleted_at IS NULL\n  )\n  AND EXISTS (\n    SELECT 1 FROM communication_thread_participants ctp2\n    WHERE ctp2.thread_id = thread_id\n    AND   ctp2.member_id = auth_member_id()\n    AND   ctp2.left_at IS NULL\n  )\n)","CREATE POLICY \\"thread_participants: thread creator insert\\"\nON communication_thread_participants FOR INSERT\nWITH CHECK (\n  EXISTS (\n    SELECT 1 FROM communication_threads ct\n    WHERE ct.id = thread_id\n    AND   ct.assembly_id = auth_assembly_id()\n    AND   ct.created_by = auth.uid()\n    AND   ct.deleted_at IS NULL\n  )\n)","CREATE POLICY \\"thread_participants: update own read timestamp\\"\nON communication_thread_participants FOR UPDATE\nUSING (member_id = auth_member_id())\nWITH CHECK (member_id = auth_member_id())","-- communication_thread_messages\nCREATE POLICY \\"thread_messages: participants read\\"\nON communication_thread_messages FOR SELECT\nUSING (\n  deleted_at IS NULL\n  AND EXISTS (\n    SELECT 1 FROM communication_thread_participants ctp\n    WHERE ctp.thread_id = thread_id\n    AND   ctp.member_id = auth_member_id()\n    AND   ctp.left_at IS NULL\n  )\n)","CREATE POLICY \\"thread_messages: participants insert text\\"\nON communication_thread_messages FOR INSERT\nWITH CHECK (\n  message_type = 'text'\n  AND sender_id = auth_member_id()\n  AND EXISTS (\n    SELECT 1 FROM communication_thread_participants ctp\n    WHERE ctp.thread_id = thread_id\n    AND   ctp.member_id = auth_member_id()\n    AND   ctp.left_at IS NULL\n  )\n)","CREATE POLICY \\"thread_messages: pastor insert audio\\"\nON communication_thread_messages FOR INSERT\nWITH CHECK (\n  message_type = 'audio'\n  AND sender_id = auth_member_id()\n  AND auth_has_permission('communications.audio.broadcast')\n  AND EXISTS (\n    SELECT 1 FROM communication_thread_participants ctp\n    WHERE ctp.thread_id = thread_id\n    AND   ctp.member_id = auth_member_id()\n    AND   ctp.left_at IS NULL\n  )\n)","CREATE POLICY \\"thread_messages: sender soft delete within 24h\\"\nON communication_thread_messages FOR UPDATE\nUSING (\n  sender_id = auth_member_id()\n  AND created_at > now() - interval '24 hours'\n  AND deleted_at IS NULL\n)\nWITH CHECK (\n  deleted_at IS NOT NULL\n  AND deleted_by = auth.uid()\n)","CREATE POLICY \\"thread_messages: admin soft delete\\"\nON communication_thread_messages FOR UPDATE\nUSING (\n  auth_has_permission('communications.direct.moderate')\n  AND EXISTS (\n    SELECT 1 FROM communication_threads ct\n    WHERE ct.id = thread_id\n    AND   ct.assembly_id = auth_assembly_id()\n  )\n)","-- communication_attachments\nCREATE POLICY \\"attachments: assembly scoped read\\"\nON communication_attachments FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND (\n    is_sensitive = false\n    OR auth_has_permission('communications.attachments.view_pastoral')\n  )\n)","CREATE POLICY \\"attachments: pastor upload audio\\"\nON communication_attachments FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND mime_type LIKE 'audio/%'\n  AND auth_has_permission('communications.audio.broadcast')\n  AND uploaded_by = auth.uid()\n)","CREATE POLICY \\"attachments: members upload non-audio\\"\nON communication_attachments FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND mime_type NOT LIKE 'audio/%'\n  AND is_sensitive = false\n  AND uploaded_by = auth.uid()\n)","CREATE POLICY \\"attachments: uploader or admin soft delete\\"\nON communication_attachments FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND (\n    uploaded_by = auth.uid()\n    OR auth_has_permission('communications.attachments.manage')\n  )\n)","-- announcement_posts\nCREATE POLICY \\"announcements: members read active\\"\nON announcement_posts FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND visible_from <= now()\n  AND (visible_until IS NULL OR visible_until > now())\n  AND (\n    target_group_ids = '{}'\n    OR EXISTS (\n      SELECT 1 FROM group_members gm\n      WHERE gm.member_id = auth_member_id()\n      AND   gm.group_id = ANY(target_group_ids)\n      AND   gm.is_active = true\n    )\n  )\n)","CREATE POLICY \\"announcements: managers insert\\"\nON announcement_posts FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.announcements.manage')\n)","CREATE POLICY \\"announcements: managers update\\"\nON announcement_posts FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.announcements.manage')\n  AND deleted_at IS NULL\n)","-- communication_preferences\nCREATE POLICY \\"preferences: members read own\\"\nON communication_preferences FOR SELECT\nUSING (member_id = auth_member_id())","CREATE POLICY \\"preferences: members insert own\\"\nON communication_preferences FOR INSERT\nWITH CHECK (\n  member_id = auth_member_id()\n  AND assembly_id = auth_assembly_id()\n)","CREATE POLICY \\"preferences: members update own\\"\nON communication_preferences FOR UPDATE\nUSING (member_id = auth_member_id())\nWITH CHECK (member_id = auth_member_id())","-- push_device_tokens\nCREATE POLICY \\"push_tokens: members read own\\"\nON push_device_tokens FOR SELECT\nUSING (member_id = auth_member_id())","CREATE POLICY \\"push_tokens: members insert own\\"\nON push_device_tokens FOR INSERT\nWITH CHECK (\n  member_id = auth_member_id()\n  AND assembly_id = auth_assembly_id()\n)","CREATE POLICY \\"push_tokens: members update own\\"\nON push_device_tokens FOR UPDATE\nUSING (member_id = auth_member_id())\nWITH CHECK (member_id = auth_member_id())","CREATE POLICY \\"push_tokens: members delete own\\"\nON push_device_tokens FOR DELETE\nUSING (member_id = auth_member_id())","-- storage_signed_url_log\nCREATE POLICY \\"signed_url_log: admins read\\"\nON storage_signed_url_log FOR SELECT\nUSING (\n  auth_has_permission('communications.reports.view')\n  AND EXISTS (\n    SELECT 1 FROM communication_attachments ca\n    WHERE ca.id = attachment_id\n    AND   ca.assembly_id = auth_assembly_id()\n  )\n)","CREATE POLICY \\"signed_url_log: members read own\\"\nON storage_signed_url_log FOR SELECT\nUSING (requested_by = auth.uid())","-- assembly_storage_usage\nCREATE POLICY \\"storage_usage: admins read\\"\nON assembly_storage_usage FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.reports.view')\n)","-- communication_trigger_rules\nCREATE POLICY \\"trigger_rules: admins read\\"\nON communication_trigger_rules FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.templates.manage')\n)","CREATE POLICY \\"trigger_rules: admins insert\\"\nON communication_trigger_rules FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.templates.manage')\n)","CREATE POLICY \\"trigger_rules: admins update\\"\nON communication_trigger_rules FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND auth_has_permission('communications.templates.manage')\n)","-- webhook_events: only service role (Edge Functions)\n-- no end-user policies\n\n---\n-- PART 4: Storage usage increment function\n---\n\nCREATE OR REPLACE FUNCTION increment_storage_usage(\n  p_assembly_id uuid,\n  p_bytes       int8\n)\nRETURNS void\nLANGUAGE plpgsql SECURITY DEFINER\nAS $$\nDECLARE\n  v_month date := date_trunc('month', now())::date;\nBEGIN\n  INSERT INTO assembly_storage_usage (assembly_id, snapshot_month, supabase_bytes)\n  VALUES (p_assembly_id, v_month, p_bytes)\n  ON CONFLICT (assembly_id, snapshot_month)\n  DO UPDATE SET supabase_bytes = assembly_storage_usage.supabase_bytes + p_bytes;\nEND;\n$$","---\n-- PART 5: Seed new permission keys\n---\n\nINSERT INTO system_permissions\n  (id, key, label, module_name, category, is_assignable, is_active, description)\nVALUES\n  (gen_random_uuid(), 'communications.broadcast.send',          'Send Broadcasts',            'communications', 'messaging',    true, true, 'Create and send broadcast campaigns'),\n  (gen_random_uuid(), 'communications.broadcast.schedule',      'Schedule Broadcasts',        'communications', 'messaging',    true, true, 'Schedule broadcast campaigns for future delivery'),\n  (gen_random_uuid(), 'communications.direct.send',             'Send Direct Messages',       'communications', 'messaging',    true, true, 'Send direct messages to members'),\n  (gen_random_uuid(), 'communications.direct.send_pastoral',    'Send Pastoral Messages',     'communications', 'pastoral',     true, true, 'Create pastoral threads and sensitive direct messages'),\n  (gen_random_uuid(), 'communications.direct.moderate',         'Moderate Threads',           'communications', 'moderation',   true, true, 'Delete any message in any thread'),\n  (gen_random_uuid(), 'communications.audio.broadcast',         'Send Audio Broadcasts',      'communications', 'media',        true, true, 'Upload and broadcast audio messages (pastor only)'),\n  (gen_random_uuid(), 'communications.announcements.manage',    'Manage Announcements',       'communications', 'content',      true, true, 'Post, edit and pin assembly announcements'),\n  (gen_random_uuid(), 'communications.templates.manage',        'Manage Templates',           'communications', 'admin',        true, true, 'Create and edit message templates and trigger rules'),\n  (gen_random_uuid(), 'communications.attachments.view_pastoral','View Pastoral Attachments', 'communications', 'pastoral',     true, true, 'Access media in pastoral and sensitive threads'),\n  (gen_random_uuid(), 'communications.attachments.manage',      'Manage Attachments',         'communications', 'admin',        true, true, 'Delete any attachment in the assembly'),\n  (gen_random_uuid(), 'communications.reports.view',            'View Comms Reports',         'communications', 'reporting',    true, true, 'View delivery stats, signed URL logs, storage usage')\nON CONFLICT (key) DO NOTHING"}	communication_rls_policies
20260612000001	{"-- Fix infinite recursion in communication RLS policies\n-- \n-- Problem: communication_threads SELECT policy checks communication_thread_participants,\n--          and communication_thread_participants SELECT policy checks back into\n--          communication_threads, creating infinite recursion.\n--\n-- Solution: Create SECURITY DEFINER helper functions that bypass RLS to check\n--           participant membership directly, breaking the circular dependency.\n\n---\n-- PART 1: Helper functions (SECURITY DEFINER — bypass RLS to break the cycle)\n---\n\n-- Returns true if the current auth user's member profile is a participant in the given thread.\n-- SECURITY DEFINER means this query runs WITHOUT RLS on the participants table,\n-- which is safe because we only SELECT a boolean (no data leakage).\nCREATE OR REPLACE FUNCTION auth_is_thread_participant(p_thread_id uuid)\nRETURNS boolean\nLANGUAGE sql STABLE SECURITY DEFINER\nAS $$\n  SELECT EXISTS (\n    SELECT 1 FROM communication_thread_participants\n    WHERE thread_id = p_thread_id\n    AND   member_id = auth_member_id()\n    AND   left_at IS NULL\n  );\n$$","-- Returns true if the current user is a participant of the thread that owns a given participant row.\n-- Used by the communication_thread_participants SELECT policy.\nCREATE OR REPLACE FUNCTION auth_is_participant_of_thread(p_thread_id uuid)\nRETURNS boolean\nLANGUAGE sql STABLE SECURITY DEFINER\nAS $$\n  SELECT EXISTS (\n    SELECT 1 FROM communication_thread_participants\n    WHERE thread_id = p_thread_id\n    AND   member_id = auth_member_id()\n    AND   left_at IS NULL\n  );\n$$","---\n-- PART 2: Drop old recursive policies\n---\n\nDROP POLICY IF EXISTS \\"threads: participants read\\"       ON communication_threads","DROP POLICY IF EXISTS \\"threads: pastoral restricted\\"     ON communication_threads","DROP POLICY IF EXISTS \\"thread_participants: read own threads\\" ON communication_thread_participants","---\n-- PART 3: Recreate non-recursive policies using the helper functions\n---\n\n-- communication_threads: allow read if user is a participant (uses SECURITY DEFINER fn)\nCREATE POLICY \\"threads: participants read\\"\nON communication_threads FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND auth_is_thread_participant(id)\n)","-- communication_threads: restrict pastoral/sensitive threads (uses SECURITY DEFINER fn)\nCREATE POLICY \\"threads: pastoral restricted\\"\nON communication_threads FOR SELECT\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND (\n    is_sensitive = false\n    OR auth_has_permission('communications.attachments.view_pastoral')\n  )\n  AND auth_is_thread_participant(id)\n)","-- communication_thread_participants: allow read via SECURITY DEFINER fn\n-- (no longer references communication_threads to break the cycle)\nCREATE POLICY \\"thread_participants: read own threads\\"\nON communication_thread_participants FOR SELECT\nUSING (\n  auth_is_participant_of_thread(thread_id)\n)"}	fix_rls_recursion
20260612000002	{"-- Fix communication module INSERT RLS policies to allow admin bypass\n--\n-- Problem: Admin user has role = 'admin' in user_profiles but assembly_role_id = null,\n--          so auth_has_permission() always returns false for them.\n--          The INSERT policies require specific permissions, blocking admin from creating\n--          campaigns, templates, and announcements.\n--\n-- Solution: Add `public.is_admin()` (OR) bypass to all communication INSERT/UPDATE policies\n--           so that users with role = 'admin' in user_profiles are always permitted.\n\n---\n-- communication_campaigns\n---\n\nDROP POLICY IF EXISTS \\"campaigns: senders insert\\" ON communication_campaigns","CREATE POLICY \\"campaigns: senders insert\\"\nON communication_campaigns FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.broadcast.send')\n  )\n)","DROP POLICY IF EXISTS \\"campaigns: senders update own or admin any\\" ON communication_campaigns","CREATE POLICY \\"campaigns: senders update own or admin any\\"\nON communication_campaigns FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND (\n    public.is_admin()\n    OR created_by = auth.uid()\n    OR auth_has_permission('communications.broadcast.schedule')\n  )\n)","---\n-- communication_templates\n---\n\nDROP POLICY IF EXISTS \\"templates: managers insert\\" ON communication_templates","CREATE POLICY \\"templates: managers insert\\"\nON communication_templates FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.templates.manage')\n  )\n)","DROP POLICY IF EXISTS \\"templates: managers update\\" ON communication_templates","CREATE POLICY \\"templates: managers update\\"\nON communication_templates FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.templates.manage')\n  )\n)","DROP POLICY IF EXISTS \\"templates: managers soft delete\\" ON communication_templates","CREATE POLICY \\"templates: managers soft delete\\"\nON communication_templates FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.templates.manage')\n  )\n)","---\n-- announcement_posts\n---\n\nDROP POLICY IF EXISTS \\"announcements: managers insert\\" ON announcement_posts","CREATE POLICY \\"announcements: managers insert\\"\nON announcement_posts FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.announcements.manage')\n  )\n)","DROP POLICY IF EXISTS \\"announcements: managers update\\" ON announcement_posts","CREATE POLICY \\"announcements: managers update\\"\nON announcement_posts FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND deleted_at IS NULL\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.announcements.manage')\n  )\n)","---\n-- communication_trigger_rules\n---\n\nDROP POLICY IF EXISTS \\"trigger_rules: admins insert\\" ON communication_trigger_rules","CREATE POLICY \\"trigger_rules: admins insert\\"\nON communication_trigger_rules FOR INSERT\nWITH CHECK (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.templates.manage')\n  )\n)","DROP POLICY IF EXISTS \\"trigger_rules: admins update\\" ON communication_trigger_rules","CREATE POLICY \\"trigger_rules: admins update\\"\nON communication_trigger_rules FOR UPDATE\nUSING (\n  assembly_id = auth_assembly_id()\n  AND (\n    public.is_admin()\n    OR auth_has_permission('communications.templates.manage')\n  )\n)"}	fix_communication_admin_rls
20260612000003	{"-- =============================================================================\n-- CACI Hub — Migration 20260612000003_fix_finance_rls_admin_bypass\n-- Purpose:  Finance module RLS policies were gating all reads behind\n--           has_finance_permission('finance.view'), but no migration ever\n--           seeded role_permissions rows for 'finance.view' / 'finance.manage'\n--           for any assembly_role.  As a result even admin users saw zero\n--           records.\n--\n--           Fix: drop and recreate the SELECT policies to OR-in is_admin(),\n--           exactly as every other module (members, services, groups, etc.)\n--           does.  The has_finance_permission check is retained so that\n--           non-admin custom roles still need the permission explicitly\n--           assigned.\n--\n-- Affects:  finance_categories, finance_transactions, finance_pledges,\n--           finance_budgets  (SELECT policies only).\n-- =============================================================================\n\n-- ── finance_categories ────────────────────────────────────────────────────────\n\nDROP POLICY IF EXISTS \\"fcat: read with finance.view\\" ON finance_categories","CREATE POLICY \\"fcat: read with finance.view\\"\n  ON finance_categories FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND (\n      is_admin()\n      OR has_finance_permission('finance.view')\n    )\n  )","-- ── finance_transactions ──────────────────────────────────────────────────────\n\nDROP POLICY IF EXISTS \\"ftx: read with finance.view\\" ON finance_transactions","CREATE POLICY \\"ftx: read with finance.view\\"\n  ON finance_transactions FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND (\n      is_admin()\n      OR has_finance_permission('finance.view')\n    )\n  )","-- ── finance_pledges ───────────────────────────────────────────────────────────\n\nDROP POLICY IF EXISTS \\"fpl: read with finance.view\\" ON finance_pledges","CREATE POLICY \\"fpl: read with finance.view\\"\n  ON finance_pledges FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND (\n      is_admin()\n      OR has_finance_permission('finance.view')\n    )\n  )","-- ── finance_budgets ───────────────────────────────────────────────────────────\n\nDROP POLICY IF EXISTS \\"fbg: read with finance.view\\" ON finance_budgets","CREATE POLICY \\"fbg: read with finance.view\\"\n  ON finance_budgets FOR SELECT\n  USING (\n    assembly_id = auth_assembly_id()\n    AND deleted_at IS NULL\n    AND (\n      is_admin()\n      OR has_finance_permission('finance.view')\n    )\n  )"}	fix_finance_rls_admin_bypass
20260612000004	{"-- =============================================================================\n-- CACI Hub — Migration 20260612000004_fix_auth_assembly_id_security_definer\n-- Purpose:  The auth_assembly_id() helper function was defined WITHOUT\n--           SECURITY DEFINER. Because user_profiles has RLS enabled, any call\n--           to auth_assembly_id() from within another table's RLS policy would\n--           run the inner SELECT on user_profiles under the calling user's\n--           security context, which can return NULL (blocked by RLS recursion).\n--\n--           When auth_assembly_id() returns NULL, every RLS condition of the\n--           form `assembly_id = auth_assembly_id()` evaluates to FALSE and\n--           silently returns zero rows — exactly what we see on the Finance page.\n--\n--           Fix:  Recreate auth_assembly_id() as SECURITY DEFINER (matching\n--           the pattern used by get_user_assembly_id() and is_admin()).\n-- =============================================================================\n\nCREATE OR REPLACE FUNCTION public.auth_assembly_id()\nRETURNS uuid\nLANGUAGE sql\nSTABLE\nSECURITY DEFINER\nSET search_path = public\nAS $$\n  SELECT assembly_id\n  FROM public.user_profiles\n  WHERE id = auth.uid()\n  LIMIT 1;\n$$","COMMENT ON FUNCTION public.auth_assembly_id() IS\n  'Returns the assembly_id for the currently authenticated user. '\n  'SECURITY DEFINER prevents RLS recursion when called from other table RLS policies.'"}	fix_auth_assembly_id_security_definer
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 587, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: announcement_posts announcement_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_posts
    ADD CONSTRAINT announcement_posts_pkey PRIMARY KEY (id);


--
-- Name: assemblies assemblies_assembly_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assemblies
    ADD CONSTRAINT assemblies_assembly_code_key UNIQUE (assembly_code);


--
-- Name: assemblies assemblies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assemblies
    ADD CONSTRAINT assemblies_pkey PRIMARY KEY (id);


--
-- Name: assembly_roles assembly_roles_assembly_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assembly_roles
    ADD CONSTRAINT assembly_roles_assembly_id_name_key UNIQUE (assembly_id, name);


--
-- Name: assembly_roles assembly_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assembly_roles
    ADD CONSTRAINT assembly_roles_pkey PRIMARY KEY (id);


--
-- Name: assembly_storage_usage assembly_storage_usage_assembly_id_snapshot_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assembly_storage_usage
    ADD CONSTRAINT assembly_storage_usage_assembly_id_snapshot_month_key UNIQUE (assembly_id, snapshot_month);


--
-- Name: assembly_storage_usage assembly_storage_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assembly_storage_usage
    ADD CONSTRAINT assembly_storage_usage_pkey PRIMARY KEY (id);


--
-- Name: communication_attachments communication_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_attachments
    ADD CONSTRAINT communication_attachments_pkey PRIMARY KEY (id);


--
-- Name: communication_campaigns communication_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_campaigns
    ADD CONSTRAINT communication_campaigns_pkey PRIMARY KEY (id);


--
-- Name: communication_messages communication_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT communication_messages_pkey PRIMARY KEY (id);


--
-- Name: communication_preferences communication_preferences_member_id_channel_category_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_preferences
    ADD CONSTRAINT communication_preferences_member_id_channel_category_key UNIQUE (member_id, channel, category);


--
-- Name: communication_preferences communication_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_preferences
    ADD CONSTRAINT communication_preferences_pkey PRIMARY KEY (id);


--
-- Name: communication_templates communication_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_pkey PRIMARY KEY (id);


--
-- Name: communication_thread_messages communication_thread_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_messages
    ADD CONSTRAINT communication_thread_messages_pkey PRIMARY KEY (id);


--
-- Name: communication_thread_participants communication_thread_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_participants
    ADD CONSTRAINT communication_thread_participants_pkey PRIMARY KEY (id);


--
-- Name: communication_thread_participants communication_thread_participants_thread_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_participants
    ADD CONSTRAINT communication_thread_participants_thread_id_member_id_key UNIQUE (thread_id, member_id);


--
-- Name: communication_threads communication_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_threads
    ADD CONSTRAINT communication_threads_pkey PRIMARY KEY (id);


--
-- Name: communication_trigger_rules communication_trigger_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_trigger_rules
    ADD CONSTRAINT communication_trigger_rules_pkey PRIMARY KEY (id);


--
-- Name: finance_budgets finance_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_pkey PRIMARY KEY (id);


--
-- Name: finance_categories finance_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_categories
    ADD CONSTRAINT finance_categories_pkey PRIMARY KEY (id);


--
-- Name: finance_pledges finance_pledges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_pledges
    ADD CONSTRAINT finance_pledges_pkey PRIMARY KEY (id);


--
-- Name: finance_transactions finance_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: households households_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_pkey PRIMARY KEY (id);


--
-- Name: member_audit_log member_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_audit_log
    ADD CONSTRAINT member_audit_log_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: pastoral_cases pastoral_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT pastoral_cases_pkey PRIMARY KEY (id);


--
-- Name: pastoral_visits pastoral_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_visits
    ADD CONSTRAINT pastoral_visits_pkey PRIMARY KEY (id);


--
-- Name: system_permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: prayer_requests prayer_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT prayer_requests_pkey PRIMARY KEY (id);


--
-- Name: push_device_tokens push_device_tokens_member_id_device_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_device_tokens
    ADD CONSTRAINT push_device_tokens_member_id_device_token_key UNIQUE (member_id, device_token);


--
-- Name: push_device_tokens push_device_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_device_tokens
    ADD CONSTRAINT push_device_tokens_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_key);


--
-- Name: service_attendance service_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_attendance
    ADD CONSTRAINT service_attendance_pkey PRIMARY KEY (id);


--
-- Name: service_audit_log service_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_audit_log
    ADD CONSTRAINT service_audit_log_pkey PRIMARY KEY (id);


--
-- Name: service_templates service_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_templates
    ADD CONSTRAINT service_templates_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: storage_signed_url_log storage_signed_url_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_signed_url_log
    ADD CONSTRAINT storage_signed_url_log_pkey PRIMARY KEY (id);


--
-- Name: system_permissions system_permissions_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_permissions
    ADD CONSTRAINT system_permissions_key_unique UNIQUE (key);


--
-- Name: group_members uq_active_membership; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT uq_active_membership UNIQUE (group_id, member_id);


--
-- Name: service_attendance uq_attendance_per_service; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_attendance
    ADD CONSTRAINT uq_attendance_per_service UNIQUE (service_id, member_id);


--
-- Name: finance_budgets uq_budget_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT uq_budget_period UNIQUE (assembly_id, category_id, period, year, month, quarter);


--
-- Name: finance_categories uq_category_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_categories
    ADD CONSTRAINT uq_category_name UNIQUE (assembly_id, name, category_type);


--
-- Name: groups uq_group_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT uq_group_name UNIQUE (assembly_id, name, group_type);


--
-- Name: pastoral_cases uq_open_case; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT uq_open_case UNIQUE (assembly_id, member_id, case_type, status) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: finance_pledges uq_pledge; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_pledges
    ADD CONSTRAINT uq_pledge UNIQUE (assembly_id, member_id, pledge_name);


--
-- Name: prayer_requests uq_prayer_request; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT uq_prayer_request UNIQUE (assembly_id, member_id, title);


--
-- Name: services uq_service_per_day; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT uq_service_per_day UNIQUE (assembly_id, group_id, service_date, service_type);


--
-- Name: service_templates uq_template_assembly_title; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_templates
    ADD CONSTRAINT uq_template_assembly_title UNIQUE (assembly_id, title, recurrence, day_of_week);


--
-- Name: finance_transactions uq_transaction_reference; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT uq_transaction_reference UNIQUE (assembly_id, reference_number) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_06 messages_2026_07_06_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_06
    ADD CONSTRAINT messages_2026_07_06_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_07 messages_2026_07_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_07
    ADD CONSTRAINT messages_2026_07_07_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_08 messages_2026_07_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_08
    ADD CONSTRAINT messages_2026_07_08_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_09 messages_2026_07_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_09
    ADD CONSTRAINT messages_2026_07_09_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_10 messages_2026_07_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_10
    ADD CONSTRAINT messages_2026_07_10_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_11 messages_2026_07_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_11
    ADD CONSTRAINT messages_2026_07_11_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_07_12 messages_2026_07_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_07_12
    ADD CONSTRAINT messages_2026_07_12_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: -
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: idx_assemblies_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assemblies_is_active ON public.assemblies USING btree (is_active);


--
-- Name: idx_att_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_att_active ON public.service_attendance USING btree (service_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_att_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_att_member ON public.service_attendance USING btree (member_id);


--
-- Name: idx_att_service; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_att_service ON public.service_attendance USING btree (service_id);


--
-- Name: idx_att_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_att_status ON public.service_attendance USING btree (member_id, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_audit_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_changed_at ON public.service_audit_log USING btree (changed_at);


--
-- Name: idx_audit_log_assembly_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_assembly_changed_at ON public.member_audit_log USING btree (assembly_id, changed_at DESC);


--
-- Name: idx_audit_log_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_member_id ON public.member_audit_log USING btree (member_id);


--
-- Name: idx_audit_service; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_service ON public.service_audit_log USING btree (service_id);


--
-- Name: idx_comm_attachments_archive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comm_attachments_archive ON public.communication_attachments USING btree (archive_after) WHERE ((archived_at IS NULL) AND (deleted_at IS NULL));


--
-- Name: idx_comm_attachments_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comm_attachments_tier ON public.communication_attachments USING btree (storage_tier, storage_provider);


--
-- Name: idx_comm_messages_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comm_messages_campaign ON public.communication_messages USING btree (campaign_id);


--
-- Name: idx_comm_messages_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comm_messages_member ON public.communication_messages USING btree (member_id);


--
-- Name: idx_comm_messages_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comm_messages_status ON public.communication_messages USING btree (status);


--
-- Name: idx_fbg_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fbg_assembly ON public.finance_budgets USING btree (assembly_id);


--
-- Name: idx_fbg_category_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fbg_category_period ON public.finance_budgets USING btree (assembly_id, category_id, year) WHERE (deleted_at IS NULL);


--
-- Name: idx_fcat_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fcat_active ON public.finance_categories USING btree (assembly_id, category_type) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_fcat_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fcat_assembly ON public.finance_categories USING btree (assembly_id);


--
-- Name: idx_fpl_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fpl_active ON public.finance_pledges USING btree (assembly_id, status) WHERE ((status = 'active'::public.finance_pledge_status) AND (deleted_at IS NULL));


--
-- Name: idx_fpl_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fpl_assembly ON public.finance_pledges USING btree (assembly_id);


--
-- Name: idx_fpl_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fpl_member ON public.finance_pledges USING btree (member_id);


--
-- Name: idx_ftx_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftx_assembly ON public.finance_transactions USING btree (assembly_id);


--
-- Name: idx_ftx_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftx_category ON public.finance_transactions USING btree (category_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_ftx_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftx_date ON public.finance_transactions USING btree (assembly_id, transaction_date) WHERE (deleted_at IS NULL);


--
-- Name: idx_ftx_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftx_member ON public.finance_transactions USING btree (member_id) WHERE ((member_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_ftx_pledge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftx_pledge ON public.finance_transactions USING btree (pledge_id) WHERE (pledge_id IS NOT NULL);


--
-- Name: idx_ftx_service; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftx_service ON public.finance_transactions USING btree (service_id) WHERE (service_id IS NOT NULL);


--
-- Name: idx_gm_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gm_active ON public.group_members USING btree (group_id, is_active) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_gm_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gm_group ON public.group_members USING btree (group_id);


--
-- Name: idx_gm_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gm_member ON public.group_members USING btree (member_id);


--
-- Name: idx_gm_member_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gm_member_active ON public.group_members USING btree (member_id) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_groups_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_groups_active ON public.groups USING btree (assembly_id, group_type) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_groups_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_groups_assembly ON public.groups USING btree (assembly_id);


--
-- Name: idx_households_assembly_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_households_assembly_id ON public.households USING btree (assembly_id);


--
-- Name: idx_households_primary_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_households_primary_contact_id ON public.households USING btree (primary_contact_id) WHERE (primary_contact_id IS NOT NULL);


--
-- Name: idx_members_assembly_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_assembly_id ON public.members USING btree (assembly_id);


--
-- Name: idx_members_auth_user_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_members_auth_user_id_unique ON public.members USING btree (auth_user_id) WHERE (auth_user_id IS NOT NULL);


--
-- Name: idx_members_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_created_at ON public.members USING btree (assembly_id, created_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_members_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_deleted_at ON public.members USING btree (assembly_id, deleted_at DESC) WHERE (deleted_at IS NOT NULL);


--
-- Name: idx_members_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_members_email_unique ON public.members USING btree (assembly_id, email) WHERE ((email IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_members_fulltext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_fulltext ON public.members USING gin (to_tsvector('english'::regconfig, ((first_name || ' '::text) || last_name)));


--
-- Name: idx_members_household_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_household_id ON public.members USING btree (household_id) WHERE ((household_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_members_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_is_active ON public.members USING btree (assembly_id, is_active) WHERE (deleted_at IS NULL);


--
-- Name: idx_members_last_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_last_name ON public.members USING btree (last_name) WHERE (deleted_at IS NULL);


--
-- Name: idx_members_membership_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_members_membership_number_unique ON public.members USING btree (membership_number) WHERE ((membership_number IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_members_membership_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_membership_status ON public.members USING btree (assembly_id, membership_status) WHERE (deleted_at IS NULL);


--
-- Name: idx_members_phone_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_members_phone_unique ON public.members USING btree (assembly_id, primary_phone) WHERE ((primary_phone IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_pc_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pc_assembly ON public.pastoral_cases USING btree (assembly_id);


--
-- Name: idx_pc_assigned_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pc_assigned_status ON public.pastoral_cases USING btree (assigned_to, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_pc_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pc_member ON public.pastoral_cases USING btree (member_id);


--
-- Name: idx_pc_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pc_priority ON public.pastoral_cases USING btree (assembly_id, priority) WHERE ((status <> 'closed'::public.pastoral_case_status) AND (deleted_at IS NULL));


--
-- Name: idx_pr_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pr_active ON public.prayer_requests USING btree (assembly_id, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_pr_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pr_assembly ON public.prayer_requests USING btree (assembly_id);


--
-- Name: idx_pr_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pr_member ON public.prayer_requests USING btree (member_id) WHERE (member_id IS NOT NULL);


--
-- Name: idx_push_tokens_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_push_tokens_member ON public.push_device_tokens USING btree (member_id) WHERE (is_active = true);


--
-- Name: idx_pv_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pv_case ON public.pastoral_visits USING btree (case_id);


--
-- Name: idx_pv_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pv_member ON public.pastoral_visits USING btree (member_id);


--
-- Name: idx_pv_next_visit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pv_next_visit ON public.pastoral_visits USING btree (next_visit_date) WHERE ((next_visit_date IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_pv_visited_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pv_visited_by ON public.pastoral_visits USING btree (visited_by);


--
-- Name: idx_svc_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_svc_active ON public.services USING btree (assembly_id, service_date) WHERE (deleted_at IS NULL);


--
-- Name: idx_svc_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_svc_assembly ON public.services USING btree (assembly_id);


--
-- Name: idx_svc_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_svc_date ON public.services USING btree (service_date);


--
-- Name: idx_svc_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_svc_group ON public.services USING btree (group_id) WHERE (group_id IS NOT NULL);


--
-- Name: idx_svc_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_svc_status ON public.services USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: idx_svc_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_svc_template ON public.services USING btree (template_id) WHERE (template_id IS NOT NULL);


--
-- Name: idx_thread_messages_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_thread_messages_thread ON public.communication_thread_messages USING btree (thread_id, created_at);


--
-- Name: idx_tmpl_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tmpl_active ON public.service_templates USING btree (assembly_id, is_active) WHERE (deleted_at IS NULL);


--
-- Name: idx_tmpl_assembly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tmpl_assembly ON public.service_templates USING btree (assembly_id);


--
-- Name: idx_tmpl_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tmpl_group ON public.service_templates USING btree (group_id) WHERE (group_id IS NOT NULL);


--
-- Name: idx_user_profiles_assembly_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_profiles_assembly_id ON public.user_profiles USING btree (assembly_id);


--
-- Name: idx_user_profiles_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_profiles_is_active ON public.user_profiles USING btree (is_active);


--
-- Name: idx_webhook_events_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhook_events_msg ON public.webhook_events USING btree (message_id);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_06_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_06_inserted_at_topic_idx ON realtime.messages_2026_07_06 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_07_inserted_at_topic_idx ON realtime.messages_2026_07_07 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_08_inserted_at_topic_idx ON realtime.messages_2026_07_08 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_09_inserted_at_topic_idx ON realtime.messages_2026_07_09 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_10_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_10_inserted_at_topic_idx ON realtime.messages_2026_07_10 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_11_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_11_inserted_at_topic_idx ON realtime.messages_2026_07_11 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_07_12_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_07_12_inserted_at_topic_idx ON realtime.messages_2026_07_12 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: messages_2026_07_06_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_06_inserted_at_topic_idx;


--
-- Name: messages_2026_07_06_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_06_pkey;


--
-- Name: messages_2026_07_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_07_inserted_at_topic_idx;


--
-- Name: messages_2026_07_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_07_pkey;


--
-- Name: messages_2026_07_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_08_inserted_at_topic_idx;


--
-- Name: messages_2026_07_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_08_pkey;


--
-- Name: messages_2026_07_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_09_inserted_at_topic_idx;


--
-- Name: messages_2026_07_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_09_pkey;


--
-- Name: messages_2026_07_10_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_10_inserted_at_topic_idx;


--
-- Name: messages_2026_07_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_10_pkey;


--
-- Name: messages_2026_07_11_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_11_inserted_at_topic_idx;


--
-- Name: messages_2026_07_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_11_pkey;


--
-- Name: messages_2026_07_12_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_07_12_inserted_at_topic_idx;


--
-- Name: messages_2026_07_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_07_12_pkey;


--
-- Name: user_profiles sync_permissions_on_profile_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sync_permissions_on_profile_update AFTER UPDATE OF assembly_role_id, assembly_id ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.sync_user_permissions_to_jwt();


--
-- Name: assemblies trg_assemblies_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_assemblies_set_updated_at BEFORE UPDATE ON public.assemblies FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: members trg_enforce_member_update_columns; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_enforce_member_update_columns BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.enforce_member_update_columns();


--
-- Name: households trg_households_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_households_set_updated_at BEFORE UPDATE ON public.households FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: households trg_link_household_primary_contact; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_link_household_primary_contact AFTER INSERT OR UPDATE OF primary_contact_id ON public.households FOR EACH ROW EXECUTE FUNCTION public.link_household_primary_contact();


--
-- Name: members trg_members_audit_log; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_members_audit_log AFTER UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.write_member_audit_log();


--
-- Name: members trg_members_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_members_set_updated_at BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: services trg_service_audit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_service_audit AFTER UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.log_service_changes();


--
-- Name: user_profiles trg_user_profiles_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_user_profiles_set_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: announcement_posts announcement_posts_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_posts
    ADD CONSTRAINT announcement_posts_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: announcement_posts announcement_posts_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_posts
    ADD CONSTRAINT announcement_posts_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.user_profiles(id);


--
-- Name: announcement_posts announcement_posts_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_posts
    ADD CONSTRAINT announcement_posts_posted_by_fkey FOREIGN KEY (posted_by) REFERENCES public.user_profiles(id);


--
-- Name: assembly_roles assembly_roles_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assembly_roles
    ADD CONSTRAINT assembly_roles_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id) ON DELETE CASCADE;


--
-- Name: assembly_storage_usage assembly_storage_usage_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assembly_storage_usage
    ADD CONSTRAINT assembly_storage_usage_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_attachments communication_attachments_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_attachments
    ADD CONSTRAINT communication_attachments_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_attachments communication_attachments_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_attachments
    ADD CONSTRAINT communication_attachments_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.communication_campaigns(id);


--
-- Name: communication_attachments communication_attachments_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_attachments
    ADD CONSTRAINT communication_attachments_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_attachments communication_attachments_thread_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_attachments
    ADD CONSTRAINT communication_attachments_thread_message_id_fkey FOREIGN KEY (thread_message_id) REFERENCES public.communication_thread_messages(id);


--
-- Name: communication_attachments communication_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_attachments
    ADD CONSTRAINT communication_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_campaigns communication_campaigns_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_campaigns
    ADD CONSTRAINT communication_campaigns_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_campaigns communication_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_campaigns
    ADD CONSTRAINT communication_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_campaigns communication_campaigns_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_campaigns
    ADD CONSTRAINT communication_campaigns_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_campaigns communication_campaigns_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_campaigns
    ADD CONSTRAINT communication_campaigns_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.communication_templates(id);


--
-- Name: communication_messages communication_messages_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT communication_messages_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_messages communication_messages_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT communication_messages_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.communication_campaigns(id);


--
-- Name: communication_messages communication_messages_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT communication_messages_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: communication_preferences communication_preferences_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_preferences
    ADD CONSTRAINT communication_preferences_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_preferences communication_preferences_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_preferences
    ADD CONSTRAINT communication_preferences_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: communication_templates communication_templates_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_templates communication_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_templates communication_templates_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_thread_messages communication_thread_messages_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_messages
    ADD CONSTRAINT communication_thread_messages_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_thread_messages communication_thread_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_messages
    ADD CONSTRAINT communication_thread_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.members(id);


--
-- Name: communication_thread_messages communication_thread_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_messages
    ADD CONSTRAINT communication_thread_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.communication_threads(id);


--
-- Name: communication_thread_participants communication_thread_participants_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_participants
    ADD CONSTRAINT communication_thread_participants_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: communication_thread_participants communication_thread_participants_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_thread_participants
    ADD CONSTRAINT communication_thread_participants_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.communication_threads(id);


--
-- Name: communication_threads communication_threads_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_threads
    ADD CONSTRAINT communication_threads_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_threads communication_threads_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_threads
    ADD CONSTRAINT communication_threads_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_threads communication_threads_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_threads
    ADD CONSTRAINT communication_threads_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_trigger_rules communication_trigger_rules_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_trigger_rules
    ADD CONSTRAINT communication_trigger_rules_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: communication_trigger_rules communication_trigger_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_trigger_rules
    ADD CONSTRAINT communication_trigger_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.user_profiles(id);


--
-- Name: communication_trigger_rules communication_trigger_rules_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_trigger_rules
    ADD CONSTRAINT communication_trigger_rules_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.communication_templates(id);


--
-- Name: finance_budgets finance_budgets_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: finance_budgets finance_budgets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.finance_categories(id);


--
-- Name: finance_budgets finance_budgets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: finance_budgets finance_budgets_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_budgets
    ADD CONSTRAINT finance_budgets_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: finance_categories finance_categories_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_categories
    ADD CONSTRAINT finance_categories_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: finance_categories finance_categories_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_categories
    ADD CONSTRAINT finance_categories_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: finance_categories finance_categories_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_categories
    ADD CONSTRAINT finance_categories_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: finance_pledges finance_pledges_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_pledges
    ADD CONSTRAINT finance_pledges_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: finance_pledges finance_pledges_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_pledges
    ADD CONSTRAINT finance_pledges_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: finance_pledges finance_pledges_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_pledges
    ADD CONSTRAINT finance_pledges_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: finance_pledges finance_pledges_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_pledges
    ADD CONSTRAINT finance_pledges_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: finance_transactions finance_transactions_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: finance_transactions finance_transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.finance_categories(id);


--
-- Name: finance_transactions finance_transactions_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: finance_transactions finance_transactions_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: finance_transactions finance_transactions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: finance_transactions finance_transactions_pledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_pledge_id_fkey FOREIGN KEY (pledge_id) REFERENCES public.finance_pledges(id);


--
-- Name: finance_transactions finance_transactions_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES auth.users(id);


--
-- Name: finance_transactions finance_transactions_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_transactions
    ADD CONSTRAINT finance_transactions_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: households fk_households_primary_contact; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT fk_households_primary_contact FOREIGN KEY (primary_contact_id) REFERENCES public.members(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_members group_members_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: group_members group_members_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_members group_members_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: groups groups_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: groups groups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: groups groups_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: groups groups_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_leader_id_fkey FOREIGN KEY (leader_id) REFERENCES public.members(id);


--
-- Name: households households_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: member_audit_log member_audit_log_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_audit_log
    ADD CONSTRAINT member_audit_log_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: member_audit_log member_audit_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_audit_log
    ADD CONSTRAINT member_audit_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: member_audit_log member_audit_log_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_audit_log
    ADD CONSTRAINT member_audit_log_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: members members_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: members members_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: members members_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: members members_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE SET NULL;


--
-- Name: pastoral_cases pastoral_cases_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT pastoral_cases_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: pastoral_cases pastoral_cases_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT pastoral_cases_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES auth.users(id);


--
-- Name: pastoral_cases pastoral_cases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT pastoral_cases_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: pastoral_cases pastoral_cases_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT pastoral_cases_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: pastoral_cases pastoral_cases_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_cases
    ADD CONSTRAINT pastoral_cases_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: pastoral_visits pastoral_visits_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_visits
    ADD CONSTRAINT pastoral_visits_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.pastoral_cases(id);


--
-- Name: pastoral_visits pastoral_visits_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_visits
    ADD CONSTRAINT pastoral_visits_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: pastoral_visits pastoral_visits_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_visits
    ADD CONSTRAINT pastoral_visits_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: pastoral_visits pastoral_visits_visited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pastoral_visits
    ADD CONSTRAINT pastoral_visits_visited_by_fkey FOREIGN KEY (visited_by) REFERENCES auth.users(id);


--
-- Name: prayer_requests prayer_requests_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT prayer_requests_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: prayer_requests prayer_requests_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT prayer_requests_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: prayer_requests prayer_requests_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT prayer_requests_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: push_device_tokens push_device_tokens_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_device_tokens
    ADD CONSTRAINT push_device_tokens_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: push_device_tokens push_device_tokens_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_device_tokens
    ADD CONSTRAINT push_device_tokens_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: role_permissions role_permissions_permission_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_key_fkey FOREIGN KEY (permission_key) REFERENCES public.system_permissions(key) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.assembly_roles(id) ON DELETE CASCADE;


--
-- Name: service_attendance service_attendance_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_attendance
    ADD CONSTRAINT service_attendance_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: service_attendance service_attendance_marked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_attendance
    ADD CONSTRAINT service_attendance_marked_by_fkey FOREIGN KEY (marked_by) REFERENCES auth.users(id);


--
-- Name: service_attendance service_attendance_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_attendance
    ADD CONSTRAINT service_attendance_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: service_attendance service_attendance_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_attendance
    ADD CONSTRAINT service_attendance_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: service_audit_log service_audit_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_audit_log
    ADD CONSTRAINT service_audit_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES auth.users(id);


--
-- Name: service_audit_log service_audit_log_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_audit_log
    ADD CONSTRAINT service_audit_log_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: service_templates service_templates_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_templates
    ADD CONSTRAINT service_templates_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: service_templates service_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_templates
    ADD CONSTRAINT service_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: service_templates service_templates_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_templates
    ADD CONSTRAINT service_templates_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: service_templates service_templates_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_templates
    ADD CONSTRAINT service_templates_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: services services_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: services services_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: services services_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES auth.users(id);


--
-- Name: services services_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: services services_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.service_templates(id);


--
-- Name: storage_signed_url_log storage_signed_url_log_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_signed_url_log
    ADD CONSTRAINT storage_signed_url_log_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.communication_attachments(id);


--
-- Name: storage_signed_url_log storage_signed_url_log_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_signed_url_log
    ADD CONSTRAINT storage_signed_url_log_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.user_profiles(id);


--
-- Name: user_profiles user_profiles_assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_assembly_id_fkey FOREIGN KEY (assembly_id) REFERENCES public.assemblies(id);


--
-- Name: user_profiles user_profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_role_id_fkey FOREIGN KEY (assembly_role_id) REFERENCES public.assembly_roles(id) ON DELETE SET NULL;


--
-- Name: webhook_events webhook_events_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.communication_messages(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: announcement_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.announcement_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: announcement_posts announcements: managers insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "announcements: managers insert" ON public.announcement_posts FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.announcements.manage'::text))));


--
-- Name: announcement_posts announcements: managers update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "announcements: managers update" ON public.announcement_posts FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (public.is_admin() OR public.auth_has_permission('communications.announcements.manage'::text))));


--
-- Name: announcement_posts announcements: members read active; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "announcements: members read active" ON public.announcement_posts FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (visible_from <= now()) AND ((visible_until IS NULL) OR (visible_until > now())) AND ((target_group_ids = '{}'::uuid[]) OR (EXISTS ( SELECT 1
   FROM public.group_members gm
  WHERE ((gm.member_id = public.auth_member_id()) AND (gm.group_id = ANY (announcement_posts.target_group_ids)) AND (gm.is_active = true)))))));


--
-- Name: assemblies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assemblies ENABLE ROW LEVEL SECURITY;

--
-- Name: assemblies assemblies_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY assemblies_select_own ON public.assemblies FOR SELECT TO authenticated USING ((id = public.get_user_assembly_id()));


--
-- Name: assemblies assemblies_select_public; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY assemblies_select_public ON public.assemblies FOR SELECT TO anon USING ((is_active = true));


--
-- Name: assembly_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assembly_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: assembly_roles assembly_roles_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY assembly_roles_delete ON public.assembly_roles FOR DELETE TO authenticated USING (((assembly_id = public.get_user_assembly_id()) AND public.is_admin()));


--
-- Name: assembly_roles assembly_roles_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY assembly_roles_insert ON public.assembly_roles FOR INSERT TO authenticated WITH CHECK (((assembly_id = public.get_user_assembly_id()) AND public.is_admin()));


--
-- Name: assembly_roles assembly_roles_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY assembly_roles_select ON public.assembly_roles FOR SELECT TO authenticated USING ((assembly_id = public.get_user_assembly_id()));


--
-- Name: assembly_roles assembly_roles_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY assembly_roles_update ON public.assembly_roles FOR UPDATE TO authenticated USING (((assembly_id = public.get_user_assembly_id()) AND public.is_admin()));


--
-- Name: assembly_storage_usage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assembly_storage_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: service_attendance att: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "att: insert own assembly" ON public.service_attendance FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.services s
  WHERE ((s.id = service_attendance.service_id) AND (s.assembly_id = public.auth_assembly_id())))));


--
-- Name: service_attendance att: read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "att: read own assembly" ON public.service_attendance FOR SELECT USING (((EXISTS ( SELECT 1
   FROM public.services s
  WHERE ((s.id = service_attendance.service_id) AND (s.assembly_id = public.auth_assembly_id()) AND (s.deleted_at IS NULL)))) AND (deleted_at IS NULL)));


--
-- Name: service_attendance att: update own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "att: update own assembly" ON public.service_attendance FOR UPDATE USING (((EXISTS ( SELECT 1
   FROM public.services s
  WHERE ((s.id = service_attendance.service_id) AND (s.assembly_id = public.auth_assembly_id())))) AND (deleted_at IS NULL)));


--
-- Name: communication_attachments attachments: assembly scoped read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "attachments: assembly scoped read" ON public.communication_attachments FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND ((is_sensitive = false) OR public.auth_has_permission('communications.attachments.view_pastoral'::text))));


--
-- Name: communication_attachments attachments: members upload non-audio; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "attachments: members upload non-audio" ON public.communication_attachments FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (mime_type !~~ 'audio/%'::text) AND (is_sensitive = false) AND (uploaded_by = auth.uid())));


--
-- Name: communication_attachments attachments: pastor upload audio; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "attachments: pastor upload audio" ON public.communication_attachments FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (mime_type ~~ 'audio/%'::text) AND public.auth_has_permission('communications.audio.broadcast'::text) AND (uploaded_by = auth.uid())));


--
-- Name: communication_attachments attachments: uploader or admin soft delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "attachments: uploader or admin soft delete" ON public.communication_attachments FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND ((uploaded_by = auth.uid()) OR public.auth_has_permission('communications.attachments.manage'::text))));


--
-- Name: service_audit_log audit: insert only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "audit: insert only" ON public.service_audit_log FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.services s
  WHERE ((s.id = service_audit_log.service_id) AND (s.assembly_id = public.auth_assembly_id())))));


--
-- Name: service_audit_log audit: read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "audit: read own assembly" ON public.service_audit_log FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.services s
  WHERE ((s.id = service_audit_log.service_id) AND (s.assembly_id = public.auth_assembly_id())))));


--
-- Name: member_audit_log audit_log_select_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_log_select_admin ON public.member_audit_log FOR SELECT TO authenticated USING ((public.is_admin() AND (assembly_id = public.get_user_assembly_id())));


--
-- Name: communication_campaigns campaigns: members read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "campaigns: members read own assembly" ON public.communication_campaigns FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: communication_campaigns campaigns: senders insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "campaigns: senders insert" ON public.communication_campaigns FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.broadcast.send'::text))));


--
-- Name: communication_campaigns campaigns: senders update own or admin any; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "campaigns: senders update own or admin any" ON public.communication_campaigns FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (public.is_admin() OR (created_by = auth.uid()) OR public.auth_has_permission('communications.broadcast.schedule'::text))));


--
-- Name: communication_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_campaigns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_campaigns ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_thread_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_thread_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_thread_participants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_thread_participants ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_threads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_threads ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_trigger_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.communication_trigger_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: finance_budgets fbg: insert with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fbg: insert with finance.manage" ON public.finance_budgets FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_budgets fbg: read with finance.view; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fbg: read with finance.view" ON public.finance_budgets FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (public.is_admin() OR public.has_finance_permission('finance.view'::text))));


--
-- Name: finance_budgets fbg: update with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fbg: update with finance.manage" ON public.finance_budgets FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_categories fcat: read with finance.view; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fcat: read with finance.view" ON public.finance_categories FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (public.is_admin() OR public.has_finance_permission('finance.view'::text))));


--
-- Name: finance_categories fcat: update with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fcat: update with finance.manage" ON public.finance_categories FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_categories fcat: write with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fcat: write with finance.manage" ON public.finance_categories FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_budgets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.finance_budgets ENABLE ROW LEVEL SECURITY;

--
-- Name: finance_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.finance_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: finance_pledges; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.finance_pledges ENABLE ROW LEVEL SECURITY;

--
-- Name: finance_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.finance_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: finance_pledges fpl: insert with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fpl: insert with finance.manage" ON public.finance_pledges FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_pledges fpl: read with finance.view; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fpl: read with finance.view" ON public.finance_pledges FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (public.is_admin() OR public.has_finance_permission('finance.view'::text))));


--
-- Name: finance_pledges fpl: update with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "fpl: update with finance.manage" ON public.finance_pledges FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_transactions ftx: insert with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ftx: insert with finance.manage" ON public.finance_transactions FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: finance_transactions ftx: read with finance.view; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ftx: read with finance.view" ON public.finance_transactions FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND (public.is_admin() OR public.has_finance_permission('finance.view'::text))));


--
-- Name: finance_transactions ftx: update with finance.manage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ftx: update with finance.manage" ON public.finance_transactions FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.has_finance_permission('finance.manage'::text)));


--
-- Name: group_members gm: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "gm: insert own assembly" ON public.group_members FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.groups g
  WHERE ((g.id = group_members.group_id) AND (g.assembly_id = public.auth_assembly_id())))));


--
-- Name: group_members gm: members read own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "gm: members read own" ON public.group_members FOR SELECT USING ((member_id IN ( SELECT members.id
   FROM public.members
  WHERE (members.assembly_id = public.auth_assembly_id()))));


--
-- Name: group_members gm: read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "gm: read own assembly" ON public.group_members FOR SELECT USING (((EXISTS ( SELECT 1
   FROM public.groups g
  WHERE ((g.id = group_members.group_id) AND (g.assembly_id = public.auth_assembly_id()) AND (g.deleted_at IS NULL)))) AND (deleted_at IS NULL)));


--
-- Name: group_members gm: update own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "gm: update own assembly" ON public.group_members FOR UPDATE USING (((EXISTS ( SELECT 1
   FROM public.groups g
  WHERE ((g.id = group_members.group_id) AND (g.assembly_id = public.auth_assembly_id())))) AND (deleted_at IS NULL)));


--
-- Name: group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;

--
-- Name: groups groups: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "groups: insert own assembly" ON public.groups FOR INSERT WITH CHECK ((assembly_id = public.auth_assembly_id()));


--
-- Name: groups groups: read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "groups: read own assembly" ON public.groups FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: groups groups: update own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "groups: update own assembly" ON public.groups FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: households; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.households ENABLE ROW LEVEL SECURITY;

--
-- Name: households households_delete_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY households_delete_admin ON public.households FOR DELETE TO authenticated USING ((public.is_admin() AND (assembly_id = public.get_user_assembly_id())));


--
-- Name: member_audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.member_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;

--
-- Name: members members_insert_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY members_insert_admin ON public.members FOR INSERT TO authenticated WITH CHECK ((public.is_admin() AND (assembly_id = public.get_user_assembly_id())));


--
-- Name: members members_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY members_select ON public.members FOR SELECT TO authenticated USING (((public.is_admin() AND (assembly_id = public.get_user_assembly_id())) OR ((assembly_id = public.get_user_assembly_id()) AND (is_active = true)) OR (auth_user_id = ( SELECT auth.uid() AS uid))));


--
-- Name: members members_update_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY members_update_admin ON public.members FOR UPDATE TO authenticated USING ((public.is_admin() AND (assembly_id = public.get_user_assembly_id()) AND (is_active = true))) WITH CHECK ((public.is_admin() AND (assembly_id = public.get_user_assembly_id())));


--
-- Name: communication_messages messages: members read own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "messages: members read own" ON public.communication_messages FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (member_id = public.auth_member_id()) AND (deleted_at IS NULL)));


--
-- Name: communication_messages messages: reporters read assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "messages: reporters read assembly" ON public.communication_messages FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND public.auth_has_permission('communications.reports.view'::text) AND (deleted_at IS NULL)));


--
-- Name: pastoral_cases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pastoral_cases ENABLE ROW LEVEL SECURITY;

--
-- Name: pastoral_visits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pastoral_visits ENABLE ROW LEVEL SECURITY;

--
-- Name: pastoral_cases pc: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pc: insert own assembly" ON public.pastoral_cases FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.has_pastoral_permission('pastoral.manage'::text)));


--
-- Name: pastoral_cases pc: read assigned or admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pc: read assigned or admin" ON public.pastoral_cases FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND ((assigned_to = auth.uid()) OR (created_by = auth.uid()) OR (is_private = false) OR (EXISTS ( SELECT 1
   FROM public.user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.assembly_id = public.auth_assembly_id()) AND (user_profiles.role = 'admin'::text))))) AND public.has_pastoral_permission('pastoral.view'::text)));


--
-- Name: pastoral_cases pc: update assigned or admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pc: update assigned or admin" ON public.pastoral_cases FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND ((assigned_to = auth.uid()) OR (created_by = auth.uid()) OR (EXISTS ( SELECT 1
   FROM public.user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.assembly_id = public.auth_assembly_id()) AND (user_profiles.role = 'admin'::text))))) AND public.has_pastoral_permission('pastoral.manage'::text)));


--
-- Name: prayer_requests pr: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pr: insert own assembly" ON public.prayer_requests FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.has_pastoral_permission('pastoral.manage'::text)));


--
-- Name: prayer_requests pr: read own assembly staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pr: read own assembly staff" ON public.prayer_requests FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.has_pastoral_permission('pastoral.view'::text)));


--
-- Name: prayer_requests pr: update own or admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pr: update own or admin" ON public.prayer_requests FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.has_pastoral_permission('pastoral.manage'::text) AND ((member_id = ( SELECT m.id
   FROM public.members m
  WHERE ((m.auth_user_id = auth.uid()) AND (m.assembly_id = public.auth_assembly_id()))
 LIMIT 1)) OR (EXISTS ( SELECT 1
   FROM public.user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.assembly_id = public.auth_assembly_id()) AND (user_profiles.role = 'admin'::text)))))));


--
-- Name: prayer_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.prayer_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: communication_preferences preferences: members insert own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "preferences: members insert own" ON public.communication_preferences FOR INSERT WITH CHECK (((member_id = public.auth_member_id()) AND (assembly_id = public.auth_assembly_id())));


--
-- Name: communication_preferences preferences: members read own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "preferences: members read own" ON public.communication_preferences FOR SELECT USING ((member_id = public.auth_member_id()));


--
-- Name: communication_preferences preferences: members update own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "preferences: members update own" ON public.communication_preferences FOR UPDATE USING ((member_id = public.auth_member_id())) WITH CHECK ((member_id = public.auth_member_id()));


--
-- Name: push_device_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.push_device_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: push_device_tokens push_tokens: members delete own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "push_tokens: members delete own" ON public.push_device_tokens FOR DELETE USING ((member_id = public.auth_member_id()));


--
-- Name: push_device_tokens push_tokens: members insert own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "push_tokens: members insert own" ON public.push_device_tokens FOR INSERT WITH CHECK (((member_id = public.auth_member_id()) AND (assembly_id = public.auth_assembly_id())));


--
-- Name: push_device_tokens push_tokens: members read own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "push_tokens: members read own" ON public.push_device_tokens FOR SELECT USING ((member_id = public.auth_member_id()));


--
-- Name: push_device_tokens push_tokens: members update own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "push_tokens: members update own" ON public.push_device_tokens FOR UPDATE USING ((member_id = public.auth_member_id())) WITH CHECK ((member_id = public.auth_member_id()));


--
-- Name: pastoral_visits pv: insert via case access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pv: insert via case access" ON public.pastoral_visits FOR INSERT WITH CHECK ((public.has_pastoral_permission('pastoral.manage'::text) AND (EXISTS ( SELECT 1
   FROM public.pastoral_cases pc
  WHERE ((pc.id = pastoral_visits.case_id) AND (pc.assembly_id = public.auth_assembly_id()) AND ((pc.assigned_to = auth.uid()) OR (pc.created_by = auth.uid())))))));


--
-- Name: pastoral_visits pv: read via case access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pv: read via case access" ON public.pastoral_visits FOR SELECT USING (((deleted_at IS NULL) AND public.has_pastoral_permission('pastoral.view'::text) AND (EXISTS ( SELECT 1
   FROM public.pastoral_cases pc
  WHERE ((pc.id = pastoral_visits.case_id) AND (pc.assembly_id = public.auth_assembly_id()) AND (pc.deleted_at IS NULL) AND ((pc.assigned_to = auth.uid()) OR (pc.created_by = auth.uid()) OR (pc.is_private = false) OR (EXISTS ( SELECT 1
           FROM public.user_profiles
          WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.assembly_id = public.auth_assembly_id()) AND (user_profiles.role = 'admin'::text))))))))));


--
-- Name: pastoral_visits pv: update own visits; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "pv: update own visits" ON public.pastoral_visits FOR UPDATE USING (((visited_by = auth.uid()) AND (deleted_at IS NULL) AND public.has_pastoral_permission('pastoral.manage'::text)));


--
-- Name: role_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: role_permissions role_permissions_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY role_permissions_delete ON public.role_permissions FOR DELETE TO authenticated USING ((public.is_admin() AND (EXISTS ( SELECT 1
   FROM public.assembly_roles ar
  WHERE ((ar.id = role_permissions.role_id) AND (ar.assembly_id = public.get_user_assembly_id()))))));


--
-- Name: role_permissions role_permissions_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY role_permissions_insert ON public.role_permissions FOR INSERT TO authenticated WITH CHECK ((public.is_admin() AND (EXISTS ( SELECT 1
   FROM public.assembly_roles ar
  WHERE ((ar.id = role_permissions.role_id) AND (ar.assembly_id = public.get_user_assembly_id()))))));


--
-- Name: role_permissions role_permissions_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY role_permissions_select ON public.role_permissions FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.assembly_roles ar
  WHERE ((ar.id = role_permissions.role_id) AND (ar.assembly_id = public.get_user_assembly_id())))));


--
-- Name: service_attendance; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.service_attendance ENABLE ROW LEVEL SECURITY;

--
-- Name: service_audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.service_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: service_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.service_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: services; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

--
-- Name: storage_signed_url_log signed_url_log: admins read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "signed_url_log: admins read" ON public.storage_signed_url_log FOR SELECT USING ((public.auth_has_permission('communications.reports.view'::text) AND (EXISTS ( SELECT 1
   FROM public.communication_attachments ca
  WHERE ((ca.id = storage_signed_url_log.attachment_id) AND (ca.assembly_id = public.auth_assembly_id()))))));


--
-- Name: storage_signed_url_log signed_url_log: members read own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "signed_url_log: members read own" ON public.storage_signed_url_log FOR SELECT USING ((requested_by = auth.uid()));


--
-- Name: storage_signed_url_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.storage_signed_url_log ENABLE ROW LEVEL SECURITY;

--
-- Name: assembly_storage_usage storage_usage: admins read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "storage_usage: admins read" ON public.assembly_storage_usage FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND public.auth_has_permission('communications.reports.view'::text)));


--
-- Name: services svc: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "svc: insert own assembly" ON public.services FOR INSERT WITH CHECK ((assembly_id = public.auth_assembly_id()));


--
-- Name: services svc: read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "svc: read own assembly" ON public.services FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: services svc: update own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "svc: update own assembly" ON public.services FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: system_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.system_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: system_permissions system_permissions_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY system_permissions_select_authenticated ON public.system_permissions FOR SELECT TO authenticated USING (true);


--
-- Name: communication_templates templates: managers insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "templates: managers insert" ON public.communication_templates FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.templates.manage'::text))));


--
-- Name: communication_templates templates: managers soft delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "templates: managers soft delete" ON public.communication_templates FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.templates.manage'::text))));


--
-- Name: communication_templates templates: managers update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "templates: managers update" ON public.communication_templates FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.templates.manage'::text))));


--
-- Name: communication_templates templates: members read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "templates: members read own assembly" ON public.communication_templates FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (is_active = true) AND (deleted_at IS NULL)));


--
-- Name: communication_thread_messages thread_messages: admin soft delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_messages: admin soft delete" ON public.communication_thread_messages FOR UPDATE USING ((public.auth_has_permission('communications.direct.moderate'::text) AND (EXISTS ( SELECT 1
   FROM public.communication_threads ct
  WHERE ((ct.id = communication_thread_messages.thread_id) AND (ct.assembly_id = public.auth_assembly_id()))))));


--
-- Name: communication_thread_messages thread_messages: participants insert text; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_messages: participants insert text" ON public.communication_thread_messages FOR INSERT WITH CHECK (((message_type = 'text'::text) AND (sender_id = public.auth_member_id()) AND (EXISTS ( SELECT 1
   FROM public.communication_thread_participants ctp
  WHERE ((ctp.thread_id = ctp.thread_id) AND (ctp.member_id = public.auth_member_id()) AND (ctp.left_at IS NULL))))));


--
-- Name: communication_thread_messages thread_messages: participants read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_messages: participants read" ON public.communication_thread_messages FOR SELECT USING (((deleted_at IS NULL) AND (EXISTS ( SELECT 1
   FROM public.communication_thread_participants ctp
  WHERE ((ctp.thread_id = ctp.thread_id) AND (ctp.member_id = public.auth_member_id()) AND (ctp.left_at IS NULL))))));


--
-- Name: communication_thread_messages thread_messages: pastor insert audio; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_messages: pastor insert audio" ON public.communication_thread_messages FOR INSERT WITH CHECK (((message_type = 'audio'::text) AND (sender_id = public.auth_member_id()) AND public.auth_has_permission('communications.audio.broadcast'::text) AND (EXISTS ( SELECT 1
   FROM public.communication_thread_participants ctp
  WHERE ((ctp.thread_id = ctp.thread_id) AND (ctp.member_id = public.auth_member_id()) AND (ctp.left_at IS NULL))))));


--
-- Name: communication_thread_messages thread_messages: sender soft delete within 24h; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_messages: sender soft delete within 24h" ON public.communication_thread_messages FOR UPDATE USING (((sender_id = public.auth_member_id()) AND (created_at > (now() - '24:00:00'::interval)) AND (deleted_at IS NULL))) WITH CHECK (((deleted_at IS NOT NULL) AND (deleted_by = auth.uid())));


--
-- Name: communication_thread_participants thread_participants: read own threads; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_participants: read own threads" ON public.communication_thread_participants FOR SELECT USING (public.auth_is_participant_of_thread(thread_id));


--
-- Name: communication_thread_participants thread_participants: thread creator insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_participants: thread creator insert" ON public.communication_thread_participants FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.communication_threads ct
  WHERE ((ct.id = communication_thread_participants.thread_id) AND (ct.assembly_id = public.auth_assembly_id()) AND (ct.created_by = auth.uid()) AND (ct.deleted_at IS NULL)))));


--
-- Name: communication_thread_participants thread_participants: update own read timestamp; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "thread_participants: update own read timestamp" ON public.communication_thread_participants FOR UPDATE USING ((member_id = public.auth_member_id())) WITH CHECK ((member_id = public.auth_member_id()));


--
-- Name: communication_threads threads: members insert non-pastoral; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "threads: members insert non-pastoral" ON public.communication_threads FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (is_pastoral = false) AND (is_sensitive = false)));


--
-- Name: communication_threads threads: participants read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "threads: participants read" ON public.communication_threads FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND public.auth_is_thread_participant(id)));


--
-- Name: communication_threads threads: pastoral restricted; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "threads: pastoral restricted" ON public.communication_threads FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL) AND ((is_sensitive = false) OR public.auth_has_permission('communications.attachments.view_pastoral'::text)) AND public.auth_is_thread_participant(id)));


--
-- Name: communication_threads threads: pastoral role insert sensitive; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "threads: pastoral role insert sensitive" ON public.communication_threads FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND public.auth_has_permission('communications.direct.send_pastoral'::text)));


--
-- Name: service_templates tmpl: insert own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tmpl: insert own assembly" ON public.service_templates FOR INSERT WITH CHECK ((assembly_id = public.auth_assembly_id()));


--
-- Name: service_templates tmpl: read own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tmpl: read own assembly" ON public.service_templates FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: service_templates tmpl: update own assembly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tmpl: update own assembly" ON public.service_templates FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (deleted_at IS NULL)));


--
-- Name: communication_trigger_rules trigger_rules: admins insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "trigger_rules: admins insert" ON public.communication_trigger_rules FOR INSERT WITH CHECK (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.templates.manage'::text))));


--
-- Name: communication_trigger_rules trigger_rules: admins read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "trigger_rules: admins read" ON public.communication_trigger_rules FOR SELECT USING (((assembly_id = public.auth_assembly_id()) AND public.auth_has_permission('communications.templates.manage'::text)));


--
-- Name: communication_trigger_rules trigger_rules: admins update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "trigger_rules: admins update" ON public.communication_trigger_rules FOR UPDATE USING (((assembly_id = public.auth_assembly_id()) AND (public.is_admin() OR public.auth_has_permission('communications.templates.manage'::text))));


--
-- Name: user_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_profiles user_profiles_insert_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_profiles_insert_admin ON public.user_profiles FOR INSERT TO authenticated WITH CHECK ((public.is_admin() AND (assembly_id = public.get_user_assembly_id())));


--
-- Name: user_profiles user_profiles_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_profiles_select ON public.user_profiles FOR SELECT TO authenticated USING (((id = ( SELECT auth.uid() AS uid)) OR (public.is_admin() AND (assembly_id = public.get_user_assembly_id()))));


--
-- Name: user_profiles user_profiles_update_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_profiles_update_admin ON public.user_profiles FOR UPDATE TO authenticated USING ((public.is_admin() AND (assembly_id = public.get_user_assembly_id()))) WITH CHECK ((public.is_admin() AND (assembly_id = public.get_user_assembly_id())));


--
-- Name: webhook_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: objects member_photos_authenticated_read; Type: POLICY; Schema: storage; Owner: -
--

CREATE POLICY member_photos_authenticated_read ON storage.objects FOR SELECT TO authenticated USING ((bucket_id = 'member-photos'::text));


--
-- Name: objects member_photos_owner_delete; Type: POLICY; Schema: storage; Owner: -
--

CREATE POLICY member_photos_owner_delete ON storage.objects FOR DELETE USING (((bucket_id = 'member-photos'::text) AND (auth.role() = 'authenticated'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));


--
-- Name: objects member_photos_owner_insert; Type: POLICY; Schema: storage; Owner: -
--

CREATE POLICY member_photos_owner_insert ON storage.objects FOR INSERT WITH CHECK (((bucket_id = 'member-photos'::text) AND (auth.role() = 'authenticated'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));


--
-- Name: objects member_photos_owner_update; Type: POLICY; Schema: storage; Owner: -
--

CREATE POLICY member_photos_owner_update ON storage.objects FOR UPDATE USING (((bucket_id = 'member-photos'::text) AND (auth.role() = 'authenticated'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));


--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime_messages_publication WITH (publish = 'insert, update, delete, truncate');


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: -
--

ALTER PUBLICATION supabase_realtime_messages_publication ADD TABLE ONLY realtime.messages;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict T08lCyunFWIVDumxyxNvIjCG5eH9Nu2s1frbV4xKfj9tacuzGAzxSQv10k8yTZF

